
#include <time.h>

//#include <omp.h>

#ifdef _OPENMP
#ifdef _DEBUG
#undef _DEBUG
#include <omp.h>
#define _DEBUG
#else
#include <omp.h>
#endif
#endif

#ifdef _OPENMP
#ifdef _DEBUG
#undef _DEBUG
#pragma comment(lib,"vcompd.lib")
#define _DEBUG
#else
#pragma comment(lib,"vcomp.lib")
#endif
#endif


#include "ITO_Mapping.h"

int N_gen=0;


//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^


int gauss_optimize_filter(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad){

	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;

	float gauss_sum=0;
	float total_sum=0;


	int cou1=(SR_y-filter_rad)*SR->widthStep;

	//�̈���̃K�E�V�A���̑��a
	for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
		for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

			work = (uchar)SR->imageData[cou1 + j];
			if(work > 0){
				gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)));
			}
		}
		cou1+=SR->widthStep;
	}

	//�̈���̃K�E�V�A�����|�������a
	cou1=(SR_y-filter_rad)*SR->widthStep;

	for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
		for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

			work = (uchar)SR->imageData[cou1 + j];
			if(work > 0){

				work=(uchar)SR->imageData[cou1 + j];
				total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*work;
			}
		}
		cou1+=SR->widthStep;
	}

	SR_value=(int)(total_sum/gauss_sum);

	return SR_value;
}


//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//�G�b�W��ԗp
float gauss_optimize_filter0(float* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* SR0,int *keisuu){

	int i=0,j=0,s=0,t=0;
	float SR_value=0;
	float work=0;
	int val=0;

	float gauss_sum=0;
	float total_sum=0;

	int cou1=(SR_y-filter_rad)*SR0->widthStep;

	for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
		for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

			val=(uchar)SR0->imageData[cou1+j];
			if(val > 0){
				work=*(SR	+ cou1 + j);
				total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*work;
				gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)));

			}
		}
		cou1+=SR0->widthStep;
	}

	if(gauss_sum>0){
		SR_value=(total_sum/gauss_sum);
	}else{
		SR_value=0;
	}

	return SR_value;
}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^

//�G�b�W��ԗp
float* gauss_optimize_filter0_line(float* SR, float* a_line, int filter_rad, IplImage* SR0, float* SR_work,int *keisuu, float* SR_ex2){

	int i=0,j=0,s=0,t=0;
	float SR_value=0;
	float work=0;
	int val=0;
	float val2=0;

	float gauss_sum=0;
	float total_sum=0;

	//�̈���̃K�E�V�A���̑��a
	for(i=0; i<SR0->height; i++){
		for(j=filter_rad; j<(SR0->width - filter_rad-1); j++){

			gauss_sum=0;
			total_sum=0;

				for(t=-filter_rad; t< (filter_rad+1); t++){
						val=(uchar)SR0->imageData[i*SR0->widthStep+j+t];
						total_sum+=(*(a_line + t+filter_rad)*val);
						gauss_sum+=(*(a_line + t+filter_rad)*keisuu[val]);

				}
				if(gauss_sum>0){
					SR_value=(total_sum/gauss_sum);
				}else{
					SR_value=0;
				}
				*(SR_work + j*SR0->height + i)=SR_value; 
		}}



	//�̈���̃K�E�V�A���̑��a
	for(i=0; i<SR0->width; i++){
		for(j=filter_rad; j<(SR0->height - filter_rad-1); j++){

			gauss_sum=0;
			total_sum=0;

				for(t=-filter_rad; t< (filter_rad+1); t++){
						val2=*(SR_work + i*SR0->height + j+t);
						total_sum+=(*(a_line + t+filter_rad)*val2);
						gauss_sum+=(*(a_line + t+filter_rad)*keisuu[(int)val2]);

				}
				if(gauss_sum>0){
					SR_value=(total_sum/gauss_sum);
				}else{
					SR_value=0;
				}
				*(SR_ex2 + j*SR0->width + i)=SR_value; 
		}}

	return SR_ex2;
}




//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^


int gauss_optimize_filter2(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g,int *keisuu){

	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou1=(SR_y-filter_rad)*SR->widthStep;
	int cou2=(SR_y-filter_rad)*ini->width;


		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work = (uchar)SR->imageData[cou1 + j];
				err=*(SR_counts_g + cou2 + j);
				err2=*(SR_counts  + cou2 + j);
				if(work > 0){
					work=(uchar)SR->imageData[cou1 + j];
					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*work*(err/err2);
					gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)))*(err/err2);
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
		}

	if(0.1>float(float(count)/float((filter_rad*2+1)*(filter_rad*2+1))) ){
		SR_value=(uchar)ini->imageData[SR_y*ini->widthStep + 3*SR_x + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
	}

	return SR_value;
}


//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//���񏈗�

void gauss_optimize_filter2_2(IplImage* SR,  float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g,IplImage* SR_color_hokan2){

	int SR_y,SR_x;
	int i=0,j=0;
	int SR_value=0;
	int work=0;
	float err=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou01,cou1;
	int cou02,cou2;
	int cent;
	float sqr=(filter_rad*2+1)*(filter_rad*2+1);
	int hei=(filter_rad*2+1);
	float work_para;


	#pragma omp parallel for private(cou01,cou02,SR_x,cent,cou1,cou2,gauss_sum,total_sum,count,i,j,work,err,work_para,SR_value)//���񉻁�
	for(SR_y=5; SR_y<SR->height-5; SR_y++){

		cou01=(SR_y-filter_rad)*SR->widthStep;
		cou02=(SR_y-filter_rad)*ini->width;

		for(SR_x=5; SR_x<SR->width-5; SR_x++){

		cent=SR_y*ini->widthStep + 3*SR_x;
		cou1=cou01;
		cou2=cou02;

		gauss_sum=0;
		total_sum=0;
		count=0;

		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){

			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work = (uchar)SR->imageData[cou1 + j];
				err=*(SR_counts_g + cou2 + j);
				if(work > 0){
					work_para=*(a + (i-(SR_y-filter_rad))*hei + (j-(SR_x-filter_rad)))*err;
					total_sum+=work_para*work;
					gauss_sum+=work_para;
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
		}

	if(0.1> float(count)/sqr ){
		SR_value=(uchar)ini->imageData[cent + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
	}

	if(SR_value>255){SR_value=255;}else if(SR_value<0){SR_value=0;}
	SR_color_hokan2->imageData[cent + plane]=(uchar)SR_value;
	}
}


}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//2pass

IplImage* gauss_optimize_filter2_line(IplImage* SR,  float* a_line, int filter_rad, IplImage* ini, int plane, float *SR_counts, float* SR_counts_g,float* SR_work,int *keisuu, IplImage *SR_color_hokan2){

	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;
//	float keisuu_sum=0;
	int val=0;
	float val2=0;

	//�̈���̃K�E�V�A���̑��a
	for(i=0; i<SR->height; i++){
		for(j=filter_rad; j<(SR->width - filter_rad-1); j++){

			gauss_sum=0;
			total_sum=0;

				for(t=-filter_rad; t< (filter_rad+1); t++){
						val=(uchar)SR->imageData[i*SR->widthStep+j+t];
						err=*(SR_counts_g + i*ini->width + j);
						err2=*(SR_counts + i*ini->width + j);
						total_sum+=(*(a_line + t+filter_rad)*val)*(err/err2);
						gauss_sum+=(*(a_line + t+filter_rad)*keisuu[val])*(err/err2);

				}
				if(gauss_sum>0){
					SR_value=(total_sum/gauss_sum);
				}else{
					SR_value=0;
				}
				*(SR_work + j*SR->height + i)=SR_value; 
		}}
	//�̈���̃K�E�V�A���̑��a
	for(i=0; i<SR->width; i++){
		for(j=filter_rad; j<(SR->height - filter_rad-1); j++){

			gauss_sum=0;
			total_sum=0;

				for(t=-filter_rad; t< (filter_rad+1); t++){
						val2=*(SR_work + i*SR->height + j+t);
						err=*(SR_counts_g + i*ini->height + j);
						err2=*(SR_counts + i*ini->height + j);
						total_sum+=(*(a_line + t+filter_rad)*val2)*(err/err2);
						gauss_sum+=(*(a_line + t+filter_rad)*keisuu[(int)val2])*(err/err2);

				}
				if(gauss_sum>0){
					SR_value=(total_sum/gauss_sum);
				}else{
					SR_value=0;
				}
				SR_color_hokan2->imageData[j*SR_color_hokan2->widthStep + 3*i+plane]=(uchar)SR_value; 
		}}


	return SR_color_hokan2;
}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//G�������z�Q��

int gauss_optimize_filter2_G(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,int *keisuu){
	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	int green_value=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou1=(SR_y-filter_rad)*SR->widthStep;
	int cou2=(SR_y-filter_rad)*ini->width;


		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[cou1 + j];
				green_value=(uchar)green->imageData[i*green->widthStep + 3*j+1];//green�̒l
				err=*(SR_counts_g + cou2 + j);
				err2=*(SR_counts +  cou2 + j);
				if(work > 0){
					work=(uchar)SR->imageData[cou1 + j];
					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*(work-green_value)*(err/err2);
					gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)))*(err/err2);
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
		}

	if(0.05>float(float(count)/float((filter_rad*2+1)*(filter_rad*2+1))) ){
		SR_value=(uchar)ini->imageData[SR_y*ini->widthStep + 3*SR_x + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=SR_value+(uchar)green->imageData[SR_y*green->widthStep + 3*SR_x+1];//green�̕t��
	}


	return SR_value;
}

//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//G�������z�Q��
//����

void gauss_optimize_filter2_G_2(IplImage* SR,  float* a, int filter_rad, IplImage* ini, int plane, float *SR_counts, float* SR_counts_g, IplImage* green,IplImage *SR_color_hokan){

	int SR_y,SR_x;
	int i=0,j=0;
	int SR_value=0;
	int work=0;
	int green_value=0;
	float err=0;


	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou01,cou1;
	int cou02,cou2;
	int cou03,cou3;
	int cent;
	float sqr=(filter_rad*2+1)*(filter_rad*2+1);
	int hei=(filter_rad*2+1);
	float work_para;

	#pragma omp parallel for private(cou01,cou02,cou03,SR_x,cent,cou1,cou2,cou3,green_value,gauss_sum,total_sum,count,i,j,work,err,work_para,SR_value)//���񉻁�
	for(SR_y=5; SR_y<SR->height-5; SR_y++){

		cou01=(SR_y-filter_rad)*SR->widthStep;
		cou02=(SR_y-filter_rad)*ini->width;
		cou03=(SR_y-filter_rad)*green->widthStep;

		for(SR_x=5; SR_x<SR->width-5; SR_x++){

		cent=SR_y*green->widthStep + 3*SR_x;
		cou1=cou01;
		cou2=cou02;
		cou3=cou03;


		gauss_sum=0;
		total_sum=0;
		count=0;


		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){


			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[cou1 + j];
				green_value=(uchar)green->imageData[cou3 + 3*j+1];//green�̒l
				err=*(SR_counts_g + cou2 + j);
				if(work > 0){
					work_para=*(a + (i-(SR_y-filter_rad))*hei + (j-(SR_x-filter_rad)))*err;
					total_sum+=work_para*(work-green_value);
					gauss_sum+=work_para;
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
			cou3+=green->widthStep;
		}

	if(0.05> float(count)/sqr ){
		SR_value=(uchar)ini->imageData[cent + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=SR_value+(uchar)green->imageData[cent+1];//green�̕t��
	}

	if(SR_value>255){SR_value=255;}else if(SR_value<0){SR_value=0;}
	SR_color_hokan->imageData[cent + plane]=(uchar)SR_value;
}}


}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//RB�������z�Q��


int gauss_optimize_filter2_RB(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,int *keisuu){
	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	int red_value=0;
	int blue_value=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou1=(SR_y-filter_rad)*SR->widthStep;
	int cou2=(SR_y-filter_rad)*ini->width;
	int cent;

		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[cou1 + j];
				blue_value=(uchar)green->imageData[i*green->widthStep + 3*j+0];//blue�̒l
				red_value=(uchar)green->imageData[i*green->widthStep + 3*j+2];//red�̒l
				err=*(SR_counts_g + cou2 + j);
				err2=*(SR_counts + cou2 + j);
				if(work > 0){
					work=(uchar)SR->imageData[cou1 + j];
					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*(work-(red_value+blue_value)/2.0)*(err/err2);
					gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)))*(err/err2);
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
		}
	
	if(0.05>float(float(count)/float((filter_rad*2+1)*(filter_rad*2+1))) ){
		SR_value=(uchar)ini->imageData[SR_y*ini->widthStep + 3*SR_x + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=SR_value+((uchar)green->imageData[SR_y*green->widthStep + 3*SR_x+2]+(uchar)green->imageData[SR_y*green->widthStep + 3*SR_x+0])/2.0;//green�̕t��
	}


	return SR_value;
}


//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//RB�������z�Q��
//����


void gauss_optimize_filter2_RB_2(IplImage* SR, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,IplImage *SR_color_hokan){

	int SR_y,SR_x;
	int i=0,j=0;
	int SR_value=0;
	int work=0;
	int red_value=0;
	int blue_value=0;
	float err=0;


	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	int cou01,cou1;
	int cou02,cou2;
	int cou03,cou3;
	int cent;
	float sqr=(filter_rad*2+1)*(filter_rad*2+1);
	int hei=(filter_rad*2+1);
	float work_para;

	#pragma omp parallel for private(cou01,cou02,cou03,SR_x,cent,cou1,cou2,cou3,red_value,blue_value,gauss_sum,total_sum,count,i,j,work,err,work_para,SR_value)//���񉻁�
	for(SR_y=5; SR_y<SR->height-5; SR_y++){

		cou01=(SR_y-filter_rad)*SR->widthStep;
		cou02=(SR_y-filter_rad)*ini->width;
		cou03=(SR_y-filter_rad)*green->widthStep;

		for(SR_x=5; SR_x<SR->width-5; SR_x++){

		cent=SR_y*green->widthStep + 3*SR_x;
		cou1=cou01;
		cou2=cou02;
		cou3=cou03;


		gauss_sum=0;
		total_sum=0;
		count=0;

		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[cou1 + j];
				blue_value=(uchar)green->imageData[cou3 + 3*j+0];//blue�̒l
				red_value=(uchar)green->imageData[cou3 + 3*j+2];//red�̒l
				err=*(SR_counts_g + cou2 + j);
				if(work > 0){
					work_para=*(a + (i-(SR_y-filter_rad))*hei + (j-(SR_x-filter_rad)))*err;
					total_sum+=work_para*(work-(red_value+blue_value)/2);
					gauss_sum+=work_para;
					count+=1;
				}
			}
			cou1+=SR->widthStep;
			cou2+=ini->width;
			cou3+=green->widthStep;
		}
	
	if(0.05> float(count)/sqr ){
		SR_value=(uchar)ini->imageData[cent + plane];
	}else{
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=SR_value+((uchar)green->imageData[cent+2]+(uchar)green->imageData[cent+0])/2;//green�̕t��
	}

	if(SR_value>255){SR_value=255;}else if(SR_value<0){SR_value=0;}
	SR_color_hokan->imageData[cent + plane]=(uchar)SR_value;
}}

}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//RB�������z�Q��
//�ڍוs��


int gauss_optimize_filter2_RB_test(IplImage* SR2, IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane, float *SR_counts, float* SR_counts_g, IplImage* green){
	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	int work2=0;
	int red_value=0;
	int blue_value=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	//�̈���̃K�E�V�A���̑��a
	for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
		for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

			work = (uchar)SR->imageData[i*SR->widthStep + j];
			err=*(SR_counts_g + i*ini->width + j);
			err2=*(SR_counts + i*ini->width + j);
			if(work > 0){
				gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)))*(err/err2);
//				count+=1;
			}

			if((uchar)SR->imageData[i*SR->widthStep + j]>0){	//������?
				count+=1;
			}
	}}


	if(0.05>float(float(count)/float((filter_rad*2+1)*(filter_rad*2+1))) ){
		SR_value=(uchar)ini->imageData[SR_y*ini->widthStep + 3*SR_x + plane];
	}else{

		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[i*SR->widthStep + j];
				work2 =		(uchar)SR2->imageData[i*SR->widthStep + j];
				err=*(SR_counts_g + i*ini->width + j);
				err2=*(SR_counts + i*ini->width + j);
				if(work > 0){
					work=(uchar)SR->imageData[i*SR->widthStep + j];
//					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*work*(err/err2);
					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*(work2)*(err/err2);
				}
		}}
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=(uchar)green->imageData[SR_y*green->widthStep + 3*SR_x+1]-SR_value;//green�̕t��

	}


	return SR_value;
}



//******************************************************************************************************************************************//
//�K�E�V�A����ԃt�B���^
//�ڍוs��



int gauss_optimize_filter2_else(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green, int iro){
	int i=0,j=0,s=0,t=0;
	int SR_value=0;
	int work=0;
	int green_value=0;
	float err=0;
	float err2=0;

	float gauss_sum=0;
	float total_sum=0;

	int count=0;

	//�̈���̃K�E�V�A���̑��a
	for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
		for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

			work = (uchar)SR->imageData[i*SR->widthStep + j];
			err=*(SR_counts_g + i*ini->width + j);
			err2=*(SR_counts + i*ini->width + j);
			if(work > 0){
				gauss_sum+=*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad)))*(err/err2);
//				count+=1;
			}

			if((uchar)SR->imageData[i*SR->widthStep + j]>0){	//������?
				count+=1;
			}
	}}


	if(0.05>float(float(count)/float((filter_rad*2+1)*(filter_rad*2+1))) ){
		SR_value=(uchar)ini->imageData[SR_y*ini->widthStep + 3*SR_x + plane];
	}else{

		//�̈���̃K�E�V�A�����|�������a
		for(i=SR_y-filter_rad; i<(SR_y + filter_rad+1); i++){
			for(j=SR_x-filter_rad; j<(SR_x + filter_rad+1); j++){

				work =		(uchar)SR->imageData[i*SR->widthStep + j];
				green_value=(uchar)green->imageData[i*green->widthStep + 3*j+iro];//green�̒l
				err=*(SR_counts_g + i*ini->width + j);
				err2=*(SR_counts + i*ini->width + j);
				if(work > 0){
					work=(uchar)SR->imageData[i*SR->widthStep + j];
//					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*work*(err/err2);
					total_sum+=(*(a + (i-(SR_y-filter_rad))*(filter_rad*2+1) + (j-(SR_x-filter_rad))))*(work-green_value)*(err/err2);
				}
		}}
		SR_value=(int)(total_sum/gauss_sum);
		SR_value=SR_value+(uchar)green->imageData[SR_y*green->widthStep + 3*SR_x+iro];//green�̕t��

	}


	return SR_value;
}




//******************************************************************************************************************************************//
//�K�E�V�A����PSF�𐶐�����֐�
//


float* gauss_filter0(int filter_rad,float sigma){
	float* a=(float*)calloc(81,sizeof(float));
	int i=0,j=0;
	double dist=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			dist=sqrt((double)( (i-filter_rad)*(i-filter_rad) + (j-filter_rad)*(j-filter_rad)) );

			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));

		}
	}

	return a;

}

//******************************************************************************************************************************************//
//�K�E�V�A����PSF(1�����t�B���^)�𐶐�����֐�


float* gauss_filter0_line(int filter_rad,float sigma){
	float* a_line=(float*)calloc(7,sizeof(float));
	int i=0,j=0;
	double dist=0;

	for(i=0;i<(filter_rad*2+1);i++){

			dist=sqrt((double)((i-filter_rad)*(i-filter_rad)) );

			*(a_line +  i) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));

	}

	return a_line;

}


//******************************************************************************************************************************************//
//���v���V�A���t�B���^�𐶐�����֐�



//����0128�ǉ�
float* laplace_filter0(int filter_rad){

	//���v���V�A���Ȃ̂�filter_rad=1�Ɍ��肷��
	filter_rad=1;

	float* a=(float*)calloc(9,sizeof(float));
	int i=0,j=0;
	double dist=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			if((i==1)&&(j==1)){
				*(a + i*(filter_rad*2+1) + j) =4;
			}else if((i==0)&&(j==1)){
				*(a + i*(filter_rad*2+1) + j) =-1;
			}else if((i==1)&&(j==0)){
				*(a + i*(filter_rad*2+1) + j) =-1;
			}else if((i==1)&&(j==2)){
				*(a + i*(filter_rad*2+1) + j) =-1;
			}else if((i==2)&&(j==1)){
				*(a + i*(filter_rad*2+1) + j) =-1;
			}else{
				*(a + i*(filter_rad*2+1) + j) =0;
			}

	}}

	return a;

}


//******************************************************************************************************************************************//
//�K�E�V�A����PSF�𐶐�����֐�
//


float* gauss_filter(float* a, int filter_rad,float sigma){
//	float* a=(float*)calloc(121,sizeof(float));
	int i=0,j=0;
	double dist=0;
	double sum=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			dist=sqrt((double)( (i-filter_rad)*(i-filter_rad) + (j-filter_rad)*(j-filter_rad)) );

			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));
//			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist)/(2*sigma*sigma));
			sum+=*(a + i*(filter_rad*2+1) + j);
		}
	}

	//���K������
	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			*(a + i*(filter_rad*2+1) + j)/=sum;

		}
	}

	return a;
}



//******************************************************************************************************************************************//
//�K�E�V�A����PSF�𐶐�����֐�
//

float* gauss_filter_line(float* a, int filter_rad,float sigma){

	int i=0,j=0;
	double dist=0;
	double sum=0;

	for(i=0;i<(filter_rad*2+1);i++){

			dist=sqrt((double)((i-filter_rad)*(i-filter_rad)) );
			*(a +  i) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));

			sum+=*(a +  i);//�K�E�V�A���W���̑��a
	}

	//���K������
	for(i=0;i<(filter_rad*2+1);i++){
			*(a +  i)/=sum;
	}


	return a;

}


//******************************************************************************************************************************************//
//�􉽕ϊ��̃}�g���b�N�X
//


//������6���R�x�̏ꍇ
#ifdef free6
void init_warp(CvMat* W, float p1, float p2, float p3, float p4, float p5, float p6)
{
	CV_MAT_ELEM(*W, float, 0, 0) = 1+p1;
	CV_MAT_ELEM(*W, float, 1, 0) = p2;
	CV_MAT_ELEM(*W, float, 2, 0) = 0;

	CV_MAT_ELEM(*W, float, 0, 1) = p3;
	CV_MAT_ELEM(*W, float, 1, 1) = 1+p4;
	CV_MAT_ELEM(*W, float, 2, 1) = 0;

	CV_MAT_ELEM(*W, float, 0, 2) = p5;
	CV_MAT_ELEM(*W, float, 1, 2) = p6;
	CV_MAT_ELEM(*W, float, 2, 2) = 1;
}
#endif

//������4���R�x�̏ꍇ
#ifdef free4
void init_warp(CvMat* W, float wz, float tx, float ty, float s)
{
	CV_MAT_ELEM(*W, float, 0, 0) = s;
	CV_MAT_ELEM(*W, float, 1, 0) = wz;
	CV_MAT_ELEM(*W, float, 2, 0) = 0;

	CV_MAT_ELEM(*W, float, 0, 1) = -wz;
	CV_MAT_ELEM(*W, float, 1, 1) = s;
	CV_MAT_ELEM(*W, float, 2, 1) = 0;

	CV_MAT_ELEM(*W, float, 0, 2) = tx;
	CV_MAT_ELEM(*W, float, 1, 2) = ty;
	CV_MAT_ELEM(*W, float, 2, 2) = 1;
}
#endif


//������3���R�x�̏ꍇ
#ifdef free3
void init_warp(CvMat* W, float wz, float tx, float ty)
{
	CV_MAT_ELEM(*W, float, 0, 0) = 1;
	CV_MAT_ELEM(*W, float, 1, 0) = wz;
	CV_MAT_ELEM(*W, float, 2, 0) = 0;

	CV_MAT_ELEM(*W, float, 0, 1) = -wz;
	CV_MAT_ELEM(*W, float, 1, 1) = 1;
	CV_MAT_ELEM(*W, float, 2, 1) = 0;

	CV_MAT_ELEM(*W, float, 0, 2) = tx;
	CV_MAT_ELEM(*W, float, 1, 2) = ty;
	CV_MAT_ELEM(*W, float, 2, 2) = 1;
}
#endif


//������2���R�x�̏ꍇ
void init_warp0(CvMat* W, float tx, float ty)
{
	CV_MAT_ELEM(*W, float, 0, 0) = 1;
	CV_MAT_ELEM(*W, float, 1, 0) = 0;
	CV_MAT_ELEM(*W, float, 2, 0) = 0;

	CV_MAT_ELEM(*W, float, 0, 1) = 0;
	CV_MAT_ELEM(*W, float, 1, 1) = 1;
	CV_MAT_ELEM(*W, float, 2, 1) = 0;

	CV_MAT_ELEM(*W, float, 0, 2) = tx;
	CV_MAT_ELEM(*W, float, 1, 2) = ty;
	CV_MAT_ELEM(*W, float, 2, 2) = 1;
}





//******************************************************************************************************************************************//
//�􉽕ϊ���̋�`�̈��`�悷��֐�
//


void draw_warped_rect(IplImage* pImage, CvRect rect, CvMat* W)
{
	CvPoint lt, lb, rt, rb;
	
	CvMat* X = cvCreateMat(3, 1, CV_32F);
	CvMat* Z = cvCreateMat(3, 1, CV_32F);

	// left-top point
	SET_VECTOR(X, rect.x, rect.y);
	cvGEMM(W, X, 1, 0, 0, Z);
	GET_INT_VECTOR(Z, lt.x, lt.y);

	// left-bottom point
	SET_VECTOR(X, rect.x, rect.y+rect.height);
	cvGEMM(W, X, 1, 0, 0, Z);
	GET_INT_VECTOR(Z, lb.x, lb.y);

	// right-top point
	SET_VECTOR(X, rect.x+rect.width, rect.y);
	cvGEMM(W, X, 1, 0, 0, Z);
	GET_INT_VECTOR(Z, rt.x, rt.y);

	// right-bottom point
	SET_VECTOR(X, rect.x+rect.width, rect.y+rect.height);
	cvGEMM(W, X, 1, 0, 0, Z);
	GET_INT_VECTOR(Z, rb.x, rb.y);

	// draw rectangle
	cvLine(pImage, lt, rt, cvScalar(255),1.2,CV_AA);
	cvLine(pImage, rt, rb, cvScalar(255),1.2,CV_AA);
	cvLine(pImage, rb, lb, cvScalar(255),1.2,CV_AA);
	cvLine(pImage, lb, lt, cvScalar(255),1.2,CV_AA);

	// release resources and exit
	cvReleaseMat(&X);
	cvReleaseMat(&Z);
}

void warp_image(IplImage* pSrcFrame, IplImage* pDstFrame, CvMat* W)
{
	cvSet(pDstFrame, cvScalar(0));

	CvMat* X = cvCreateMat(3, 1, CV_32F);
	CvMat* Z = cvCreateMat(3, 1, CV_32F);
	int x, y;

	for(x=0;x<pSrcFrame->width; x++)
	{
		for(y=0;y<pSrcFrame->height; y++)
		{
			SET_VECTOR(X, x, y);

			cvGEMM(W, X, 1, 0, 0, Z);

			int x2, y2;
			GET_INT_VECTOR(Z, x2, y2);

			if(x2>=0 && x2<pDstFrame->width &&
				y2>=0 && y2<pDstFrame->height)
			{
				CV_IMAGE_ELEM(pDstFrame, uchar, y2, x2) = 
					CV_IMAGE_ELEM(pSrcFrame, uchar, y, x);
			}
		}
	}
	//cvSmooth(pDstFrame, pDstFrame);

	cvReleaseMat(&X);
	cvReleaseMat(&Z);
}








//******************************************************************************************************************************************//
//�ʒu���킹�摜��MAP�@�ɂ��č\������
// �ŋ}�~���@(SD�@)


IplImage* cg_color2(float *a,float *laplace,IplImage* SR_color, IplImage* src_ini_color , float *SR_ex, float *SR_ey, float *a_line2)
{
	//a: PSF
	//b:�ʒu���킹��̃f�[�^
	//x:�����f�[�^(�����ω������o�͂���)
	//laplace: (3�~3�̃��v���V�A���f�[�^)

	printf("ComplexConjugate_color2_st..\n");

	N_gen=SR_color->width*SR_color->height;

	float *x_y=(float*)calloc(N_gen,sizeof(float));
	float *x_cb=(float*)calloc(N_gen,sizeof(float));
	float *x_cr=(float*)calloc(N_gen,sizeof(float));

	float *b_y=(float*)calloc(N_gen,sizeof(float));
	float *b_cb=(float*)calloc(N_gen,sizeof(float));
	float *b_cr=(float*)calloc(N_gen,sizeof(float));


	float  alpha_y,alpha_cb,alpha_cr;
	float  beta_y,beta_cb,beta_cr, work;

	float *p_y=(float*)calloc(N_gen,sizeof(float));
	float *tmp_y=(float*)calloc(N_gen,sizeof(float));
	float *tmp2_y=(float*)calloc(N_gen,sizeof(float));//����0128�ǉ�


	float *p_cb=(float*)calloc(N_gen,sizeof(float));
	float *tmp_cb=(float*)calloc(N_gen,sizeof(float));
	float *tmp2_cb=(float*)calloc(N_gen,sizeof(float));//����0128�ǉ�

	float *p_cr=(float*)calloc(N_gen,sizeof(float));
	float *tmp_cr=(float*)calloc(N_gen,sizeof(float));
	float *tmp2_cr=(float*)calloc(N_gen,sizeof(float));//����0128�ǉ�



	float *w_area=(float*)calloc(N_gen,sizeof(float));



//	FILE *hfp;
//	hfp=fopen("G:\\hukugen2.txt","w");
	double  alpha_y2,alpha_cb2,alpha_cr2;
	double  beta_y2,beta_cb2,beta_cr2;


	double old_work1=0,old_work2=0;


	double eps;
	int i=0, j=0,k=0,t=0, kwst=0;



	//������(YCrCb�̃f�[�^����)
	#pragma omp parallel for private(j,k,t,kwst)								//���񉻁�
	for(i=0;i<SR_color->height;i++){
		k=i*SR_color->width;
		kwst=i*SR_color->widthStep;
		t=0;
		for(j=0;j<SR_color->widthStep;j=j+3){
			*(x_y+ k+t)	=(uchar)src_ini_color->imageData[kwst +j+0];
			*(x_cb+k+t)	=(uchar)src_ini_color->imageData[kwst +j+1];
			*(x_cr+k+t)	=(uchar)src_ini_color->imageData[kwst +j+2];
			*(b_y+ k+t)	=(uchar)SR_color->imageData[kwst +j+0];
			*(b_cb+k+t)	=(uchar)SR_color->imageData[kwst +j+1];
			*(b_cr+k+t)	=(uchar)SR_color->imageData[kwst +j+2];
		t+=1;
		}
	}
	k=0;t=0;kwst=0;

	printf("preprocess fin.\n");

// y:B
//cb:G
//cr:R

	//���ŕ���&2pass
	matrix_vector_product_line( a_line2, x_y,  tmp_y,  SR_color, w_area);// tmp=AP///������
	matrix_vector_product_line( a_line2, x_cb, tmp_cb, SR_color, w_area);// tmp=AP///������
	matrix_vector_product_line( a_line2, x_cr, tmp_cr, SR_color, w_area);// tmp=AP///������



	#pragma omp parallel for
	for( i = 0; i < N_gen; i++)
	{
		if( *(b_y+i)>0 ){	*(p_y+i) = *(b_y+i) -*(tmp_y +i) ;	}
		if( *(b_cb+i)>0 ){	*(p_cb+i) = *(b_cb+i) -*(tmp_cb +i);}
		if( *(b_cr+i)>0 ){	*(p_cr+i) = *(b_cr+i) -*(tmp_cr +i);}
	}


// y:B
//cb:G
//cr:R

do{

	printf("Loop check\n");

	//�ŏ����̍�:J1+J2+J3
	// alpha�̌v�Z(J1)
		//���ŕ���&2pass
		matrix_vector_product_line(a_line2,	p_cb,	tmp_cb,	SR_color,	w_area);			// tmp=AP///������
		matrix_vector_product02_line(a_line2,	p_y,	tmp_cb,	tmp_y , SR_color,	w_area);// tmp=AP///������
		matrix_vector_product02_line(a_line2,	p_cr,	tmp_cb,	tmp_cr, SR_color,	w_area);// tmp=AP///������

	//�����f�[�^x�̃��v���V�A����tmp2�ɓ����B(J2)
		//���ŕ���
		matrix_vector_product2( laplace, x_y,	tmp2_y , SR_color); // tmp=Ab
		matrix_vector_product2( laplace, x_cb,  tmp2_cb , SR_color); // tmp=Ab 
		matrix_vector_product2( laplace, x_cr,  tmp2_cr , SR_color); // tmp=Ab 

	//PSF�̍��ƍS�����̔䗦�v�Z
		double ratio1=1.0,ratio2=1.0;


	//�d�ݕt�������Z
		//���ŕ���
		subst_f(tmp_y, tmp2_y, tmp_y, N_gen, -0.1);
		subst_f(tmp_cb,tmp2_cb,tmp_cb,N_gen, -0.1);
		subst_f(tmp_cr,tmp2_cr,tmp_cr,N_gen, -0.1);

		alpha_y = +1.0;
		alpha_cb= +1.0 ;
		alpha_cr =+1.0 ;


	//x�̒l�̕ύX
	#pragma omp parallel for				//���񉻁�
	for( i = 0; i < N_gen; i++){ 

		*(x_y+i) = *(x_y+i)	  +*(tmp_y+i);
		*(x_cb+i) = *(x_cb+i) +*(tmp_cb+i);
		*(x_cr+i) = *(x_cr+i) +*(tmp_cr+i);
		if(*(x_y+i)>255){*(x_y+i)=255;}	else if(*(x_y+i)<0){*(x_y+i)=0;}
		if(*(x_cb+i)>255){*(x_cb+i)=255;}	else if(*(x_cb+i)<0){*(x_cb+i)=0;}
		if(*(x_cr+i)>255){*(x_cr+i)=255;}	else if(*(x_cr+i)<0){*(x_cr+i)=0;}

	}

	//���ŕ���&2pass
	matrix_vector_product_line( a_line2, x_y,  tmp_y,  SR_color,	w_area); // tmp=AP///������
	matrix_vector_product_line( a_line2, x_cb, tmp_cb, SR_color,	w_area); // tmp=AP///������
	matrix_vector_product_line( a_line2, x_cr, tmp_cr, SR_color,	w_area); // tmp=AP///������


	#pragma omp parallel for				//���񉻁�
	for( i = 0; i < N_gen; i++)
	{
		//Huber�֐��𓱓�����ɂ͂����ŃA�b�p�[���~�b�g��������΂��������B
		if( *(b_y+i)>0 ){	*(p_y+i)  = *(b_y+i) -*(tmp_y +i) ;}
		if( *(b_cb+i)>0 ){	*(p_cb+i) = *(b_cb+i) -*(tmp_cb +i) ;}
		if( *(b_cr+i)>0 ){	*(p_cr+i) = *(b_cr+i) -*(tmp_cr +i) ;}
	}


	k++; // �����񐔂̍X�V

	printf("Loop check\n");


}while( k <4 );


	t=0;
	//����
	#pragma omp parallel for private(j,k,t,kwst)
	for(i=0;i<SR_color->height;i++){

		k=i*SR_color->width;
		kwst=i*SR_color->widthStep;
		t=0;

		for(j=0;j<SR_color->widthStep;j=j+3){
			if(		*(x_y+k+t) >255){	SR_color->imageData[kwst +j+0]=(uchar)255;		}
			else if(*(x_y+k+t) <0){		SR_color->imageData[kwst +j+0]=(uchar)0;			}
			else{						SR_color->imageData[kwst +j+0]=(uchar)*(x_y+k+t);	}
			if(		*(x_cb+k+t) >255){	SR_color->imageData[kwst +j+1]=(uchar)255;		}
			else if(*(x_cb+k+t) <0){	SR_color->imageData[kwst +j+1]=(uchar)0;		}
			else{						SR_color->imageData[kwst +j+1]=(uchar)*(x_cb+k+t);	}
			if(		*(x_cr+k+t) >255){	SR_color->imageData[kwst +j+2]=(uchar)255;			}
			else if(*(x_cr+k+t) <0){	SR_color->imageData[kwst +j+2]=(uchar)0;			}
			else{						SR_color->imageData[kwst +j+2]=(uchar)*(x_cr+k+t);	}
		t+=1;
		}
	}
	k=0;t=0;

	free(x_y);
	free(b_y);
	free(p_y);
	free(tmp_y);
	free(tmp2_y);
	free(x_cr);
	free(b_cr);
	free(p_cr);
	free(tmp_cr);
	free(tmp2_cr);
	free(x_cb);
	free(b_cb);
	free(p_cb);
	free(tmp_cb);
	free(tmp2_cb);
	free(w_area);


	return SR_color;
}






//******************************************************************************************************************************************//
//�����摜��MAP�@�ɂ��č\������
// �ŋ}�~���@(SD�@)


IplImage* cg_color2_cubic(float *a,float *laplace,IplImage* SR_color, IplImage* src_ini_color , float *SR_ex, float *SR_ey, float *a_line2)
{
	//a: PSF
	//b:�ʒu���킹��̃f�[�^
	//x:�����f�[�^(�����ω������o�͂���)
	//laplace: (3�~3�̃��v���V�A���f�[�^)

//	printf("cg_color_start1\n");
	printf("ComplexConjugate_color2_cubic_st..\n");

	N_gen=SR_color->width*SR_color->height;

	float *x_y=(float*)calloc(N_gen,sizeof(float));
	float *x_cb=(float*)calloc(N_gen,sizeof(float));
	float *x_cr=(float*)calloc(N_gen,sizeof(float));

	float *b_y=(float*)calloc(N_gen,sizeof(float));
	float *b_cb=(float*)calloc(N_gen,sizeof(float));
	float *b_cr=(float*)calloc(N_gen,sizeof(float));


	float  alpha_y,alpha_cb,alpha_cr;
	float  beta_y,beta_cb,beta_cr, work;

	float *p_y=(float*)calloc(N_gen,sizeof(float));
	float *tmp_y=(float*)calloc(N_gen,sizeof(float));

	float *p_cb=(float*)calloc(N_gen,sizeof(float));
	float *tmp_cb=(float*)calloc(N_gen,sizeof(float));
	float *tmp2_cb=(float*)calloc(N_gen,sizeof(float));//����0128�ǉ�

	float *p_cr=(float*)calloc(N_gen,sizeof(float));
	float *tmp_cr=(float*)calloc(N_gen,sizeof(float));

	float *w_area=(float*)calloc(N_gen,sizeof(float));



//	FILE *hfp;
//	hfp=fopen("G:\\hukugen2.txt","w");
	double  alpha_y2,alpha_cb2,alpha_cr2;
	double  beta_y2,beta_cb2,beta_cr2, work2;
	double work3;

	double old_work1=0,old_work2=0;
	double eps;
	int i=0, j=0,k=0,t=0,kwst=0;

	//������(YCrCb�̃f�[�^����)
	#pragma omp parallel for private(i,j,t,kwst)								//���񉻁�
	for(i=0;i<SR_color->height;i++){
		k=i*SR_color->width;
		kwst=i*SR_color->widthStep;
		t=0;
		for(j=0;j<SR_color->widthStep;j=j+3){
			*(x_y+ k+t)	=(uchar)src_ini_color->imageData[kwst +j+0];
			*(x_cb+k+t)	=(uchar)src_ini_color->imageData[kwst +j+1];
			*(x_cr+k+t)	=(uchar)src_ini_color->imageData[kwst +j+2];
			*(b_y+ k+t)	=(uchar)SR_color->imageData[kwst +j+0];
			*(b_cb+k+t)	=(uchar)SR_color->imageData[kwst +j+1];
			*(b_cr+k+t)	=(uchar)SR_color->imageData[kwst +j+2];
		t+=1;
		}
	}
	k=0;t=0;kwst=0;


// y:B
//cb:G
//cr:R
	//���ŕ���&2pass
	matrix_vector_product_line( a_line2, x_y,  tmp_y,  SR_color, w_area); // tmp=AP///������
	matrix_vector_product_line( a_line2, x_cb, tmp_cb, SR_color, w_area); // tmp=AP///������
	matrix_vector_product_line( a_line2, x_cr, tmp_cr, SR_color, w_area); // tmp=AP///������

	//�d�ݕt�������Z
	//���ŕ���
	subst_f(b_y , tmp_y , p_y , N_gen, -1);
	subst_f(b_cb, tmp_cb, p_cb, N_gen, -1);
	subst_f(b_cr, tmp_cr, p_cr, N_gen, -1);


// y:B
//cb:G
//cr:R

do
{
		printf("Loop check\n");

		//���ŕ���&2pass
		matrix_vector_product_line(a_line2,	p_cb,	tmp_cb,	SR_color,	w_area);	// tmp=AP///������
		//���ŕ���
		matrix_vector_product2( laplace, x_cb,  tmp2_cb , SR_color);				// tmp=AP///������


		//PSF�̍��ƍS�����̔䗦�v�Z
		double ratio1=1.0,ratio2=1.0;

		subst_f(tmp_cb, tmp2_cb, tmp_cb,N_gen,  -0.1);

		alpha_cb= +1.0 ;


		//x�̒l�̕ύX
		#pragma omp parallel for
		for( i = 0; i < N_gen; i++){ 

			*(x_y+i)  = *(x_y+i)	+*(tmp_cb+i);
			*(x_cb+i) = *(x_cb+i)	+*(tmp_cb+i);	
			*(x_cr+i) = *(x_cr+i)	+*(tmp_cb+i);

			if(*(x_y+i)>255){*(x_y+i)=255;}	else if(*(x_y+i)<0){*(x_y+i)=0;}
			if(*(x_cb+i)>255){*(x_cb+i)=255;}	else if(*(x_cb+i)<0){*(x_cb+i)=0;}
			if(*(x_cr+i)>255){*(x_cr+i)=255;}	else if(*(x_cr+i)<0){*(x_cr+i)=0;}
		}

		matrix_vector_product_line( a_line2, x_cb, tmp_cb, SR_color,	w_area);		// tmp=AP///������

		//�d�ݕt�������Z
		//���ŕ���
		subst_f(b_y , tmp_cb, p_y , N_gen, -1);
		subst_f(b_cb, tmp_cb, p_cb, N_gen, -1);
		subst_f(b_cr, tmp_cb, p_cr, N_gen, -1);

		k++; // �����񐔂̍X�V
		printf("Loop check\n");


}while( k < 2 );

OUTPUT:



	//�T�`�����菜��
	t=0;

	#pragma omp parallel for private(j,k,t,kwst)
	for(i=0;i<SR_color->height;i++){

		k=i*SR_color->width;
		kwst=i*SR_color->widthStep;
		t=0;

		for(j=0;j<SR_color->widthStep;j=j+3){
			if(		*(x_y+k+t) >255){	SR_color->imageData[kwst +j+0]=(uchar)255;			}
			else if(*(x_y+k+t) <0){		SR_color->imageData[kwst +j+0]=(uchar)0;			}
			else{						SR_color->imageData[kwst +j+0]=(uchar)*(x_y+k+t);	}
			if(		*(x_cb+k+t) >255){	SR_color->imageData[kwst +j+1]=(uchar)255;			}
			else if(*(x_cb+k+t) <0){	SR_color->imageData[kwst +j+1]=(uchar)0;			}
			else{						SR_color->imageData[kwst +j+1]=(uchar)*(x_cb+k+t);	}
			if(		*(x_cr+k+t) >255){	SR_color->imageData[kwst +j+2]=(uchar)255;			}
			else if(*(x_cr+k+t) <0){	SR_color->imageData[kwst +j+2]=(uchar)0;			}
			else{						SR_color->imageData[kwst +j+2]=(uchar)*(x_cr+k+t);	}
		t+=1;
		}
	}


	free(x_y);
	free(b_y);
	free(p_y);
	free(tmp_y);

	free(x_cr);
	free(b_cr);
	free(p_cr);
	free(tmp_cr);

	free(x_cb);
	free(b_cb);
	free(p_cb);
	free(tmp_cb);
	free(tmp2_cb);
	free(w_area);

	return SR_color;
}








//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab


void matrix_vector_product(float *a, float *b, float *c, IplImage* src)
{
	float wk=0;
	int i, s, t;

	float work;

	for ( i = 0; i < N_gen; i++)
	{
		wk = 0.0;

				for(s=-5;s<6;s++){
				for(t=-5;t<6;t++){

					if( ((i + (s*src->width) + t)>=0)&&((i + (s*src->width) + t)<(src->width*src->height))  ){

						work=*(b + i+ (s*src->width) + t );
						wk+=*(a +(s+5)*11 +(t+5))*work;


					}
				}}


		*(c+i) = wk;
	}


}



//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab
//2�p�X��


void matrix_vector_product_line(float *a, float *b, float *c, IplImage* src, float *work)
{
	float wk=0;
	int i, j,  t;

	float total_sum=0;

	int cou1=0;



	//�������̃K�E�V�A������
	#pragma omp parallel for private(total_sum,t,j,cou1)								//���񉻁�
	for(i=0; i<src->height; i++){
		cou1=i*src->width;

		for(j=5; j<(src->width - 6); j++){

			total_sum=0;

				
				for(t=-5; t< 6; t++){
						total_sum+=(*(b+ cou1+j+t))*(*(a+t+5));

				}
				*(work + j*src->height+i)=total_sum; 
		}

	}

	//�c�����̃K�E�V�A������
	#pragma omp parallel for private(total_sum,t,i,cou1)								//���񉻁�
	for(j=0; j<(src->width); j++){
		cou1=j*src->height;

		for(i=5; i<src->height-6; i++){



			total_sum=0;

				for(t=-5; t< 6; t++){
					total_sum+=(*(work+ cou1+i+t))*(*(a+t+5));

				}
				*(c + i*src->width+j)=total_sum; 
		}
	}


}



//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab



void matrix_vector_product02( float *a, float *b, float *d, float *c ,IplImage* src){
	float wk=0;
	int i,  s, t;

	float work;

	for ( i = 0; i < N_gen; i++)
	{
		wk = 0.0;

				for(s=-5;s<6;s++){
				for(t=-5;t<6;t++){

					if( ((i + (s*src->width) + t)>=0)&&((i + (s*src->width) + t)<(src->width*src->height))  ){

						work=*(b + i+ (s*src->width) + t );
						wk+=*(a +(s+5)*11 +(t+5))*work;

					}
				}}


		*(c+i) = wk+*(d+i);
	}
}



//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab
//2�p�X��


void matrix_vector_product02_line( float *a, float *b, float *d, float *c ,IplImage* src, float *work){
	float wk=0;
	int i, j, t;

	float total_sum=0;

	int cou1=0;


	//�������̃K�E�V�A������
	#pragma omp parallel for private(total_sum,t,j,cou1)								//���񉻁�
	for(i=0; i<src->height; i++){
		cou1=i*src->width;

		for(j=5; j<(src->width - 6); j++){

			total_sum=0;

				for(t=-5; t< 6; t++){
						total_sum+=(*(b+ cou1+j+t))*(*(a+t+5));

				}
				*(work + j*src->height+i)=total_sum; 
		}

	}
	//�c�����̃K�E�V�A������
	#pragma omp parallel for private(total_sum,t,i,cou1)								//���񉻁�
	for(j=0; j<(src->width); j++){
		cou1=j*src->height;

		for(i=5; i<src->height-6; i++){

			total_sum=0;

				for(t=-5; t< 6; t++){
					total_sum+=(*(work+ cou1+i+t))*(*(a+t+5));

				}
				*(c + i*src->width+j)=total_sum+ *(d + i*src->width+j); 
		}
	}

}



//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab
//����

void matrix_vector_product2(float *a, float *b, float *c, IplImage* src)
{
	float wk=0;
	int i, j, s, t;
	float work;

	int cou1=0;


	#pragma omp parallel for private(wk,s,t,j,cou1,work)				//���񉻁�
	for(i=1; i<src->height-1; i++){
		cou1=i*src->width;


		for(j=1; j<src->width-1; j++){
			wk = 0.0;

				for(s=-1;s<2;s++){
					for(t=-1;t<2;t++){

						work=*(b + cou1+j+ (s*src->width) + t );
						wk+=*(a +(s+1)*3 +(t+1))*work;

					}
				}
		*(c+cou1+j) = wk;
		}
	}


}


//******************************************************************************************************************************************//
// �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�  c <-ab
//�G�b�W�������œK�����s��

void matrix_vector_product2_y(float *a, float *b, float *c, IplImage* src, float *SR_ex, float *SR_ey)
{
	float wk=0;
	int i, s, t;

	float work;

	//�G�b�W�̕������聙
	float ed_x0=0,ed_y0=0;
	float ed_x=0,ed_y=0;
	double ed[4],max_ed=0;
	double ed_sum=0.0;
	int k=0,ed_num=4;
	float *d=(float*)calloc(9,sizeof(float));


	for ( i = 0; i < N_gen; i++)
	{
				//�G�b�W�̕������聙
				//��������
				ed_x=0;ed_y=0;
				for(k=0;k<9;k++){*(d+k)=0;}


				//��𑜂̃G�b�W�f�[�^�𗘗p����ꍇ
				if( (*(SR_ex+i)!=0)||(*(SR_ey+i)!=0) ){
						ed_x=*(SR_ex+i);
						ed_y=*(SR_ey+i);

					//4�����x�N�g���Ƃ̓���
					ed[0]=(double)sqrt(double(ed_x*ed_x));
					ed[1]=(double)sqrt(double((0.707*ed_x+0.707*ed_y)*(0.707*ed_x+0.707*ed_y)));
					ed[2]=(double)sqrt(double(ed_y*ed_y));
					ed[3]=(double)sqrt(double((-0.707*ed_x+0.707*ed_y)*(-0.707*ed_x+0.707*ed_y)));

				//���a
				ed_sum=ed[0]+ed[1]+ed[2]+ed[3];


				*(d+1)=-1*ed[0];*(d+4)=(2*ed[0]);*(d+7)=-1*ed[0];
				*(d+0)=-1*ed[1];*(d+4)+=(2*ed[1]);*(d+8)=-1*ed[1];
				*(d+3)=-1*ed[2];*(d+4)+=(2*ed[2]);*(d+5)=-1*ed[2];
				*(d+2)=-1*ed[3];*(d+4)+=(2*ed[3]);*(d+6)=-1*ed[3];

				}
				else{
					//���𑜂���x,y�����G�b�W�̉��Z
					for(s=-3;s<4;s++){
					for(t=-3;t<4;t++){
						if( ((i + (s*src->width) + t)>=0)&&((i + ((s+1)*src->width) + t)<(src->width*src->height))&&
							(*(b + i+ (s*src->width) + t+1 )>0)&&(*(b + i+ (s*src->width) + t )>0)&&(*(b + i+ ((s+1)*src->width) + t+1 )>0)){	

								ed_x0=*(b + i+ (s*src->width) + t+1 ) - *(b + i+ (s*src->width) + t );
								ed_y0=*(b + i+ ((s+1)*src->width) + t ) - *(b + i+ (s*src->width) + t );

								//�G�b�W�ш�̐���
								if( (ed_x0<50)&&(ed_x0>-50)&&(ed_y0<50)&&(ed_y0>-50)){
									ed_x+=ed_x0;
									ed_y+=ed_y0;
								}
						}
					}}
				//4�����x�N�g���Ƃ̓���
				ed[0]=(double)sqrt(double(ed_x*ed_x));
				ed[1]=(double)sqrt(double((0.707*ed_x+0.707*ed_y)*(0.707*ed_x+0.707*ed_y)));
				ed[2]=(double)sqrt(double(ed_y*ed_y));
				ed[3]=(double)sqrt(double((-0.707*ed_x+0.707*ed_y)*(-0.707*ed_x+0.707*ed_y)));

//�d�ݕt���ۑ�
				//���a
				ed_sum=ed[0]+ed[1]+ed[2]+ed[3];
				//����������
//				*(d+1)=-1*ed[0];*(d+4)=(2*ed[0]);*(d+7)=-1*ed[0];
//				*(d+0)=-1*ed[1];*(d+4)+=(2*ed[1]);*(d+8)=-1*ed[1];
//				*(d+3)=-1*ed[2];*(d+4)+=(2*ed[2]);*(d+5)=-1*ed[2];
//				*(d+2)=-1*ed[3];*(d+4)+=(2*ed[3]);*(d+6)=-1*ed[3];
				*(d+1)=-1*ed[2];*(d+4)=(2*ed[0]);*(d+7)=-1*ed[2];
				*(d+0)=-1*ed[3];*(d+4)+=(2*ed[1]);*(d+8)=-1*ed[3];
				*(d+3)=-1*ed[0];*(d+4)+=(2*ed[2]);*(d+5)=-1*ed[0];
				*(d+2)=-1*ed[1];*(d+4)+=(2*ed[3]);*(d+6)=-1*ed[1];

				}

				if(ed_sum>0){
					for(k=0;k<9;k++){
						*(d+k)/=ed_sum;
					}
				}
				else{
					for(k=0;k<9;k++){
						*(d+k)=*(a+k);

					}
				}

/*				else{
					for(k=0;k<9;k++){
						*(d+k)=0;
					}
				}
*/


		wk = 0.0;
				for(s=-1;s<2;s++){
				for(t=-1;t<2;t++){

					if( ((i + (s*src->width) + t)>=0)&&((i + (s*src->width) + t)<(src->width*src->height))  ){

						work=*(b + i+ (s*src->width) + t );
						wk+=*(d +(s+1)*3 +(t+1))*work;


					}
				}}


		*(c+i) = wk;
	}

	//�����
	free(d);
}



/* �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�c <-Ab*/

void matrix_vector_product_new(float *a, float *b, float *c, IplImage* src,  float *SR_ex, float *SR_ey)
{
	float wk=0;
	int i,  s, t;

	float work;

	//�G�b�W�̕������聙
	float ed_x0=0,ed_y0=0;
	float ed_x=0,ed_y=0;
	double ed[2],max_ed=0;
	double ed_sum=0.0;//���̊֐����ł͑��a�ł͂Ȃ���Βl
	double psf_sum=0;
	double in_pro=0;//���ϒl
	int k=0,ed_num=2;
	float *d=(float*)calloc(121,sizeof(float));

	for ( i = 0; i < N_gen; i++)
	{

				//�G�b�W�̕������聙
				//��������
				ed_x=0;ed_y=0;
				for(k=0;k<9;k++){*(d+k)=0;}


				//��𑜂̃G�b�W�f�[�^�𗘗p����ꍇ
				if( (*(SR_ex+i)!=0)||(*(SR_ey+i)!=0) ){
						ed_x=*(SR_ex+i);
						ed_y=*(SR_ey+i);

					//4�����x�N�g���Ƃ̓���
					ed[0]=(double)ed_x;
					ed[1]=(double)ed_y;

					//�x�N�g���̐�Βl
					ed_sum=(double)sqrt((double)((ed_x*ed_x)+(ed_y*ed_y)));

					//���K��
					ed[0]/=ed_sum;
					ed[1]/=ed_sum;

				}
/*				else{
					//���𑜂���x,y�����G�b�W�̉��Z
					for(s=-3;s<4;s++){
					for(t=-3;t<4;t++){
						if( ((i + (s*src->width) + t)>=0)&&((i + ((s+1)*src->width) + t)<(src->width*src->height))&&
							(*(b + i+ (s*src->width) + t+1 )>0)&&(*(b + i+ (s*src->width) + t )>0)&&(*(b + i+ ((s+1)*src->width) + t+1 )>0)){	

								ed_x0=*(b + i+ (s*src->width) + t+1 ) - *(b + i+ (s*src->width) + t );
								ed_y0=*(b + i+ ((s+1)*src->width) + t ) - *(b + i+ (s*src->width) + t );

								//�G�b�W�ш�̐���
								if( (ed_x0<50)&&(ed_x0>-50)&&(ed_y0<50)&&(ed_y0>-50)){
									ed_x+=ed_x0;
									ed_y+=ed_y0;
								}
						}
					}}

					//4�����x�N�g���Ƃ̓���
					ed[0]=(double)ed_x;
					ed[1]=(double)ed_y;

					//�x�N�g���̐�Βl
					ed_sum=(double)sqrt((double)((ed_x*ed_x)+(ed_y*ed_y)));

						if(ed_sum>0){
						//���K��
						ed[0]/=ed_sum;
						ed[1]/=ed_sum;
						}
				}

*/
					//�����G�b�W�������
					if(ed_sum>0){
						//�G�b�W�����Ɠ��όv�Z�Ƒ��a
						psf_sum=0;
						for(s=-5;s<6;s++){
							for(t=-5;t<6;t++){

								if((s!=0)||(t!=0)){	
									in_pro=(s*ed[0]+t*ed[1])/(double)sqrt((double)(s*s+t*t));
									psf_sum+=*(a +(s+5)*11 +(t+5))*(double)sqrt(in_pro*in_pro);
								}
						}}
						psf_sum+=*(a +(s+0)*11 +(t+0));

						//�G�b�W�����Ɠ��όv�Z
						for(s=-5;s<6;s++){
							for(t=-5;t<6;t++){

								if((s!=0)||(t!=0)){	

									in_pro=(s*ed[0]+t*ed[1])/(double)sqrt((double)(s*s+t*t));
									*(d +(s+5)*11 +(t+5))=(*(a +(s+5)*11 +(t+5))*(double)sqrt(in_pro*in_pro))/psf_sum;
								}
						}}
					}
					else{
						for(k=0;k<121;k++){
							*(d+k)=*(a+k);
						}
					}



		wk = 0.0;
		for(s=-5;s<6;s++){
			for(t=-5;t<6;t++){

					if( ((i + (s*src->width) + t)>=0)&&((i + (s*src->width) + t)<(src->width*src->height))  ){

						work=*(b + i+ (s*src->width) + t );
						wk+=*(d +(s+5)*11 +(t+5))*work;


					}
				}}


		*(c+i) = wk;
	}

	//�����
	free(d);
}



int double_comp( const void *s1 , const void *s2 )
{
	const double a1 = *((double *)s1); /* (double *)�փL���X�g*/
	const double a2 = *((double *)s2); /* (double *)�փL���X�g*/		

	if( a1 < a2 )
	{
		return -1;
	}
	else if( a1 == a2 )
	{
		return 0;
	}
	else
	{
		return 1;
	}
}



// A�x�N�g��a[0,...,N-1]��b[0,...,N-1]�̓��ς��v�Z����
float inner_product(float *a, float *b)
{
	int i;
	float s = 0.0;

	for( i= 0; i< N_gen; i++) s += (*(a+i)*(*(b+i)));
		return s ;
	}


// 1�m�����̌v�Za[0,...,N-1]
float vector_norm1( float *a)
{
	int i;
	float norm = 0.0;
	for ( i = 0; i < N_gen; i++ )
	{
		norm += fabs(*(a+i));
	}
	return norm;
}






// A�x�N�g��a[0,...,N-1]��b[0,...,N-1]�̓��ς��v�Z����
float inner_product_all(float *a, float *b, IplImage *reg_src)
{
	int i;
	float s = 0.0;

	for( i= 0; i< (reg_src->width*reg_src->height*36); i++) s += (*(a+i)*(*(b+i)));
		return s ;
	}




// 1�m�����̌v�Za[0,...,N-1]
float vector_norm1_all( float *a , IplImage *reg_src)
{
	int i;
	float norm = 0.0;
	for ( i = 0; i < (reg_src->width*reg_src->height*36); i++ )
	{
		norm += fabs(*(a+i));
	}
	return norm;
}





void subst_f(float *a, float *b, float *c,int num, float flag){

	int i=0;

	if(flag==-1){

		#pragma omp parallel for
		for( i = 0; i < num; i++)
		{
				*(c+i) = *(a+i) -*(b+i) ;
		}
	}else if(flag==1){
		#pragma omp parallel for
		for( i = 0; i < num; i++)
		{
				*(c+i) = *(a+i) +*(b+i) ;
		}
	}else{
		#pragma omp parallel for
		for( i = 0; i < num; i++)
		{
				*(c+i) = *(a+i) +*(b+i)*flag ;
		}
	}

}



//�P���x�C���[���
void bayer_simple_implementation(IplImage *src,IplImage *pImgT100_dammy,IplImage *pImgT100_dammyB,IplImage *pImgT100_dammyR){


	int cou1,cou2,i,j;
	ushort value=0;

	#pragma omp parallel for private(cou1,cou2,j)				//���񉻁�
	for(i=1;i<src->height-1;i++){

			cou1=i*src->widthStep;
			cou2=i*pImgT100_dammy->widthStep;

			for(j=1;j<src->width-1;j++){

				cou1+=3;
				cou2+=1;

				if(0==(uchar)src->imageData[cou1+1]){ //src��G������0�������ꍇ

								pImgT100_dammy->imageData[cou2]=
								((uchar)src->imageData[cou1	+3 + 1]+
								(uchar)src->imageData[cou1	-3 + 1]+
								(uchar)src->imageData[cou1+src->widthStep	+1]+
								(uchar)src->imageData[cou1-src->widthStep	+1])/4;
				}else{												//src��G������0�łȂ��ꍇ

								pImgT100_dammy->imageData[cou2]=
							   ((uchar)src->imageData[cou1	-src->widthStep	-3 +1]+
								(uchar)src->imageData[cou1	-src->widthStep	+3 +1]+
								(uchar)src->imageData[cou1	+src->widthStep	-3 +1]+
								(uchar)src->imageData[cou1	+src->widthStep	+3 +1]+
								4*(uchar)src->imageData[cou1 +1 ])/8;

				}



			}
	}

	//B-plane�ɂ���
	#pragma omp parallel for private(cou1,cou2,j)				//���񉻁�
	for(i=1;i<src->height-1;i++){

			cou1=i*src->widthStep;
			cou2=i*pImgT100_dammy->widthStep;

			for(j=1;j<src->width-1;j++){

				cou1+=3;
				cou2+=1;

				//�P����ԃo�[�W����
				if(0!=(uchar)src->imageData[cou1+0]){//B��f�̏ꍇ
					pImgT100_dammyB->imageData[cou2]=
						(uchar)src->imageData[cou1 + 0];

				}else if(0==(uchar)src->imageData[cou1+0]&&
				   0!=(uchar)src->imageData[cou1+2]
					){												//R��f�̏ꍇ(4������B�ŕ��������)
					pImgT100_dammyB->imageData[cou2]=
								((uchar)src->imageData[cou1-src->widthStep	+3 + 0]+
								(uchar)src->imageData[cou1-src->widthStep	-3 + 0]+
								(uchar)src->imageData[cou1+src->widthStep	+3 + 0]+
								(uchar)src->imageData[cou1+src->widthStep	-3 + 0])/4;
				}else if(0==(uchar)src->imageData[cou1+0]&&	//G��f�ŉE����B��f�̏ꍇ
						 0!=(uchar)src->imageData[cou1+1]&&
						 0!=(uchar)src->imageData[cou1-3+0]
					){
				pImgT100_dammyB->imageData[cou2]=
								((uchar)src->imageData[cou1	-3 +0]+
								(uchar)src->imageData[cou1	+3 +0])/2;
				}else{														//G��f�ŏ㉺��B��f�̏ꍇ
				pImgT100_dammyB->imageData[cou2]=
								((uchar)src->imageData[cou1	-src->widthStep +0]+
								(uchar)src->imageData[cou1	+src->widthStep +0])/2;
				}

		}
	}

	//R-plane�ɂ���
	#pragma omp parallel for private(cou1,cou2,j)				//���񉻁�
	for(i=1;i<src->height-1;i++){

			cou1=i*src->widthStep;
			cou2=i*pImgT100_dammy->widthStep;

			for(j=1;j<src->width-1;j++){

				cou1+=3;
				cou2+=1;


				//�P����ԃo�[�W����
				if(0!=(uchar)src->imageData[cou1+2]){	//R��f�̏ꍇ
					pImgT100_dammyR->imageData[cou2]=
						(uchar)src->imageData[cou1 + 2];

				}else if(0==(uchar)src->imageData[cou1+2]&&
				   0!=(uchar)src->imageData[cou1+0]
					){													//B��f�̏ꍇ
				pImgT100_dammyR->imageData[cou2]=
								((uchar)src->imageData[cou1	-src->widthStep	+3 + 2]+
								(uchar)src->imageData[cou1	-src->widthStep	-3 + 2]+
								(uchar)src->imageData[cou1	+src->widthStep	+3 +2]+
								(uchar)src->imageData[cou1	+src->widthStep	-3 +2])/4;
				}else if(0==(uchar)src->imageData[cou1+2]&&	//G��f�ŉE����R��f�̏ꍇ
						 0!=(uchar)src->imageData[cou1+1]&&
						 0!=(uchar)src->imageData[cou1-3+2]
					){
				pImgT100_dammyR->imageData[cou2]=
								((uchar)src->imageData[cou1	-3 +2]+
								(uchar)src->imageData[cou1	+3 +2])/2;
				}else{														//G��f�ŏ㉺��R��f�̏ꍇ
				pImgT100_dammyR->imageData[cou2]=
								((uchar)src->imageData[cou1	-src->widthStep +2]+
								(uchar)src->imageData[cou1	+src->widthStep +2])/2;
				}
			}
	}

}
