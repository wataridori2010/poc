
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include <math.h>
#include <tchar.h>
#include <time.h>



//#include <omp.h>

#ifdef _OPENMP
#ifdef _DEBUG
#undef _DEBUG
#include <omp.h>
#define _DEBUG
#else
#include <omp.h>
#endif
#endif

#ifdef _OPENMP
#ifdef _DEBUG
#undef _DEBUG
#pragma comment(lib,"vcompd.lib")
#define _DEBUG
#else
#pragma comment(lib,"vcomp.lib")
#endif
#endif


#include "ITO_Mapping.h"





//#define output_movie//�ʒu���킹����o�͂��邩�ǂ���

#define omp_exe//activate OpenMP


/*
20110420 A.Kawai
���͉摜�ɉ������}�N����`��I������悤�ɏC���B
�܂�raw2image_file16()�̊ۂ߃r�b�g�V�t�g�ʂ��}�N���ɂ����B
���͉摜
DragonFly2 16bitRAW : ���g���G���f�B�A����l��12bit(?)�œǍ���A
					�@8bit�E�V�t�g����8bit�Ɋۂ߂�B
DragonFly2  8bitRAW : 8bit�����̂܂ܓǂݍ��ށB
Kteam4Kx2K10bit�k��Bayer(�ɓ�����쐬�摜)
					: �r�b�O�G���f�B�A����l��12bit�i�����Ǝ��ۂ��قȂ�j��Ǎ���A
					�@8bit�E�V�t�g����8bit�Ɋۂ߂�B
Kteam4Kx2K12bit�k��Bayer(�͍��쐬)
					: �r�b�O�G���f�B�A�����l��12bit�œǍ���AWB,���ϊ�����������
					�@4bit�E�V�t�g����8bit�Ɋۂ߂�B

�ȉ��̃}�N����`�ɂ��ݒ��؂�ւ���B
�A���S������_�ɓ����M��_0410.doc
	[DragonFly2��16bitRAW����������ꍇ]				���@DRAGONFLY2��
	[DragonFly2��8bitRAW����������ꍇ]					���@DRAGONFLY2
	[Kteam��4K2K�摜��10bit�k��Bayer����������ꍇ]		���@KTEAM4K2K_SHRINKEDBAYER_ITO

	Kteam��4K2K�摜����͍��쐬�̉�f���Z�k��Bayer�摜	���@KTEAM4K2K_SHRINKEDBAYER_KAWAI
*/
//#define DRAGONFLY2
//#define KTEAM4K2K_SHRINKEDBAYER_ITO
//#define KTEAM4K2K_SHRINKEDBAYER_KAWAI

#define BITSHIFT_FOR_8BIT_ROUNDING 8 //�S�Ăɋ���
#ifdef DRAGONFLY2
#define DATAFORMAT "Dragonfly2"
#define Mac //�o�C�g����IBM PC(B)
#undef GammaFlag //���ϊ����Ȃ�
#endif
#ifdef KTEAM4K2K_SHRINKEDBAYER_ITO
#define DATAFORMAT "KTeam4K2K ShrinkedBayer by Ito"
#define IBM //�o�C�g����Mac(M)
#define GammaFlag //�K���}2.0�̃K���}�ϊ�
#define BITSHIFT_FOR_GAMMA 8
//#define BITSHIFT_FOR_8BIT_ROUNDING 8 //�S�Ăɋ���
#endif
#ifdef KTEAM4K2K_SHRINKEDBAYER_KAWAI
#define DATAFORMAT "KTeam4K2K ShrinkedBayer by Kawai"
#define Mac //�o�C�g����IBM PC(B)
#define GammaFlag //�K���}2.0�̃K���}�ϊ�
#define BITSHIFT_FOR_GAMMA 4 //��l��12bit�Ɠ������������邽��
//#define BITSHIFT_FOR_8BIT_ROUNDING 8 //�S�Ăɋ���
#endif
//�����ȊO�Ŏg�p���Ȃ��B
#undef DRAGONFLY2
#undef KTEAM4K2K_SHRINKEDBAYER_ITO
#undef KTEAM4K2K_SHRINKEDBAYER_KAWAI
//#define DEBUG_KAWAI
#ifdef DEBUG_KAWAI
#define J_PIXEL 2
#define I_PIXEL 2
#endif


//#define Rhead //Bayer�̐擪��f��R
#define Ghead //Bayer�̐擪��f��B  ���@�ԈႢ? Gb������
//#define Bhead //Bayer�̐擪��f��B

#define evishiga //�Ή��Ԃŕ�Ԃ����摜���ʒu���킹�ɗp����ꍇ

//WB�Q�C��
ushort R_GAIN=275;//�y��c���񂪋����Ă��ꂽ���c
ushort G_GAIN=256;//�y��c���񂪋����Ă��ꂽ���c
ushort B_GAIN=460;//�y��c���񂪋����Ă��ꂽ���c

uchar regist_th=100;//�ʒu���킹臒l//���i��200,bayer���ƈÂ�����100���炢?




int times;//�摜�����{���邩
//�摜�̉��c
ushort VGA_width;
ushort VGA_height;
float normp;//=8172.0;
int bits=2;


int main(int argc, char **argv)
{  
	//���摜(�t�@�C����)�ւ̃p�X, �����t�@�C����, �X�L�b�v��, 
	if(argc<6){ fprintf(stderr,"input param error\n", argv[0]);	exit(1);}


	char *status;
	int i,j,k, counts,corner_count = 12*16;//1000;
	int s=0,t=0,x=0,y=0,cou1,cou2;

	CvTermCriteria criteria;
	IplImage *src;
	IplImage *src_g;
	IplImage *dst_img;
	IplImage *pImgT100_dammy,*pImgT100_dammyB,*pImgT100_dammyR;
	IplImage *eig_img, *temp_img;  
	IplImage *prev_pyramid, *curr_pyramid;
	IplImage *SR_color,*SR_color_b,*SR_color_g,*SR_color_r;
	IplImage *SR_color_hokan;


	IplImage *ini_color,*ini_color_cubic;
	IplImage *ini_color_B,*ini_color_G,*ini_color_R;



//	float *er_image1,*er_counts;
	IplImage *SR_hukugen2;


	IplImage* edgex = 0;	   // 
	IplImage* edgey = 0;	   // 
	IplImage* edgex2= 0;	   // 
	IplImage* edgey2= 0;	   // 


	IplImage* conv;


	IplImage *ishiga_image_up,*ishiga_image,*ishiga_image_wo;


	char arg1[512];
	strcpy(arg1,argv[1]);

	int name_count=0;
	char name_ad[512];
	char name_file[512];
	char *name_test;


//	CvPoint2D32f *corners3=(CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
//	CvPoint2D32f *corners4=(CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));

	float *SR_g1,*SR_g2,*SR_g3;

	float* SR_counts = 0;// ���𑜉摜4�{��
	float* SR_counts_g1 = 0;//��f������
	float* SR_counts_g2 = 0;//��f������
	float* SR_counts_g3 = 0;//��f������

	float *x2=(float*)calloc(1,sizeof(float));
	float *y2=(float*)calloc(1,sizeof(float));
	float* a=(float*)calloc(81,sizeof(float));

	//a�̑����1�����̃K�E�V�A���t�B���^
	float* a_line=(float*)calloc(7,sizeof(float));



	//��
	IplImage* pGradIx = 0;	   // Gradient of I in X direction.
	IplImage* pGradIy = 0;	   // Gradient of I in Y direction.

	//����������
	IplImage* pGradTx;
	IplImage* pGradTy;
	IplImage* pGradTx100;
	IplImage* pGradTy100;
	IplImage* pGradTx50;
	IplImage* pGradTy50;
	IplImage* pGradTx25;
	IplImage* pGradTy25;
	IplImage* pGradTx12;
	IplImage* pGradTy12;
	IplImage* pGradTx6;
	IplImage* pGradTy6;
	IplImage* pMStDesc100;
	IplImage* pMStDesc50;
	IplImage* pMStDesc25;
	IplImage* pMStDesc12;
	IplImage* pMStDesc6;



	short* w_param25=(short*)calloc(192,sizeof(short));
	short* w_param50=(short*)calloc(192,sizeof(short));
	short* w_param100=(short*)calloc(192,sizeof(short));
	CvMat** iH25_temp;	//pointer pointer of Matrix
	CvMat** iH50_temp;	//pointer pointer of Matrix
	CvMat** iH100_temp;	//pointer pointer of Matrix
	iH25_temp = (CvMat **) cvAlloc (sizeof (CvMat *) * 192);
	iH50_temp = (CvMat **) cvAlloc (sizeof (CvMat *) * 192);
	iH100_temp= (CvMat **) cvAlloc (sizeof (CvMat *) * 192);

	for(int i=0;i<192; i++){
		iH25_temp[i] = cvCreateMat(2, 2, CV_32F);
		iH50_temp[i] = cvCreateMat(2, 2, CV_32F);
		iH100_temp[i] = cvCreateMat(3, 3, CV_32F);
	}



#ifndef omp_exe
	// Here we will store matrices.
	CvMat* W = 0;  // Current value of warp W(x,p)
	CvMat* iW = 0;  // Current value of warp W(x,p)//��
	CvMat* P = 0;  // Current value of warp W(x,p)//��
	CvMat* X = 0;  // Point in coordinate frame of T.
	CvMat* Z = 0;  // Point in coordinate frame of I.
	CvMat* dW =0;
	CvMat* idW=0;


	CvMat* H = 0;  // Hessian
	CvMat* iH = 0; // Inverse of Hessian
	CvMat* b = 0;  // Vector in the right side of the system of linear equations.
	CvMat* delta_p = 0; // Parameter update value.
	
	// Create matrices.
	W =  cvCreateMat(3, 3, CV_32F);
	iW = cvCreateMat(3, 3, CV_32F);//��
	P  = cvCreateMat(3, 1, CV_32F);//��
	X =  cvCreateMat(3, 1, CV_32F);
	Z =  cvCreateMat(3, 1, CV_32F);

	dW =  cvCreateMat(3, 3, CV_32F);
	idW= cvCreateMat(3, 3, CV_32F);


#ifdef free6
	H = cvCreateMat(6, 6, CV_32F);//������6���R�x�̏ꍇ
	iH = cvCreateMat(6, 6, CV_32F);//������6���R�x�̏ꍇ
	b = cvCreateMat(6, 1, CV_32F);//������6���R�x�̏ꍇ
	delta_p = cvCreateMat(6, 1, CV_32F);//������6���R�x�̏ꍇ
#endif

#ifdef free4
	H = cvCreateMat(4, 4, CV_32F);//������4���R�x�̏ꍇ
	iH = cvCreateMat(4, 4, CV_32F);//������4���R�x�̏ꍇ
	b = cvCreateMat(4, 1, CV_32F);//������4���R�x�̏ꍇ
	delta_p = cvCreateMat(4, 1, CV_32F);//������4���R�x�̏ꍇ
#endif

#ifdef free3
	H = cvCreateMat(3, 3, CV_32F);//������3���R�x�̏ꍇ
	iH = cvCreateMat(3, 3, CV_32F);//������3���R�x�̏ꍇ
	b = cvCreateMat(3, 1, CV_32F);//������3���R�x�̏ꍇ
	delta_p = cvCreateMat(3, 1, CV_32F);//������3���R�x�̏ꍇ
#endif


	//0�o�[�W�����̏ꍇ
	//LK�}�b�`���O�̊֐��Ŏg���̈�ݒ�
	CvMat* W0 = 0;  // Current value of warp W(x,p)
	CvMat* iW0 = 0;  // Current value of warp W(x,p)//��
	CvMat* P0 = 0;  // Current value of warp W(x,p)//��
	CvMat* X0 = 0;  // Point in coordinate frame of T.
	CvMat* Z0 = 0;  // Point in coordinate frame of I.

	CvMat* dW0= 0;  // Point in coordinate frame of T.
	CvMat* idW0= 0;  // Point in coordinate frame of I.

	
	CvMat* H0 = 0;  // Hessian
	CvMat* iH0 = 0; // Inverse of Hessian
	CvMat* b0 = 0;  // Vector in the right side of the system of linear equations.
	CvMat* delta_p0 = 0; // Parameter update value.

	CvPoint2D32f *ppoint,*ppoint_w;
	ppoint   = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
	ppoint_w = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));

	//LK�}�b�`���O�̊֐��Ŏg���̈�ݒ�	
	W0  =  cvCreateMat(3, 3, CV_32F);
	iW0 = cvCreateMat(3, 3, CV_32F)	;
	P0  = cvCreateMat(3, 1, CV_32F)	;
	X0  =  cvCreateMat(3, 1, CV_32F);
	Z0  =  cvCreateMat(3, 1, CV_32F);
	H0  = cvCreateMat(2, 2, CV_32F)	;		
	iH0 = cvCreateMat(2, 2, CV_32F)	;		
	b0  = cvCreateMat(2, 1, CV_32F)	;		
	delta_p0 = cvCreateMat(2, 1, CV_32F);

	dW0  =  cvCreateMat(3, 3, CV_32F);
	idW0 = cvCreateMat(3, 3, CV_32F);
#endif

	int patch_width=0;
	int patch_height=0;

	CvPoint2D32f *corners1, *corners2, *corners3;  
	corners1 = (CvPoint2D32f *) cvAlloc (corner_count * sizeof (CvPoint2D32f));  
	corners2 = (CvPoint2D32f *) cvAlloc (corner_count * sizeof (CvPoint2D32f));  
	corners3 = (CvPoint2D32f *) cvAlloc (corner_count * sizeof (CvPoint2D32f)); 

	CvPoint *corners1_ex,*corners2_ex;
	corners1_ex = (CvPoint *) cvAlloc (corner_count * sizeof (CvPoint));
	corners2_ex = (CvPoint *) cvAlloc (corner_count * sizeof (CvPoint));

	int **cornerx;
	int **cornery;

	IplImage *pImgT100,*pImgT50,*pImgT25;
	IplImage *pImgI100,*pImgI50,*pImgI25;
	IplImage *pGradIx100,*pGradIx50,*pGradIx25;
	IplImage *pGradIy100,*pGradIy50,*pGradIy25;


	//�G�b�W���o�p
	float *ex,*ey,*SR_ex,*SR_ey;
	IplImage *Sub_edge;

	//erroe image
	float* ero_image_f = (float*)calloc(12*16,sizeof(float));
	IplImage* ero_image_small = cvCreateImage(cvSize(16,12), IPL_DEPTH_8U, 1);


	//���e�X�g
	struct regist *regist_all;


#ifdef output_movie
	//������
	//AVI�o��-------------------------------------------------
    CvVideoWriter* VideoWriter = NULL;
    char* filename2 = "G:\\mv.avi";     // �o�̓t�@�C����
    double fps = 15.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------
#endif


	clock_t start_time,start_time2,finish_time,finish_time2;

	start_time = clock();



//Parameter Input
//skipnum
	int skip_num=atoi(argv[2]);
	int skip_counts=0;
//sum of frame
	int sframe=atoi(argv[3]);
//multiply rate
	times=atoi(argv[4]);
//8bit or 16bit?
	int singlebit=atoi(argv[5]);
	normp=1;

	if(singlebit>8){bits=2;}
	else{bits=1;}

//width height
	VGA_width=atoi(argv[7]);
	VGA_height=atoi(argv[8]);





	printf("proc. st.\n");
	printf("input param:%d, %d,	%d,	%d\n",atoi(argv[2]),atoi(argv[3]),atoi(argv[4]),atoi(argv[5]));
	counts=0;


//***********************************************************************************************************//
//***********************************************************************************************************//

	char IMAGE_DIR[512];
	strcpy(IMAGE_DIR,argv[1]);

	src=cvCreateImage(cvSize(VGA_width,VGA_height), IPL_DEPTH_8U, 3);


	//����������
	HANDLE hFind;
	WIN32_FIND_DATA findData={0};//�t�H���_���ꊇ�ǂݍ���
	hFind = FindFirstFile (IMAGE_DIR, &findData);

	//����������
	FILE *fpr;
//	unsigned short *fpregion16=(unsigned short *)calloc(VGA_width*VGA_height,sizeof(ushort));//ushort�̏ꍇ
	unsigned char *fpregion16=(unsigned char *)calloc(VGA_width*VGA_height*2,sizeof(uchar));



	IplImage *t_image,*t_image_c;

	ushort atai=0;
	ushort seco=1;
	ushort bitv=0;

	clock_t read1,read2;

	//����������
	char mosimosi[512];
	strcpy(mosimosi,IMAGE_DIR); strcat(mosimosi,"\\*.raw");  //mosimosi�����t�摜�ւ̃p�X
	hFind = FindFirstFile (mosimosi, &findData);
	if (hFind == INVALID_HANDLE_VALUE){
	}
	else
	{

		//�����ŃX�L�b�v����
	   do
      {
			skip_counts+=1;
		}while (FindNextFile(hFind, &findData) && skip_num > skip_counts);   //�@����{�� // ��	
	


		//�������������
      do
      {
		char filename[512];
		if(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY){
        }else{

	        // �p�X���ɕϊ�
			char filepath[512];

			strcpy(filepath, IMAGE_DIR);
			strcat(filepath, "\\");
			strcat(filepath, findData.cFileName);

			//�����t�@�C���������ۑ�
			if(counts==0){
				strcpy(name_file,findData.cFileName);
			}

			printf("\n\n%s\n",filepath); fflush(stdout);
			fpr=fopen(filepath, "rb");

			//�摜�f�[�^�ǂݍ���
			fread(fpregion16, bits, VGA_width*VGA_height, fpr);
			//src�摜�ւ̑��
			if(bits==2){	raw2image_file16(fpregion16,R_GAIN,G_GAIN,B_GAIN,normp,bits,src);
			}else{			raw2image_file8(fpregion16,R_GAIN,G_GAIN,B_GAIN,normp,bits,src);
			}

			//�����t���[���̓��ʏ���
			if(counts==0){
				//�����t���[����Ή�A���S�ŕۊǂ��邽��
				src_g = cvCreateImage(		cvSize(src->width,src->height), IPL_DEPTH_8U, 1);//�e���v���[�g	
#ifdef evishiga
			}
#endif
				if(bits==2){	raw2image_file16(fpregion16,R_GAIN,G_GAIN,B_GAIN,normp,bits,src_g);
				}else{			raw2image_file8(fpregion16,R_GAIN,G_GAIN,B_GAIN,normp,bits,src_g);
				}




				//�Ή���exe�t�@�C����p������ԏ���
				cvSaveImage("src_g.tif",src_g);


#ifdef Rhead
				system("ishiga.exe 16 R src_g.tif foo.tif");
#endif
#ifdef Ghead
				system("ishiga.exe 16 G src_g.tif foo.tif");
#endif
#ifdef Bhead
				system("ishiga.exe 16 B src_g.tif foo.tif");
#endif


#ifdef evishiga
		if(counts==0){
#endif

		//���͉摜����̊ȈՕ�Ԍ��ʂ𖈃t���[���ۑ����Ă����̈�
		pImgT100_dammy = cvCreateImage(	cvSize(src->width,src->height), IPL_DEPTH_8U, 1);//��ԂŐ��������G��
		pImgT100_dammyB = cvCreateImage(cvSize(src->width,src->height),	IPL_DEPTH_8U, 1);//��ԂŐ��������B��
		pImgT100_dammyR = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);//��ԂŐ��������R��

		//���̏����t���[���̊ȈՕ�ԗ̈�
		ini_color_B = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
		ini_color_G = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
		ini_color_R = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);


		//����Ƃ��ē����x�N�g����`�悷�邽�߂����̗̈�
		#ifdef output_movie
		ini_color = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 3);
		#endif

		//�ʒu���킹���ʂ�ۑ����Ă����̈�(����)
		SR_color = cvCreateImage(	cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 3);

		//�ʒu���킹���ʂ����ԂŐ��������̈�(����)
		SR_color_hokan= cvCreateImage(	cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 3);
		SR_color_b = cvCreateImage(		cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 1);
		SR_color_g = cvCreateImage(		cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 1);
		SR_color_r = cvCreateImage(		cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 1);

		//�ʒu���킹��f�l��F�������ɕۑ����Ă����̈�(����)
		SR_g1 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));
		SR_g2 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));
		SR_g3 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));

		//�ʒu���킹��f�l�̏d�ݕt���J�E���g�񐔂�ۑ����Ă����̈�(����)
		SR_counts =(float*)calloc(		src->width*times*src->height*times,sizeof(float));
		SR_counts_g1 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));
		SR_counts_g2 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));
		SR_counts_g3 =(float*)calloc(	src->width*times*src->height*times,sizeof(float));


		//�ʒu���킹�ŕ�������e�u���b�N���W������
		for(i=0;i<12;i++){
			for(j=0;j<16;j++){
					corners1[i*16+j].x = (int)(((j*src->width)/16.0) + (src->width/32.0));
					corners1[i*16+j].y = (int)(((i*src->height)/12.0) + (src->height/24.0));			
		}}

		//��������u���b�N�T�C�Y�̔����̒l(�c���Ƃ�)������
		patch_width	=(int)(src->width/32.0);
		patch_height=(int)(src->height/24.0);


		pImgT100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
		pImgT50  = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_8U, 1);
		pImgT25  = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_8U, 1);

		pImgI100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
		pGradIx100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_16S, 1);
		pGradIy100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_16S, 1);

		pImgI50  = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_8U, 1);
		pGradIx50 = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_16S, 1);
		pGradIy50 = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_16S, 1);

		pImgI25  = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_8U, 1);
		pGradIx25 = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_16S, 1);
		pGradIy25 = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_16S, 1);

		//����������
		pGradTx100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_16S, 1);
		pGradTy100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_16S, 1);
		pGradTx50 = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_16S, 1);
		pGradTy50 = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_16S, 1);
		pGradTx25 = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_16S, 1);
		pGradTy25 = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_16S, 1);

		pMStDesc100 = cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_32F, 2);
		pMStDesc50 = cvCreateImage(cvSize((int)(src->width/2),(int)(src->height/2)), IPL_DEPTH_32F, 2);
		pMStDesc25 = cvCreateImage(cvSize((int)(src->width/4),(int)(src->height/4)), IPL_DEPTH_32F, 2);

		printf("aa\n");
	}






	if(counts==0){
		//1����ԉ摜�̍쐬
		printf("\nmaking foo.tif..\n");

		printf("intput foo.tif\n");
		ishiga_image	=cvLoadImage("foo.tif");


		ishiga_image_wo	=cvCreateImage(cvSize(src->width*times,src->height*times), IPL_DEPTH_8U, 3);


		cvResize(ishiga_image,ishiga_image_wo,CV_INTER_CUBIC);//�o�C�L���[�r�b�N�g��
		ishiga_image_up=cvCloneImage(ishiga_image_wo);

		//�Ή���&�L���[�r�b�N�g��Ƃ̎����̏����̈ʒu���꒲��
		int address1;
		int address2;

		for(i=5;i<ishiga_image_up->height;i++){
			for(j=0;j<ishiga_image_up->width;j++){
				address1=(i-(times-1))*ishiga_image_up->widthStep+3*(j+0);
				address2=(i+0)*ishiga_image_wo->widthStep+3*(j+0);

				ishiga_image_up->imageData[address1+0]=(uchar)ishiga_image_wo->imageData[address2+0];
				ishiga_image_up->imageData[address1+1]=(uchar)ishiga_image_wo->imageData[address2+1];
				ishiga_image_up->imageData[address1+2]=(uchar)ishiga_image_wo->imageData[address2+2];
		}}

		cvReleaseImage(&ishiga_image_wo);
	}



//�����������x�C���[����
//�x�C���[�ɑΉ�����������(3�F�������ꍇ��G�ňʒu���킹)
	//���`���
	bayer_simple_implementation(src,pImgT100_dammy,pImgT100_dammyB,pImgT100_dammyR);

#ifdef output_movie
	//�x�C���[��Ԃ����J���[�l�̓���
	#pragma omp parallel for private(cou1,cou2,j)				//���񉻁�
	for(i=1;i<pImgT100->height-1;i++){

			cou1=i*src->widthStep;
			cou2=i*pImgT100->widthStep;

			for(j=1;j<pImgT100->width-1;j++){

				cou1+=3;
				cou2+=1;

				ini_color->imageData[cou1+0]=(uchar)pImgT100_dammyB->imageData[cou2];
				ini_color->imageData[cou1+1]=(uchar)pImgT100_dammy->imageData[cou2];
				ini_color->imageData[cou1+2]=(uchar)pImgT100_dammyR->imageData[cou2];
		}}
#endif



	//�����t���[���̂ݕۑ�
	if(counts==0){
		cvCopy(pImgT100_dammyB,ini_color_B);
		cvCopy(pImgT100_dammy ,ini_color_G);
		cvCopy(pImgT100_dammyR,ini_color_R);
	}


#ifdef evishiga
	t_image	=cvLoadImage("foo.tif",0);
	cvSmooth(t_image,pImgT100,CV_BLUR,1,1);//�摜�𕽊���

	t_image_c	=cvLoadImage("foo.tif",1);

#ifdef output_movie
	cvCopy(t_image_c,ini_color);
#endif

	#pragma omp parallel for private(cou1,cou2,j)				//���񉻁�
	for(i=1;i<pImgT100->height-1;i++){

			cou1=i*src->widthStep;
			cou2=i*pImgT100->widthStep;

			for(j=1;j<pImgT100->width-1;j++){

				cou1+=3;
				cou2+=1;

				pImgT100_dammyB->imageData[cou2]=(uchar)t_image_c->imageData[cou1+0];
				pImgT100_dammy->imageData[cou2] =(uchar)t_image_c->imageData[cou1+1];
				pImgT100_dammyR->imageData[cou2]=(uchar)t_image_c->imageData[cou1+2];
		}}
	
	if(counts==0){
		cvCopy(pImgT100_dammyB,ini_color_B);
		cvCopy(pImgT100_dammy ,ini_color_G);
		cvCopy(pImgT100_dammyR,ini_color_R);
	}
#endif



	cvSmooth(pImgT100_dammy, pImgT100_dammy,CV_BLUR,3,3);//�摜�𕽊���
	cvCopy(pImgT100_dammy,pImgT100);//�摜�𕽊���



	//�^�[�Q�b�g����
	cvResize(pImgT100,pImgT50,CV_INTER_LINEAR);
	cvResize(pImgT50,pImgT25,CV_INTER_LINEAR);

	//�^�[�Q�b�g�̃t���T�C�Y�G�b�W�摜
	cvSobel(pImgT100, pGradTx100, 1, 0, -1); // Gradient in X direction
	cvConvertScale(pGradTx100, pGradTx100, 0.042); // Normalize
	cvSobel(pImgT100, pGradTy100, 0, 1, -1); // Gradient in Y direction
	cvConvertScale(pGradTy100, pGradTy100, 0.042); // Normalize

	//�����t���[�����A�^�[�Q�b�g�̒l���R�s�[���ăe���v���[�g�Ƃ���A
	//�܂��A�e���v���[�g��1/2�T�C�Y�A1/4�T�C�Y�̃G�b�W�摜����
	if(counts==0){
		cvCopy(pImgT100,pImgI100);
		cvCopy(pImgT50,pImgI50);
		cvCopy(pImgT25,pImgI25);
		cvCopy(pGradTx100,pGradIx100);
		cvCopy(pGradTy100,pGradIy100);

		cvSobel(pImgI50, pGradIx50, 1, 0, -1); // Gradient in X direction
		cvConvertScale(pGradIx50, pGradIx50, 0.042); // Normalize
		cvSobel(pImgI50, pGradIy50, 0, 1, -1); // Gradient in Y direction
		cvConvertScale(pGradIy50, pGradIy50, 0.042); // Normalize

		cvSobel(pImgI25, pGradIx25, 1, 0, -1); // Gradient in X direction
		cvConvertScale(pGradIx25, pGradIx25, 0.042); // Normalize
		cvSobel(pImgI25, pGradIy25, 0, 1, -1); // Gradient in Y direction
		cvConvertScale(pGradIy25, pGradIy25, 0.042); // Normalize
	}




	//�s���~�b�h�ňʒu���킹
	CvRect omega2; 		//���񉻂̂��߂̒�`��
	//���ǉ�0301
	int endx=0;
	int endy=0;
	int inpx=0;
	int inpy=0;

	int numc;


	//3�K�w��(1/4�T�C�Y�ł�2���ł̈ʒu���킹)
	#pragma omp parallel for private(inpx,inpy,endx,endy,omega2,numc)//,ppoint,ppoint_w)		//���񉻁�
	for(i=0;i<12;i=i+4){
		for(j=0;j<16;j=j+4){

			numc=16*i+j;

#ifdef omp_exe
		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvMat* W0 = 0;  // Current value of warp W(x,p)
		CvMat* iW0 = 0;  // Current value of warp W(x,p)//��
		CvMat* P0 = 0;  // Current value of warp W(x,p)//��
		CvMat* X0 = 0;  // Point in coordinate frame of T.
		CvMat* Z0 = 0;  // Point in coordinate frame of I.
		CvMat* dW0= 0;  // Point in coordinate frame of T.
		CvMat* idW0= 0;  // Point in coordinate frame of I.
		CvMat* H0 = 0;  // Hessian
		CvMat* iH0 = 0; // Inverse of Hessian
		CvMat* b0 = 0;  // Vector in the right side of the system of linear equations.
		CvMat* delta_p0 = 0; // Parameter update value.
		W0  = cvCreateMat(3, 3, CV_32F);
		iW0 = cvCreateMat(3, 3, CV_32F)	;
		P0  = cvCreateMat(3, 1, CV_32F)	;
		X0  = cvCreateMat(3, 1, CV_32F);
		Z0  = cvCreateMat(3, 1, CV_32F);
		dW0 = cvCreateMat(3, 3, CV_32F);
		idW0= cvCreateMat(3, 3, CV_32F);
		H0  = cvCreateMat(2, 2, CV_32F)	;	
		iH0 = cvCreateMat(2, 2, CV_32F)	;		
		b0  = cvCreateMat(2, 1, CV_32F)	;		
		delta_p0 = cvCreateMat(2, 1, CV_32F);
		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvPoint2D32f *ppoint;
		CvPoint2D32f *ppoint_w;
		ppoint   = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
		ppoint_w = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
#endif


		CvRect omega;
		//�e�R�[�i�[�_���ɁA��𑜂���}�b�`���O
		ppoint[0].x=0;		ppoint[0].y=0;
		ppoint_w[0].x=0;	ppoint_w[0].y=0;
		float error=0;

		if((corners1[numc].x/4)<patch_width)	{inpx=patch_width;}	else{inpx=corners1[numc].x/4;}
		if((corners1[numc].y/4)<patch_height)	{inpy=patch_height;}else{inpy=corners1[numc].y/4;}
		if( pImgT25->width<(inpx+patch_width+1))	{endx=pImgT25->width;}	else{endx=inpx+patch_width+1;}//���ǉ�0301
		if( pImgT25->height<(inpy+patch_height+1))	{endy=pImgT25->height;}	else{endy=inpy+patch_height+1;}//���ǉ�0301
		omega = cvRect((inpx - patch_width), (inpy - patch_height), endx-(inpx - patch_width), endy-(inpy - patch_height));//���ǉ�0301
//		ppoint[0].x=2*(ppoint_w[0].x); ppoint[0].y=2*(ppoint_w[0].y);//�������W�̍X�V
		ppoint[0].x=0; ppoint[0].y=0;//�������W�̍X�V

//LK
		ppoint_w=LK_registration_FA0(pImgT25, omega, pImgI25,pGradIx25, pGradIy25,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0);
//IC
//		ppoint_w=LK_registration_IC0(pImgT25, omega, pImgI25,pGradIx25, pGradIy25,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0,pMStDesc25,dW0,idW0);

		corners3[numc].x=ppoint_w[0].x;
		corners3[numc].y=ppoint_w[0].y;

		corners3[numc+2].x=corners3[numc].x;	corners3[numc+2].y=corners3[numc].y;
		corners3[numc+32].x=corners3[numc].x;	corners3[numc+32].y=corners3[numc].y;
		corners3[numc+34].x=corners3[numc].x;	corners3[numc+34].y=corners3[numc].y;

#ifdef omp_exe
		cvReleaseMat(&W0);cvReleaseMat(&iW0);cvReleaseMat(&P0);cvReleaseMat(&X0);
		cvReleaseMat(&Z0);cvReleaseMat(&H0);cvReleaseMat(&iH0);cvReleaseMat(&b0);
		cvReleaseMat(&delta_p0);cvReleaseMat(&dW0);cvReleaseMat(&idW0);
#endif
		}
	}



	//2�K�w��(1/1 or 1/2�T�C�Y�ł�2���ł̈ʒu���킹)
	#pragma omp parallel for private(inpx,inpy,endx,endy,omega2,numc)//,ppoint,ppoint_w)		//���񉻁�
	for(i=0;i<12;i=i+2){
		for(j=0;j<16;j=j+2){

			numc=16*i+j;

#ifdef omp_exe
		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvMat* W0 = 0;  // Current value of warp W(x,p)
		CvMat* iW0 = 0;  // Current value of warp W(x,p)//��
		CvMat* P0 = 0;  // Current value of warp W(x,p)//��
		CvMat* X0 = 0;  // Point in coordinate frame of T.
		CvMat* Z0 = 0;  // Point in coordinate frame of I.
		CvMat* dW0= 0;  // Point in coordinate frame of T.
		CvMat* idW0= 0;  // Point in coordinate frame of I.
		CvMat* H0 = 0;  // Hessian
		CvMat* iH0 = 0; // Inverse of Hessian
		CvMat* b0 = 0;  // Vector in the right side of the system of linear equations.
		CvMat* delta_p0 = 0; // Parameter update value.
		W0  =  cvCreateMat(3, 3, CV_32F);
		iW0 = cvCreateMat(3, 3, CV_32F)	;
		P0  = cvCreateMat(3, 1, CV_32F)	;
		X0  =  cvCreateMat(3, 1, CV_32F);
		Z0  =  cvCreateMat(3, 1, CV_32F);
		dW0 = cvCreateMat(3, 3, CV_32F);
		idW0= cvCreateMat(3, 3, CV_32F);
		H0  = cvCreateMat(2, 2, CV_32F)	;		
		iH0 = cvCreateMat(2, 2, CV_32F)	;		
		b0  = cvCreateMat(2, 1, CV_32F)	;		
		delta_p0 = cvCreateMat(2, 1, CV_32F);

		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvPoint2D32f *ppoint;
		CvPoint2D32f *ppoint_w;
		ppoint   = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
		ppoint_w = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
#endif


		CvRect omega;
		//�e�R�[�i�[�_���ɁA��𑜂���}�b�`���O
		ppoint[0].x=0;		ppoint[0].y=0;
		ppoint_w[0].x=0;	ppoint_w[0].y=0;
		float error=0;

/*
		if((corners1[i*16+j].x/2)<patch_width)	{inpx=patch_width;}	else{inpx=corners1[i*16+j].x/2;}
		if((corners1[i*16+j].y/2)<patch_height)	{inpy=patch_height;}else{inpy=corners1[i*16+j].y/2;}
		if( pImgT50->width<(inpx+patch_width+1))	{endx=pImgT50->width;}	else{endx=inpx+patch_width+1;}//���ǉ�0301
		if( pImgT50->height<(inpy+patch_height+1))	{endy=pImgT50->height;}	else{endy=inpy+patch_height+1;}//���ǉ�0301
		omega = cvRect((inpx - patch_width), (inpy - patch_height), endx-(inpx - patch_width), endy-(inpy - patch_height));//���ǉ�0301
//		omega = cvRect((inpx - patch_width), (inpy - patch_height), 2*patch_width+1, 2*patch_height+1);//���R�����g�A�E�g0301
//		ppoint[0].x=2*(ppoint_w[0].x); ppoint[0].y=2*(ppoint_w[0].y);//�������W�̍X�V
		ppoint[0].x=2*(corners3[i*16+j].x); ppoint[0].y=2*(corners3[i*16+j].y);//�������W�̍X�V
//LK
		ppoint_w=LK_registration_FA0(pImgT50, omega, pImgI50,pGradIx50, pGradIy50,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0);
//IC
//		ppoint_w=LK_registration_IC0(pImgT50, omega, pImgI50,pGradTx50, pGradTy50,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0,pMStDesc50,dW0,idW0);
//		if((ppoint_w[0].x>=pImgT50->width)&&(ppoint_w[0].y>=pImgT50->height)){goto match_pass;}//�}�b�`�p�X
*/

		if((corners1[numc].x)<patch_width)	{inpx=patch_width;}	else{inpx=corners1[numc].x;}
		if((corners1[numc].y)<patch_height)	{inpy=patch_height;}else{inpy=corners1[numc].y;}
		if( pImgT100->width<(inpx+patch_width+1))	{endx=pImgT100->width;}	else{endx=inpx+patch_width+1;}//���ǉ�0301
		if( pImgT100->height<(inpy+patch_height+1))	{endy=pImgT100->height;}	else{endy=inpy+patch_height+1;}//���ǉ�0301
		omega = cvRect((inpx - patch_width), (inpy - patch_height), endx-(inpx - patch_width), endy-(inpy - patch_height));//���ǉ�0301
		ppoint[0].x=4*(corners3[numc].x); ppoint[0].y=4*(corners3[numc].y);//�������W�̍X�V
//LK
		ppoint_w=LK_registration_FA0(pImgT100, omega, pImgI100, pGradIx100, pGradIy100,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0);
//IC
//		ppoint_w=LK_registration_IC0(pImgT100, omega, pImgI100,pGradIx100, pGradIy100,ppoint, W0,iW0,P0,X0,Z0,H0,iH0,b0,delta_p0,pMStDesc100,dW0,idW0);

		corners2[numc].x=ppoint_w[0].x;
		corners2[numc].y=ppoint_w[0].y;
		corners2[numc+1].x=corners2[numc].x;	corners2[numc+1].y=corners2[numc].y;
		corners2[numc+16].x=corners2[numc].x;	corners2[numc+16].y=corners2[numc].y;
		corners2[numc+17].x=corners2[numc].x;	corners2[numc+17].y=corners2[numc].y;



#ifdef omp_exe
		cvReleaseMat(&W0);cvReleaseMat(&iW0);cvReleaseMat(&P0);cvReleaseMat(&X0);
		cvReleaseMat(&Z0);cvReleaseMat(&H0);cvReleaseMat(&iH0);cvReleaseMat(&b0);
		cvReleaseMat(&delta_p0);cvReleaseMat(&dW0);cvReleaseMat(&idW0);
#endif

	}}



int minx1=0,miny1=0;
int widx1=0,widy1=0;

	//1�K�w��(1/1�T�C�Y�ł�6���ł̈ʒu���킹)
	#pragma omp parallel for private(inpx,inpy,endx,endy,omega2)//,ppoint,ppoint_w)		//���񉻁�
	for(i=0;i<(12*16);i++){			//�u���b�N�����̏ꍇ������

#ifdef omp_exe
		//W, iW, P, X, Z, H, iH , b,  delta_p
		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvMat* W = 0;  // Current value of warp W(x,p)
		CvMat* iW = 0;  // Current value of warp W(x,p)//��
		CvMat* P = 0;  // Current value of warp W(x,p)//��
		CvMat* X = 0;  // Point in coordinate frame of T.
		CvMat* Z = 0;  // Point in coordinate frame of I.
		CvMat* dW =0;  
		CvMat* idW=0;  

		CvMat* H = 0;  // Hessian
		CvMat* iH = 0; // Inverse of Hessian
		CvMat* b = 0;  // Vector in the right side of the system of linear equations.
		CvMat* delta_p = 0; // Parameter update value.
		W =  cvCreateMat(3, 3, CV_32F);
		iW = cvCreateMat(3, 3, CV_32F);//��
		P  = cvCreateMat(3, 1, CV_32F);//��
		X =  cvCreateMat(3, 1, CV_32F);
		Z =  cvCreateMat(3, 1, CV_32F);
		dW =  cvCreateMat(3, 3, CV_32F);
		idW= cvCreateMat(3, 3, CV_32F);

#ifdef free6
		H = cvCreateMat(6, 6, CV_32F);//������6���R�x�̏ꍇ
		iH = cvCreateMat(6, 6, CV_32F);//������6���R�x�̏ꍇ
		b = cvCreateMat(6, 1, CV_32F);//������6���R�x�̏ꍇ
		delta_p = cvCreateMat(6, 1, CV_32F);//������6���R�x�̏ꍇ
#endif
#ifdef free4
		H = cvCreateMat(4, 4, CV_32F);//������4���R�x�̏ꍇ
		iH = cvCreateMat(4, 4, CV_32F);//������4���R�x�̏ꍇ
		b = cvCreateMat(4, 1, CV_32F);//������4���R�x�̏ꍇ
		delta_p = cvCreateMat(4, 1, CV_32F);//������4���R�x�̏ꍇ
#endif
#ifdef free3
		H = cvCreateMat(3, 3, CV_32F);//������3���R�x�̏ꍇ
		iH = cvCreateMat(3, 3, CV_32F);//������3���R�x�̏ꍇ
		b = cvCreateMat(3, 1, CV_32F);//������3���R�x�̏ꍇ
		delta_p = cvCreateMat(3, 1, CV_32F);//������3���R�x�̏ꍇ
#endif
		//���񉻂̂��߂Ƀ��[�v���Œ�`��
		CvPoint2D32f *ppoint;
		CvPoint2D32f *ppoint_w;
		ppoint   = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
		ppoint_w = (CvPoint2D32f *) cvAlloc (1 * sizeof (CvPoint2D32f));
#endif
		ppoint[0].x=0;		ppoint[0].y=0;
		ppoint_w[0].x=0;	ppoint_w[0].y=0;
		float error=0;


		CvRect omega;
		//�e�R�[�i�[�_���ɁA��𑜂���}�b�`���O
		ppoint[0].x=0;ppoint[0].y=0;

		if((corners1[i].x)<patch_width)	{inpx=patch_width;}	else{inpx=corners1[i].x;}
		if((corners1[i].y)<patch_height){inpy=patch_height;}else{inpy=corners1[i].y;}
		if( pImgT100->width<(inpx+patch_width+1))	{endx=pImgT100->width;}		else{endx=inpx+patch_width+1;}//���ǉ�0301
		if( pImgT100->height<(inpy+patch_height+1))	{endy=pImgT100->height;}	else{endy=inpy+patch_height+1;}//���ǉ�0301
		omega = cvRect((inpx - patch_width), (inpy - patch_height), endx-(inpx - patch_width), endy-(inpy - patch_height));//���ǉ�0301

//		ppoint[0].x=2.0*(corners2[i].x); ppoint[0].y=2.0*(corners2[i].y);//�������W�̍X�V
		ppoint[0].x=1.0*(corners2[i].x); ppoint[0].y=1.0*(corners2[i].y);//�������W�̍X�V


//LK
//		printf("dx,dy%lf,%lf\n",ppoint[0].x,ppoint[0].y);
		error=LK_registration_FA(pImgI100, omega, pImgT100, SR_color_g, SR_counts,
							-ppoint[0].x, -ppoint[0].y, pImgT100_dammy,edgex2,edgey2,src,SR_g1,SR_g2,SR_g3, SR_counts_g1, SR_counts_g2, SR_counts_g3,
							 pGradTx100, pGradTy100, W, iW, P, X, Z, H, iH , b,  delta_p,
							 pImgT100_dammyB,pImgT100_dammyR,ini_color_B,ini_color_G,ini_color_R);

		ero_image_f[i]+=(10*error);

#ifdef output_movie
			corners1_ex[i].x=(int)corners1[i].x;
			corners1_ex[i].y=(int)corners1[i].y;
			corners2_ex[i].x=(int)(-ppoint[0].x+corners1[i].x);
			corners2_ex[i].y=(int)(-ppoint[0].y+corners1[i].y);

			//���Ɠ_�̕`��
			cvCircle(ini_color, corners2_ex[i], 1.6, CV_RGB (0, 255, 0), 1.6, 7, 0);
			cvLine (ini_color, corners1_ex[i], corners2_ex[i], CV_RGB (255, 255, 255), 1.2, CV_AA, 0);
#endif


#ifdef omp_exe
		cvReleaseMat(&W);cvReleaseMat(&iW);cvReleaseMat(&P);cvReleaseMat(&X);cvReleaseMat(&Z);
		cvReleaseMat(&dW);cvReleaseMat(&idW);
#ifdef free6
		cvReleaseMat(&H);cvReleaseMat(&iH);cvReleaseMat(&b);cvReleaseMat(&delta_p);
#endif
#endif
	}

#ifdef evishiga
	cvReleaseImage(&t_image);
	cvReleaseImage(&t_image_c);
#endif

	start_time2 = clock();
	finish_time2 = clock();


printf("counts:%d\n",counts);

#ifdef output_movie

	//������
	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename2, -1  , 
    fps , cvSize(ini_color->width,ini_color->height) );
	}
	//AVI��������-------------------------------
		cvWriteFrame(VideoWriter,ini_color);
	// -----------------------------------------
#endif


//	cvWaitKey (10);
	counts+=1;

//������
		}
	}while (FindNextFile(hFind, &findData) && sframe > counts);   //�@����{�� // ��	
	
	CloseHandle (hFind); // ��
}




//***********************************************************************************************************//
//***********************************************************************************************************//

#ifdef output_movie
// �㏈��-----------------------------------
 cvReleaseVideoWriter(&VideoWriter); 
//------------------------------------------
#endif

	printf("Registration fin.\n");

	finish_time = clock();
	double total_time = (double)(finish_time-start_time)/(CLOCKS_PER_SEC);
	double total_time_per = (double)(finish_time-start_time)/(CLOCKS_PER_SEC*sframe);
	double regist_time = (double)(finish_time2-start_time2)/(CLOCKS_PER_SEC);

	printf("registration time:	%lf s,\ntotal time/frame:	%lf s,\n",total_time,total_time_per);
//	fprintf(fk,"%lf,%lf,%lf,",total_time,total_time_per,regist_time);


	//�ʒu���킹�����̂ݎ��Ԍv��
//	fclose(fk);

	cvReleaseImage(&pImgI25); 
	cvReleaseImage(&pGradIx25);
	cvReleaseImage(&pGradIy25);
	cvReleaseImage(&pImgI50); 
	cvReleaseImage(&pGradIx50);
	cvReleaseImage(&pGradIy50);
	cvReleaseImage(&pImgI100); 
	cvReleaseImage(&pGradIx100);
	cvReleaseImage(&pGradIy100);
	cvReleaseImage(&pImgT100);
	cvReleaseImage(&pImgT50);
	cvReleaseImage(&pImgT25);
	cvReleaseImage(&ini_color);
	cvReleaseImage(&ini_color_B);
	cvReleaseImage(&ini_color_G);
	cvReleaseImage(&ini_color_R);

	free(fpregion16);


	//�ʒu���킹�]���l�摜�̐���(���p�t���[�������Ő��K��)
	#pragma omp parallel for 	//�ޕ���
	for(i=0;i<12*16;i++){
		ero_image_small->imageData[i]=uchar(ero_image_f[i]/float(counts));///32.0);
	}

	//�ő�l�̃u���b�N��I�����ďk��
	IplImage* ero_image_small0=cvCreateImage(cvSize(8,6), IPL_DEPTH_8U, 1);
	#pragma omp parallel for 	//�ޕ���
	for(i=0;i<6;i=i+1){
		for(j=0;j<8;j=j+1){
			int ev=0;
			ev=(uchar)ero_image_small->imageData[(2*i+0)*ero_image_small->widthStep+(2*j+0)];
			ero_image_small0->imageData[i*ero_image_small0->widthStep+j]=(uchar)ev;

			ev=(uchar)ero_image_small->imageData[(2*i+0)*ero_image_small->widthStep+(2*j+1)];
			if(ev>(uchar)ero_image_small0->imageData[i*ero_image_small0->widthStep+j]){ero_image_small0->imageData[i*ero_image_small0->widthStep+j]=(uchar)ev;}

			ev=(uchar)ero_image_small->imageData[(2*i+1)*ero_image_small->widthStep+(2*j+0)];
			if(ev>(uchar)ero_image_small0->imageData[i*ero_image_small0->widthStep+j]){ero_image_small0->imageData[i*ero_image_small0->widthStep+j]=(uchar)ev;}

			ev=(uchar)ero_image_small->imageData[(2*i+1)*ero_image_small->widthStep+(2*j+1)];
			if(ev>(uchar)ero_image_small0->imageData[i*ero_image_small0->widthStep+j]){ero_image_small0->imageData[i*ero_image_small0->widthStep+j]=(uchar)ev;}

			//臒l�ȉ���0�Ƃ���
			if(60>(uchar)ero_image_small0->imageData[i*ero_image_small0->widthStep+j]){ero_image_small0->imageData[i*ero_image_small0->widthStep+j]=(uchar)0;}
	}}
	cvResize(ero_image_small0,ero_image_small,CV_INTER_LINEAR);


	//�G���[�l�̍ő�l���擾
	int erm=0;
	for(i=0;i<12*16;i++){
		if(erm<(uchar)ero_image_small->imageData[i]){
			erm=(uchar)ero_image_small->imageData[i];
		}
	}




float vacant=0;


//Save the bicubic interpolation image
	IplImage* ini_color_cubic2;
	ini_color_cubic2=ishiga_image_up;

	char cu_im[512];
	strcpy(cu_im,IMAGE_DIR);strcat(cu_im,"\\");
	strcat(cu_im,"cu_");//strcat(cu_im,name_file);
	char fnm[64];
	sprintf(fnm,"%04d",skip_num);
	strcat(cu_im,fnm);
	strcat(cu_im,".bmp");
	IplImage* ini_color_cubic2_t=cvCloneImage(ini_color_cubic2);
	cvSmooth(ini_color_cubic2_t, ini_color_cubic2_t, CV_GAUSSIAN, 3, 0, 0);
	cvSaveImage(cu_im,ini_color_cubic2_t);


	

//���ω摜�o��
	float g1_value=0;
	float g2_value=0;
	float g3_value=0;
	int row1=0,row2=0,row3=0;

	for(i=0; i<SR_color->height; i++){

		//�ޕ���
		#pragma omp parallel for private(g1_value,g2_value,g3_value)		//���񉻁�
		for(j=0; j<SR_color->width; j++){

			//����������(�F���ɕ��ς����āA�d�ݕt��������)0914�ǉ�
			if(	(*(SR_counts_g1 + row1 + j)> 0)&&(	*(SR_g1 + row1 + j)> 0	)	){
				g1_value=(*(SR_g1 + row1 + j)/(*(SR_counts_g1 + row1 + j)));
				if(g1_value>255){g1_value=255;}else if(g1_value<0){g1_value=0;}
				SR_color->imageData[row2 + (3*j)  ] = (uchar)g1_value;//�ώZ����ꍇ(���ϒl)
				SR_color_b->imageData[row3 + j  ] = (uchar)g1_value;//b��q
			}

			if(	(*(SR_counts_g2 + row1 + j)> 0)&&(*(SR_g2 + row1 + j)> 0)	){
				g2_value=(*(SR_g2 + row1 + j)/(*(SR_counts_g2 + row1 + j)));
				if(g2_value>255){g2_value=255;}else if(g2_value<0){g2_value=0;}
				SR_color->imageData[row2 + (3*j)+1] = (uchar)g2_value;//�ώZ����ꍇ(���ϒl)
				SR_color_g->imageData[row3 + j  ] = (uchar)g2_value;//g��
			}

			if(	(*(SR_counts_g3 + row1 + j)> 0)&&(	*(SR_g3 + row1 + j)> 0	)	){
				g3_value=(*(SR_g3 + row1 + j)/(*(SR_counts_g3 + row1 + j)));
				if(g3_value>255){g3_value=255;}else if(g3_value<0){g3_value=0;}
				SR_color->imageData[row2 + (3*j)+2] = (uchar)g3_value;//�ώZ����ꍇ(���ϒl)
				SR_color_r->imageData[row3 + j  ] = (uchar)g3_value;//r��
			}

		}
		row1+=SR_color->width;
		row2+=SR_color->widthStep;
		row3+=SR_color_b->widthStep;
	}

	//�̈���
	free(SR_g1);
	free(SR_g2);
	free(SR_g3);


//cvSaveImage("G:\\SR_color.bmp",SR_color);
//cvSaveImage("G:\\SR_color_b.bmp",SR_color_b);
//cvSaveImage("G:\\SR_color_g.bmp",SR_color_g);
//cvSaveImage("G:\\SR_color_r.bmp",SR_color_r);


printf("\n");


//�J���[�o��(�K�E�V�A�����)
float sigma=0.20;
int filter_size=1; //3�܂ł̒l
a = gauss_filter0(filter_size,sigma);




//a�̑����1�����t�B���^
a_line = gauss_filter0_line(filter_size,sigma);
//float *SR_work=(float*)calloc(SR_color->width*SR_color->height,sizeof(float));
//int	  *keisuu =(int*)calloc(256,sizeof(int));
	//keisuu�̏�����
//	*(keisuu	+ 0)=0;
//	for(i=1;i<256;i++){
//		*(keisuu	+ i)=1;
//	}



//SR_ex2,SR_ey2�̃G�b�W�֌W
//�����ŃT�u�s�N�Z���G�b�W�f�[�^�̕�Ԃ�����
float *SR_ex2;
float *SR_ey2;


	int image_size=SR_color->width*SR_color->height;
	//SR_counts_g���K�i��
	//�ޕ���
	#pragma omp parallel for	//OMP
	for(int c=0;c<image_size;c++){
		*(SR_counts_g1 +c)=*(SR_counts_g1 +c)/(*(SR_counts +c)+1);
		*(SR_counts_g2 +c)=*(SR_counts_g2 +c)/(*(SR_counts +c)+1);
		*(SR_counts_g3 +c)=*(SR_counts_g3 +c)/(*(SR_counts +c)+1);
	}


	start_time = clock();
	printf("Gaussian Interpolation st.\n");

	//������(09/09)
	IplImage* SR_color_hokan2;
	SR_color_hokan2=cvCloneImage(SR_color_hokan);

	//�K�E�V�A���t�B���^���v���[�����ɂ�����
	gauss_optimize_filter2_2(SR_color_g, a, filter_size, ini_color_cubic2, 1, SR_counts,SR_counts_g2	,SR_color_hokan2);
	gauss_optimize_filter2_2(SR_color_b, a, filter_size, ini_color_cubic2, 0, SR_counts,SR_counts_g1	,SR_color_hokan2);
	gauss_optimize_filter2_2(SR_color_r, a, filter_size, ini_color_cubic2, 2, SR_counts,SR_counts_g3	,SR_color_hokan2);

	//G��f�Ɋ�Â����(G��f�͂����̃K�E�V�A��)
	gauss_optimize_filter2_G_2(SR_color_b,a, filter_size, ini_color_cubic2, 0, SR_counts,SR_counts_g1,SR_color_hokan2	,SR_color_hokan);
	gauss_optimize_filter2_G_2(SR_color_r,a, filter_size, ini_color_cubic2, 2, SR_counts,SR_counts_g3,SR_color_hokan2	,SR_color_hokan);

//���K�E�V�A��_2�p�X���\��
	gauss_optimize_filter2_RB_2(SR_color_g, a, filter_size, ini_color_cubic2, 1, SR_counts,SR_counts_g2,SR_color_hokan2	,SR_color_hokan);

	printf("Gaussian Interpolation fin.\n");
	finish_time = clock();
	total_time = (double)(finish_time-start_time)/(CLOCKS_PER_SEC);
	printf("Interpolation time:	%lf s,\n",total_time);


	//�̈���
	free(SR_counts_g1);
	free(SR_counts_g2);
	free(SR_counts_g3);
	cvReleaseImage(&SR_color_r);
	cvReleaseImage(&SR_color_g);
	cvReleaseImage(&SR_color_b);
	cvReleaseImage(&SR_color_hokan2);
	cvReleaseImage(&pImgT100_dammy);
	cvReleaseImage(&pImgT100_dammyB);
	cvReleaseImage(&pImgT100_dammyR);
	free(SR_counts);


	double hokan_time = (double)(finish_time-start_time)/(CLOCKS_PER_SEC);
	start_time = clock();




//��������
	float* psf=(float*)calloc(121,sizeof(float));
	//�K�E�V�A���J�[�l���̏ꍇ
//	sigma=1.2;//400%
//	sigma=0.9;//300%?
//	sigma=0.6;//200%?
//	sigma=0.3;//100%?
	sigma=0.3*float(times);


	filter_size=5;
	psf = gauss_filter(psf,filter_size,sigma);
	float* laplace=(float*)calloc(9,sizeof(float));
	laplace=laplace_filter0(1);

//cvSaveImage("G:\\SR_color.bmp",SR_color);
//cvSaveImage("G:\\SR_color_hokan.bmp",SR_color_hokan);


//��Ԃ��Ă��Ȃ�SR_color�ɂ��āA�������܂��Ă����f�ɂ��āASR_color_hokan�̂��̂��g���A�Ƃ���B
	#pragma omp parallel for private(j,cou1)
	for(i=0;i<SR_color->height;i++){

		cou1=i*SR_color->widthStep;

		//�ޕ���
//		#pragma omp parallel for
		for(j=0;j<SR_color->width;j++){

			if( 0<(uchar)SR_color->imageData[cou1 +0] ){ SR_color->imageData[cou1 +0]=(uchar)SR_color_hokan->imageData[cou1 +0];}
			if( 0<(uchar)SR_color->imageData[cou1 +1] ){ SR_color->imageData[cou1 +1]=(uchar)SR_color_hokan->imageData[cou1 +1];}
			if( 0<(uchar)SR_color->imageData[cou1 +2] ){ SR_color->imageData[cou1 +2]=(uchar)SR_color_hokan->imageData[cou1 +2];}

			cou1+=3;
	}}

	start_time=clock();
	//�K�E�V�A��2pass���̃t�B���^
	float *a_line2 = (float*)calloc(11,sizeof(float));
	a_line2 = gauss_filter_line(a_line2,filter_size,sigma);




	//Bicubi�g��摜�𕜌�
	//Bicubic�����p�p�����[�^
		//�폜�Ώ�
		cvResize(ishiga_image,ini_color_cubic2,CV_INTER_CUBIC);//�o�C�L���[�r�b�N�g��

		float* psf_Bi=(float*)calloc(121,sizeof(float));
		sigma=1.2;//400%
		filter_size=5;
		psf_Bi = gauss_filter(psf_Bi,filter_size,sigma);
		float* laplace_Bi=(float*)calloc(9,sizeof(float));
		laplace_Bi=laplace_filter0(1);
		//�K�E�V�A��2pass���̃t�B���^
		float *a_line2_Bi = (float*)calloc(11,sizeof(float));
		a_line2_Bi = gauss_filter_line(a_line2_Bi,filter_size,sigma);


	//�����摜���G�b�W����
	ini_color_cubic2=cg_color2_cubic( psf_Bi, laplace_Bi, ini_color_cubic2,	   ini_color_cubic2_t, SR_ex2, SR_ey2, a_line2_Bi); // �ŋ}�~���@(SD�@)
	cvReleaseImage(&ini_color_cubic2_t);


	//�ʒu���킹�摜���畜��
	SR_color_hokan=cg_color2( psf, laplace, SR_color,	   SR_color_hokan, SR_ex2, SR_ey2, a_line2); // �ŋ}�~���@(SD�@)///��𑜂̃G�b�W���p

	printf("Reconstruction fin.\n");

	finish_time = clock();
	total_time = (double)(finish_time-start_time)/(CLOCKS_PER_SEC);
	printf("Reconstruction time:	%lf s,\n",total_time);






//�G���[�l�摜�Ɋ�Â��揈��
	//Detect maximum value of error
	ushort er_max;

	if( 7>=argc ){er_max=atoi(argv[6]);}
	else{er_max=128;}

	//Output ER image
	IplImage* ero_image_full = cvCreateImage(cvSize(times*src->width,times*src->height), IPL_DEPTH_8U, 1);
	cvResize(ero_image_small,ero_image_full,CV_INTER_LINEAR);

	char er_im[512];
	strcpy(er_im,IMAGE_DIR);strcat(er_im,"\\");
	strcat(er_im,"er_");

	sprintf(fnm,"%04d",skip_num);
	strcat(er_im,fnm);
	strcat(er_im,".bmp");
	cvSaveImage(er_im,ero_image_full);



	//Compose the initial image and SR image
	ushort vava;
	ushort cub_value;
	ushort huk_value;

	#pragma omp parallel for private(j,vava,cub_value,huk_value,cou1,cou2)
	for(i=0;i<SR_color_hokan->height;i++){

		cou1=i*SR_color_hokan->widthStep;
		cou2=i*ero_image_full->widthStep;

		for(j=0;j<SR_color_hokan->width;j++){

			vava=(uchar)ero_image_full->imageData[cou2];
			if(vava>er_max){vava=er_max;}

			cub_value=(uchar)ini_color_cubic2->imageData[	cou1+0];
			huk_value=(uchar)SR_color_hokan->imageData[		cou1+0];
			SR_color_hokan->imageData[cou1 + 0]=(vava*cub_value+(er_max-vava)*huk_value)/er_max;

			cub_value=(uchar)ini_color_cubic2->imageData[	cou1+1];
			huk_value=(uchar)SR_color_hokan->imageData[		cou1+1];
			SR_color_hokan->imageData[cou1 + 1]=(vava*cub_value+(er_max-vava)*huk_value)/er_max;

			cub_value=(uchar)ini_color_cubic2->imageData[	cou1+2];
			huk_value=(uchar)SR_color_hokan->imageData[		cou1+2];
			SR_color_hokan->imageData[cou1+ 2]=(vava*cub_value+(er_max-vava)*huk_value)/er_max;

			cou1+=3;
			cou2+=1;
	}}


	finish_time = clock();
	double hukugen_time = (double)(finish_time-start_time)/(CLOCKS_PER_SEC);

	//Output SR image
	char sr_im[512];
	strcpy(sr_im,IMAGE_DIR);strcat(sr_im,"\\");
	strcat(sr_im,"sr_");
	sprintf(fnm,"%04d",skip_num);
	strcat(sr_im,fnm);
	strcat(sr_im,".bmp");
	cvSaveImage(sr_im,SR_color_hokan);

	return 0;
}





//******************************************************************************************************************************************//
//LK-FA full scale processing
//6���ł̈ʒu���킹


float  LK_registration_FA(IplImage* pImgT, CvRect omega, IplImage* pImgI, IplImage* SR, float *SR_counts,
				float p5, float p6, IplImage *pImgT100_dammy,IplImage* edgex2, IplImage* edgey2,  IplImage* src, float *SR_g1, float *SR_g2,  float *SR_g3,float *SR_counts_g1,float *SR_counts_g2,float *SR_counts_g3,
				IplImage* pGradIx,IplImage* pGradIy, CvMat* W,CvMat* iW,CvMat* P,CvMat* X,CvMat* Z,CvMat* H,CvMat* iH ,CvMat* b, CvMat* delta_p,
				IplImage *pImgT100_dammy_B,IplImage *pImgT100_dammy_R, IplImage *ini_color_B, IplImage *ini_color_G, IplImage *ini_color_R){


	const float EPS = 1E-6f; //���[�v�I��臒l
	const int MAX_ITER = 8;//8;  //������


	int cou1,cou2,cou3,sect;
	float para_w;

	//��f�I��
	float* x2=(float*)calloc(1,sizeof(float));
	float* y2=(float*)calloc(1,sizeof(float));
	int gaso=0;


	//6���ł�3���ł��g���p�����[�^
	int l,m; //
	float stdesc[6]; //
	float* pb = &CV_MAT_ELEM(*b, float, 0, 0);//
	float D;
	int u, v;
	int i, j;
	int u2i;
	int v2i;
	float Ix;
	float Iy;
	float u2, v2;

	//������delta_p���`	
	//6��
#ifdef free6
	float delta_p1=1;
	float delta_p2=1;
	float delta_p3=1;
	float delta_p4=1;
	float delta_p5=1;
	float delta_p6=1;
#endif

	//3��
#ifdef free3
	float delta_wz = 1;
	float delta_tx = 1;
	float delta_ty = 1;
#endif

	float mean_error2=10;
	float mean_error3=11;

	float edx_sum1=1,edx_sum2=1;
	float edy_sum1=1,edy_sum2=1;

	float p1=0.0, p2=0.0, p3=0.0, p4=0.0;//���͂��߂�ǂ�����Ƃ肠����//������6���R�x�̏ꍇ
	float wz_a=0.0;//���͂��߂�ǂ�����Ƃ肠����//������3���R�x�̏ꍇ

	float mean_error=0;
	int iter=0;


	float x_cen;
	float y_cen;
	int x_ceni;
	int y_ceni;
	float bl_ip[4];
	float val_mx=0;
	int val_ad=0;
	float I2,I3;
	float mean_error4;


	while(iter < MAX_ITER)
	{

		iter++;

		mean_error = 0;

		int pixel_count=0; 

		#ifdef free3
		init_warp(W, wz_a, p5, p6); // Init warp W(x, p)//������3���R�x�̏ꍇ
		#endif

		#ifdef free6
		init_warp(W, p1, p2, p3, p4, p5, p6);	// W�̏����l�̑��//������6���R�x�̏ꍇ
		#endif

		cvSet(H, cvScalar(0));
		cvSet(b, cvScalar(0));


		//���G�b�W�␳�̂���
		edx_sum1=0;
		edy_sum1=0;


		for(j=0; j<omega.height; j++)
		{
			v = j + omega.y;

			for(i=0; i<omega.width; i++)
			{
					u = i + omega.x;



				SET_VECTOR(X, u, v);//uv�̓e���v���[�g���


				cvGEMM(W, X, 1, 0, 0, Z);
				GET_VECTOR(Z, u2, v2);


				u2i = cvFloor(u2);
				v2i = cvFloor(v2);

				if(u2i>=0 && u2i<pImgI->width && 
					v2i>=0 && v2i<pImgI->height)
				{
					pixel_count++;


					Ix = interpolate<short>(pGradIx, u2, v2);
					Iy = interpolate<short>(pGradIy, u2, v2);

					//���G�b�W�擾
					edx_sum1+=fabs(Ix);
					edy_sum1+=fabs(Iy);


					#ifdef free6
					stdesc[0] = (float)(u*Ix);
					stdesc[1] = (float)(u*Iy);
					stdesc[2] = (float)(v*Ix);
					stdesc[3] = (float)(v*Iy);
					stdesc[4] = (float)Ix;
					stdesc[5] = (float)Iy;
					#endif

					#ifdef free3
					stdesc[0] = -v*Ix+u*Iy;
					stdesc[1] = Ix;
					stdesc[2] = Iy;
					#endif

					I2 = interpolate<uchar>(pImgI, u2, v2);

//					if(iter ==(MAX_ITER-1) ){�@//1�񂾂��l��p����
					if(iter >=(MAX_ITER-4) ){//4��p����
	
					double inv_w = cvInvert(W, iW, CV_LU);
					if(inv_w!=0)
					{

						SET_VECTOR(Z, u, v);//uv�̓e���v���[�g���
						cvGEMM(iW, Z, 1, 0, 0, P);
						GET_VECTOR(P, u2, v2);

						x_cen=(u2*times);
						y_cen=(v2*times);
						x_ceni = cvFloor(x_cen);
						y_ceni = cvFloor(y_cen);

						bl_ip[0]=((int)(y_cen+1)-y_cen)*((int)(x_cen+1)-x_cen);//x y
						bl_ip[1]=((int)(y_cen+1)-y_cen)*(x_cen-(int)x_cen);	//x+1 y
						bl_ip[2]=(y_cen-(int)y_cen)*((int)(x_cen+1)-x_cen);//x y+1
						bl_ip[3]=(y_cen-(int)y_cen)*(x_cen-(int)x_cen);//x+1 y+1

						val_mx=0;
						val_ad=0; 
						for(int val_ct=0;val_ct<4;val_ct++){
							if(bl_ip[val_ct] > val_mx){val_mx=bl_ip[val_ct]; val_ad=val_ct;}
						}

						//�l���I�[�o�[���Ȃ��悤�Ƃ肠����
						if(	( (mean_error2<5.0) || (mean_error2<0.5*(edx_sum2+edy_sum2)) )
							&&	( u2>= 0) && ( v2>= 0) && ( (v2*times+1)< SR->height ) && ( (u2*times+1)< SR->width )
							){

							//�P�x�l���e���v���[�g�ƈႢ�������f�͏���
								I3=
								fabs( CV_IMAGE_ELEM(pImgT100_dammy_B,uchar, v, u) -interpolate<uchar>(ini_color_B, u2, v2) )+
								fabs( CV_IMAGE_ELEM(pImgT100_dammy,  uchar, v, u) -interpolate<uchar>(ini_color_G, u2, v2) )+
								fabs( CV_IMAGE_ELEM(pImgT100_dammy_R,uchar, v, u) -interpolate<uchar>(ini_color_R, u2, v2) );

								mean_error4=(I3+0.1);
//								if(I3<5*( fabs(Ix)+fabs(Iy) ) ){//10
								if(I3<regist_th){//200
//								if(1){//10


									if(val_ad==0){		sect=0;			}
									else if(val_ad==1){	sect=1;			}
									else if(val_ad==2){	sect=SR->width;	}
									else if(val_ad==3){	sect=SR->width+1;}

													cou1=SR->widthStep*(int(v2*times))+int(u2*times);
													cou2=v*src->widthStep + 3*u;
													cou3=v*pImgI->widthStep + u;
													para_w=1/mean_error4;


													*(SR_counts	+ cou1+sect	)+=1;

													*(SR_g1		+ cou1+sect	)+=(uchar(src->imageData[cou2   ]))*para_w;
													*(SR_g2		+ cou1+sect	)+=(uchar(src->imageData[cou2 +1]))*para_w;
													*(SR_g3		+ cou1+sect	)+=(uchar(src->imageData[cou2 +2]))*para_w;

													if((uchar)src->imageData[cou2   ]>0){*(SR_counts_g1	+ cou1+sect	)+=para_w;}
													if((uchar)src->imageData[cou2 +1]>0){*(SR_counts_g2	+ cou1+sect	)+=para_w;}
													if((uchar)src->imageData[cou2 +2]>0){*(SR_counts_g3	+ cou1+sect	)+=para_w;}
							}}

					}}



					//D = T-I(W)
					D = CV_IMAGE_ELEM(pImgT, uchar, v, u) - I2;
					
					//�G���[�̐ώZ
					mean_error += fabs(D);

					#ifdef free6
					pb[0] += stdesc[0] * D;
					pb[1] += stdesc[1] * D;
					pb[2] += stdesc[2] * D;
					pb[3] += stdesc[3] * D;
					pb[4] += stdesc[4] * D;
					pb[5] += stdesc[5] * D;
					#endif

					#ifdef free3
					pb[0] += stdesc[0] * D;
					pb[1] += stdesc[1] * D;
					pb[2] += stdesc[2] * D;
					#endif



					#ifdef free6
						for(l=0;l<6;l++)
						{
							for(m=0;m<6;m++)
							{
								CV_MAT_ELEM(*H, float, l, m) += stdesc[l]*stdesc[m];
							}
						}
					#endif


					#ifdef free3
						for(l=0;l<3;l++)
						{
							for(m=0;m<3;m++)
							{
								CV_MAT_ELEM(*H, float, l, m) += stdesc[l]*stdesc[m];
							}
						}
					#endif

				}



			}
		}
//���̃|�C���g���Ń��[�v���J��Ԃ����


		if(pixel_count!=0){
			mean_error /= pixel_count;
			mean_error3=mean_error2;
			mean_error2=mean_error;

			
			//���G�b�W�␳
			edx_sum2=edx_sum1/pixel_count;
			edy_sum2=edy_sum1/pixel_count;
		}





		//�w�V�A���̔��].
		double inv_res = cvInvert(H, iH);
		if(inv_res==0)
		{
			return 0;
		}


		cvGEMM(iH, b, 1, 0, 0, delta_p);

		#ifdef free6
		delta_p1 = CV_MAT_ELEM(*delta_p, float, 0, 0);//������6���R�x�̏ꍇ
		delta_p2 = CV_MAT_ELEM(*delta_p, float, 1, 0);
		delta_p3 = CV_MAT_ELEM(*delta_p, float, 2, 0);
		delta_p4 = CV_MAT_ELEM(*delta_p, float, 3, 0);
		delta_p5 = CV_MAT_ELEM(*delta_p, float, 4, 0);
		delta_p6 = CV_MAT_ELEM(*delta_p, float, 5, 0);
		#endif

		#ifdef free3
		delta_wz = CV_MAT_ELEM(*delta_p, float, 0, 0);//������3���R�x�̏ꍇ
		delta_tx = CV_MAT_ELEM(*delta_p, float, 1, 0);
		delta_ty = CV_MAT_ELEM(*delta_p, float, 2, 0);
		#endif


		#ifdef free6
		//������6���R�x�̏ꍇ
		p1+=delta_p1;
		p2+=delta_p2;
		p3+=delta_p3;
		p4+=delta_p4;
		p5+=delta_p5;
		p6+=delta_p6;
		#endif

		#ifdef free3
		//������3���R�x�̏ꍇ
		wz_a+=(1.5*delta_wz);
		p5+=(1.5*delta_tx);
		p6+=(1.5*delta_ty);
		#endif

	}


	#ifdef free3
	init_warp(W, wz_a, p5, p6);//������3���R�x�̏ꍇ
	#endif

	#ifdef free6
	init_warp(W, p1, p2, p3 ,p4, p5, p6);//������6���R�x�̏ꍇ
	#endif


	free(x2);
	free(y2);

//	cvWaitKey(10);

	return mean_error;
}


//********************************************************************************************************************//
//�o�C�i����raw�f�[�^��IplImage�Ɋi�[����
//�K�X�AWB����������A�K���}���������肷��
// 
// 20110421 A.Kawai  ���l��12bit�摜�𐳂����K���}�����ēǂ߂�悤�ɏC���B

int raw2image_file16(unsigned char *fpregion16,ushort R_GAIN,ushort G_GAIN,ushort B_GAIN,float normp,int bits,IplImage* src){

int i,j;
uchar c[4];
int G1val;
int Bval;
int Rval;
int G2val;
unsigned short *bv=(unsigned short*)calloc(4,sizeof(unsigned short));

#ifdef Rhead
	c[0]=1;c[1]=0;c[2]=2;c[3]=1;
#endif
#ifdef Ghead
	c[0]=0;c[1]=1;c[2]=1;c[3]=2;
#endif
#ifdef Bhead
	c[0]=1;c[1]=2;c[2]=0;c[3]=1;
#endif

if(src->nChannels==1){ //�O���[�摜�̏ꍇ
	c[0]=0;c[1]=0;c[2]=0;c[3]=0;
}

for(i=0;i<src->height;i=i+2){
	for(j=0;j<src->width;j=j+2){
// bv[2] bv[3]
// bv[0] bv[1]
#ifdef bit8
			bv[0]=*(fpregion16 + (i+1)*VGA_width + (j+0))*256;
			bv[2]=*(fpregion16 + (i+0)*VGA_width + (j+0))*256;
			bv[3]=*(fpregion16 + (i+0)*VGA_width + (j+1))*256;
#endif
#ifdef Mac
			bv[0]=*(fpregion16 + (i+1)*VGA_width*bits + bits*(j+0)+1)*256+*(fpregion16	+ (i+1)*VGA_width*bits + bits*(j+0)+0);
			bv[1]=*(fpregion16 + (i+1)*VGA_width*bits + bits*(j+1)+1)*256+*(fpregion16	+ (i+1)*VGA_width*bits + bits*(j+1)+0);
			bv[2]=*(fpregion16 + (i+0)*VGA_width*bits + bits*(j+0)+1)*256+*(fpregion16	+ (i+0)*VGA_width*bits + bits*(j+0)+0);
			bv[3]=*(fpregion16 + (i+0)*VGA_width*bits + bits*(j+1)+1)*256+*(fpregion16	+ (i+0)*VGA_width*bits + bits*(j+1)+0);
#endif
#ifdef IBM
			bv[0]=*(fpregion16 + (i+1)*VGA_width*bits + bits*(j+0)+0)*256+*(fpregion16	+ (i+1)*VGA_width*bits + bits*(j+0)+1);
			bv[1]=*(fpregion16 + (i+1)*VGA_width*bits + bits*(j+1)+0)*256+*(fpregion16	+ (i+1)*VGA_width*bits + bits*(j+1)+1);
			bv[2]=*(fpregion16 + (i+0)*VGA_width*bits + bits*(j+0)+0)*256+*(fpregion16	+ (i+0)*VGA_width*bits + bits*(j+0)+1);
			bv[3]=*(fpregion16 + (i+0)*VGA_width*bits + bits*(j+1)+0)*256+*(fpregion16	+ (i+0)*VGA_width*bits + bits*(j+1)+1);
#endif
#ifdef Rhead
			G1val=bv[0];
			Bval =bv[1];
			Rval =bv[2];
			G2val=bv[3];
#endif
#ifdef Ghead
			Bval =bv[0];
			G1val =bv[1];
			G2val =bv[2];
			Rval =bv[3];
#endif
#ifdef Bhead
			G1val=bv[0];
			Rval =bv[1];
			Bval =bv[2];
			G2val=bv[3];
#endif

#ifdef DEBUG_KAWAI
			if(j == J_PIXEL && i == I_PIXEL) {
			fprintf(stderr,"%s\n",DATAFORMAT);
			fprintf(stderr,"read  j=%d i=%d  0x%02x 0x%02x -> 0x%04x %d\n",0,0,fpregion16[0],fpregion16[1],G2val,G2val);
		}
#endif

#ifdef GammaFlag
			G1val=G1val*G_GAIN;
			Bval =Bval*B_GAIN;
			Rval =Rval*R_GAIN;
			G2val=G2val*G_GAIN;

			G1val=G1val>>BITSHIFT_FOR_GAMMA;
			Bval =Bval>>BITSHIFT_FOR_GAMMA;
			Rval =Rval>>BITSHIFT_FOR_GAMMA;
			G2val=G2val>>BITSHIFT_FOR_GAMMA;

			G1val=int(65535*sqrt(G1val/65535.0));
			Bval=int(65535*sqrt(Bval/65535.0));
			Rval=int(65535*sqrt(Rval/65535.0));
			G2val=int(65535*sqrt(G2val/65535.0));

			if(G1val>65535){G1val=65535;}//�I�[�o�[�V���[�g���Ȃ��悤
			if(Bval>65535){Bval=65535;}
			if(Rval>65535){Rval=65535;}
			if(G2val>65535){G2val=65535;}
#endif
#ifdef DEBUG_KAWAI
			if(j == J_PIXEL && i == I_PIXEL) {
				fprintf(stderr,"gamma j=%d i=%d  0x%02x 0x%02x -> 0x%04x %d\n",0,0,fpregion16[0],fpregion16[1],G2val,G2val); 
				fprintf(stderr,"src   j=%d i=%d  0x%02x 0x%02x ->0x%x %u\n",0,0,fpregion16[0],fpregion16[1],
				src->imageData[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]],
				src->imageData[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]); 
			}
#endif

/* 20110421 A.Kawai
128�ȏ�̒l�𐳂����ǂݍ��߂Ȃ������̂ł�������C��*/
			unsigned char* pSrc = (unsigned char*)src->imageData;
#ifdef Rhead
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=G1val>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=Bval>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=Rval>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=G2val>>BITSHIFT_FOR_8BIT_ROUNDING;
#endif 
#ifdef Ghead
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=Bval>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=G1val>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=G2val>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=Rval>>BITSHIFT_FOR_8BIT_ROUNDING;
#endif
#ifdef Bhead
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=G1val>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=Rval>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=Bval>>BITSHIFT_FOR_8BIT_ROUNDING;
			pSrc[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=G2val>>BITSHIFT_FOR_8BIT_ROUNDING;
#endif
/* �����܂ŏC���@*/

#ifdef DEBUG_KAWAI
			if(j == J_PIXEL && i == I_PIXEL) {
				fprintf(stderr,"aaasrc   j=%d i=%d  0x%02x 0x%02x ->0x%x %u\n",j,i,fpregion16[0],fpregion16[1],
					pSrc[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]],
					pSrc[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]); 
				fprintf(stderr,"debug exit.\n");
				exit(0);
			}
#endif

}}


	return 1;
}





int raw2image_file8(unsigned char *fpregion16,ushort R_GAIN,ushort G_GAIN,ushort B_GAIN,float normp,int bits,IplImage* src){

int i,j;
uchar c[4];
int G1val;
int Bval;
int Rval;
int G2val;
unsigned short *bv=(unsigned short*)calloc(4,sizeof(unsigned short));

#ifdef Rhead
	c[0]=1;c[1]=0;c[2]=2;c[3]=1;
#endif
#ifdef Ghead
	c[0]=0;c[1]=1;c[2]=1;c[3]=2;
#endif
#ifdef Bhead
	c[0]=1;c[1]=2;c[2]=0;c[3]=1;
#endif

if(src->nChannels==1){ //�O���[�摜�̏ꍇ
	c[0]=0;c[1]=0;c[2]=0;c[3]=0;
}


for(i=0;i<src->height;i=i+2){
	for(j=0;j<src->width;j=j+2){
// bv[2] bv[3]
// bv[0] bv[1]
			bv[0]=*(fpregion16 + (i+1)*VGA_width + (j+0));
			bv[1]=*(fpregion16 + (i+1)*VGA_width + (j+1));
			bv[2]=*(fpregion16 + (i+0)*VGA_width + (j+0));
			bv[3]=*(fpregion16 + (i+0)*VGA_width + (j+1));

#ifdef Rhead
			G1val=bv[0];
			Bval =bv[1];
			Rval =bv[2];
			G2val=bv[3];
#endif
#ifdef Ghead
			Bval =bv[0];
			G1val =bv[1];
			G2val =bv[2];
			Rval =bv[3];
#endif
#ifdef Bhead
			G1val=bv[0];
			Rval =bv[1];
			Bval =bv[2];
			G2val=bv[3];
#endif



#ifdef Rhead
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=G1val;
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=Bval;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=Rval;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=G2val;
#endif 
#ifdef Ghead
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=Bval;
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=G1val;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=G2val;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=Rval;
#endif
#ifdef Bhead
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+0)+c[0]]=G1val;
			src->imageData[(i+1)*src->widthStep+src->nChannels*(j+1)+c[1]]=Rval;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+0)+c[2]]=Bval;
			src->imageData[(i+0)*src->widthStep+src->nChannels*(j+1)+c[3]]=G2val;
#endif


}}


	return 1;
}
