
#pragma once

#ifndef _WIN32_WINNT		                   
#define _WIN32_WINNT 0x0501	
#endif						


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
#include <tchar.h>


//�ʒu���킹���̎��R�x
#define free6
//#define free4
//#define free3


struct regist{
	float img;
	float x;
	float y;
};


void warp_image(IplImage* pSrcFrame, IplImage* pDstFrame, CvMat* W);
void draw_warped_rect(IplImage* pImage, CvRect rect, CvMat* W);

#define SET_VECTOR2(X, p1, p2, p3, p4, p5, p6)\
	CV_MAT_ELEM(*(X), float, 0, 0) = (float)(p1);\
	CV_MAT_ELEM(*(X), float, 1, 0) = (float)(p2);\
	CV_MAT_ELEM(*(X), float, 2, 0) = (float)(p3);\
	CV_MAT_ELEM(*(X), float, 3, 0) = (float)(p4);\
	CV_MAT_ELEM(*(X), float, 4, 0) = (float)(p5);\
	CV_MAT_ELEM(*(X), float, 5, 0) = (float)(p6);\


#define GET_VECTOR2(X, p1, p2, p3, p4, p5, p6)\
	(p1) = CV_MAT_ELEM(*(X), float, 0, 0);\
	(p2) = CV_MAT_ELEM(*(X), float, 1, 0);\
	(p3) = CV_MAT_ELEM(*(X), float, 2, 0);\
	(p4) = CV_MAT_ELEM(*(X), float, 3, 0);\
	(p5) = CV_MAT_ELEM(*(X), float, 4, 0);\
	(p6) = CV_MAT_ELEM(*(X), float, 5, 0);\



template <class T>
float interpolate(IplImage* pImage, float x, float y)
{
	//���E���h�����l
	int xi = cvFloor(x);
	int yi = cvFloor(y);

	float k1 = x-xi;
	float k2 = y-yi;

	int f1 = xi<pImage->width-1;   
	int f2 = yi<pImage->height-1;

	T* row1 = &CV_IMAGE_ELEM(pImage, T, yi, xi);
	T* row2 = &CV_IMAGE_ELEM(pImage, T, yi+1, xi);
				

	float interpolated_value = (1.0f-k1)*(1.0f-k2)*(float)row1[0] +
				(f1 ? ( k1*(1.0f-k2)*(float)row1[1] ):0) +
				(f2 ? ( (1.0f-k1)*k2*(float)row2[0] ):0) +						
				((f1 && f2) ? ( k1*k2*(float)row2[1] ):0) ;

	return interpolated_value;

}



#define SET_VECTOR(X, u, v)\
	CV_MAT_ELEM(*(X), float, 0, 0) = (float)(u);\
	CV_MAT_ELEM(*(X), float, 1, 0) = (float)(v);\
	CV_MAT_ELEM(*(X), float, 2, 0) = 1.0f;

#define GET_VECTOR(X, u, v)\
	(u) = CV_MAT_ELEM(*(X), float, 0, 0);\
	(v) = CV_MAT_ELEM(*(X), float, 1, 0);

#define GET_INT_VECTOR(X, u, v)\
	(u) = (int)CV_MAT_ELEM(*(X), float, 0, 0);\
	(v) = (int)CV_MAT_ELEM(*(X), float, 1, 0);





float* gauss_filter0(int filter_size,float sigma);

float* gauss_filter0_line(int filter_size,float sigma);

int gauss_optimize_filter(IplImage* SR, int SR_x, int SR_y,float* a,int filter_rad);




#ifdef free6
void init_warp(CvMat* W, float p1, float p2, float p3, float p4, float p5, float p6);//������6���R�x
#endif

#ifdef free4
void init_warp(CvMat* W, float , float , float ,float);		//������4���R�x�̏ꍇ
#endif

#ifdef free3
void init_warp(CvMat* W, float wz, float tx, float ty);		//������3���R�x�̏ꍇ
#endif


void init_warp0(CvMat* W, float tx, float ty); //������2���R�x�̏ꍇ



float LK_registration_FA(IplImage* pImgT, CvRect omega, IplImage* pImgI, IplImage* SR,
					float *SR_counts, float ,float, IplImage*,IplImage*,IplImage*,IplImage*,float*,float*,float*,float*,float*,float*,
					IplImage* pGradIx,IplImage* pGradIy, CvMat* W,CvMat* iW,CvMat* P,CvMat* X,CvMat* Z,CvMat* H,CvMat* iH ,CvMat* b, CvMat* delta_p,
					IplImage *pImgT100_dammy_B,IplImage *pImgT100_dammy_R, IplImage *ini_color_B, IplImage *ini_color_G, IplImage *ini_color_R);


float  LK_registration_IA(IplImage* pImgT, CvRect omega, IplImage* pImgI, IplImage* SR,float *SR_counts,
				float p5, float p6, IplImage *pImgT100_dammy,IplImage* edgex2, IplImage* edgey2,  IplImage* src, float *SR_g1, float *SR_g2,  float *SR_g3,float *SR_counts_g1,float *SR_counts_g2,float *SR_counts_g3,
				IplImage* pGradIx,IplImage* pGradIy, CvMat* W,CvMat* iW,CvMat* P,CvMat* X,CvMat* Z,CvMat* H,CvMat* iH ,CvMat* b, CvMat* delta_p,
				IplImage *pImgT100_dammy_B,IplImage *pImgT100_dammy_R, IplImage *ini_color_B, IplImage *ini_color_G, IplImage *ini_color_R,
				IplImage* pGradTx,IplImage* pGradTy,
				float *ex, float *ey, float *SR_ex, float *SR_ey,struct regist* regist_all,IplImage *pMStDesc);



float  LK_registration_IC(IplImage* pImgT, CvRect omega, IplImage* pImgI, IplImage* SR, float *SR_counts,
				float p5, float p6, IplImage *pImgT100_dammy,IplImage* edgex2, IplImage* edgey2,  IplImage* src, float *SR_g1, float *SR_g2,  float *SR_g3,float *SR_counts_g1,float *SR_counts_g2,float *SR_counts_g3,
				IplImage* pGradIx,IplImage* pGradIy, CvMat* W,CvMat* iW,CvMat* P,CvMat* X,CvMat* Z,CvMat* H,CvMat* iH ,CvMat* b, CvMat* delta_p,
				IplImage *pImgT100_dammy_B,IplImage *pImgT100_dammy_R, IplImage *ini_color_B, IplImage *ini_color_G, IplImage *ini_color_R,
				IplImage* pGradTx,IplImage* pGradTy,
				float *ex, float *ey, float *SR_ex, float *SR_ey,struct regist* regist_all,IplImage *pMStDesc,	CvMat* dW, CvMat* idW);




CvPoint2D32f* LK_registration_FA0(IplImage* pImgT, CvRect omega, IplImage* pImgI,IplImage* pGradIx,IplImage* pGradIy,CvPoint2D32f*,
									   CvMat*,CvMat*,CvMat*,CvMat*,CvMat*,CvMat*,CvMat*,CvMat*,CvMat*);

CvPoint2D32f* LK_registration_IC0(IplImage* pImgT, CvRect omega, IplImage* pImgI,IplImage* pGradIx,IplImage* pGradIy,
									   CvPoint2D32f* ppoint, CvMat* W,CvMat* iW,CvMat* P,CvMat* X,CvMat* Z,CvMat* H,CvMat* iH ,CvMat* b, CvMat* delta_p,IplImage *pMStDesc, CvMat* dW,CvMat* idW);


int gauss_optimize_filter2(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *, float *,int *keisuu);
int gauss_optimize_filter2_G(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,int *keisuu);
int gauss_optimize_filter2_RB(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,int *keisuu);
int gauss_optimize_filter2_RB_test(IplImage* SR2,IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green);
int gauss_optimize_filter2_else(IplImage* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green, int iro);
float gauss_optimize_filter0(float* SR, int SR_x, int SR_y, float* a, int filter_rad, IplImage* SR0,int *keisuu);

float* gauss_optimize_filter0_line(float* SR, float* a_line, int filter_rad, IplImage* SR0, float* SR_work,int *keisuu, float* SR_ex2);
IplImage* gauss_optimize_filter2_line(IplImage* SR,  float* a_line, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g,float* SR_work,int *keisuu, IplImage *SR_color_hokan2);
float* gauss_filter_line(float* a, int filter_rad,float sigma);
void matrix_vector_product_line(float *a, float *b, float *c, IplImage* src, float *work);
void matrix_vector_product02_line( float *a, float *b, float *d, float *c ,IplImage* src, float *work);
void gauss_optimize_filter2_2(IplImage* SR,  float* a, int filter_rad, IplImage* ini, int plane, float *SR_counts, float* SR_counts_g,IplImage* SR_color_hokan2);
void gauss_optimize_filter2_G_2(IplImage* SR,  float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,IplImage *SR_color_hokan);
void gauss_optimize_filter2_RB_2(IplImage* SR,  float* a, int filter_rad, IplImage* ini, int plane,  float *SR_counts, float* SR_counts_g, IplImage* green,IplImage *SR_color_hokan);

float* laplace_filter0(int filter_rad);
float* gauss_filter(float *a,int filter_size,float sigma);
extern int N_gen; //*************************************************************************�����ɉ摜�T�C�Y(�s�N�Z��)������!!
extern int N_gen_width;
extern int N_gen_height;
#define EPS2 pow(10.0, -4.0) /* epsilon�̐ݒ�*/


float vector_norm1( float *a );
/* A�x�N�g��a[0,...,N-1]��b[0,...,N-1]�̓��ς��v�Z����*/
float inner_product(float *a, float *b);
/* �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�c<-Ab*/
void matrix_vector_product( float *a, float *b, float *c ,IplImage*);
void matrix_vector_product02( float *a, float *b, float *d, float *c ,IplImage*);//������
void matrix_vector_product2(float *a, float *b, float *c, IplImage* src);

float vector_norm1_all( float *a ,IplImage*);
float inner_product_all(float *a, float *b,IplImage*);

IplImage* cg_color2(float *a, float *laplace,IplImage* SR_color, IplImage* src_ini_color , float *SR_ex, float *SR_ey, float *a_line2);
IplImage* cg_color2_cubic(float *a, float *laplace,IplImage* SR_color, IplImage* src_ini_color , float *SR_ex, float *SR_ey, float *a_line2);


void matrix_vector_product2_y(float *a, float *b, float *c, IplImage* src, float *SR_ex, float *SR_ey);
void matrix_vector_product_new(float *a, float *b, float *c, IplImage* src, float *SR_ex, float *SR_ey);


void subst_f(float*,float*,float*,int, float);



void bayer_simple_implementation(IplImage*,IplImage*,IplImage*,IplImage*);

int raw2image_file16(unsigned char *fpregion16,ushort R_GAIN,ushort G_GAIN,ushort B_GAIN,float normp,int bits,IplImage* src);
int raw2image_file8(unsigned char *fpregion16,ushort R_GAIN,ushort G_GAIN,ushort B_GAIN,float normp,int bits,IplImage* src);

