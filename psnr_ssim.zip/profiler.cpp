#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <list>

#include <tchar.h>
#include <ctype.h>
#include<iostream>
#include <fstream>
#include <vector>
#include <windows.h>


#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"

#include "opencv\\cv.h"
#include "opencv\\highgui.h"



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main (int argc, char **argv){



	//�摜����
	printf("loading image..");

	//���͉摜
	IplImage* src		= cvLoadImage(argv[1],1);
	//���͉摜�̃O���[�摜
	IplImage* src_gray	= cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
	cvCvtColor(src, src_gray, CV_BGR2GRAY);	


	IplImage* dst	= cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 3);
	cvCvtColor(src_gray, dst, CV_GRAY2BGR);


	//�v���t�@�C���ʒu
	int	ini_x	= atoi(argv[2]);
	int	ini_y	= atoi(argv[3]);
	int	length	= atoi(argv[4]);

	char fn[512];
	strcpy(fn,argv[1]);
	strcat(fn,"_pf.txt");

	FILE*fp=fopen(fn,"w");


	for(int j=ini_x;j<ini_x+length;j++){

		int i=ini_y;

		int address_ipl	=i*src_gray->widthStep+j;
		fprintf(fp,"%d\n",(uchar)src_gray->imageData[address_ipl]);
	}


	cvLine(dst, cvPoint(ini_x,ini_y), cvPoint(ini_x+length,ini_y), CV_RGB(255,0,0), 2, 0, 0);



	fclose(fp);


	char fns[512];
	strcpy(fns,argv[1]);
	strcat(fns,"_pf.png");
	cvSaveImage(fns,dst);




	return 1;


}



