#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <cv.h>	
//#include <highgui.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"



double calc_SSIM(IplImage* img1_temp, IplImage* img2_temp, int offset);//img1_temp,img1_temp2�ɂ��āA�㉺���E����offset �s�N�Z����������f�ɂ��Čv�Z����
double calc_PSNR(IplImage* img1_temp, IplImage* img2_temp, int offset);//img1_temp,img1_temp2�ɂ��āA�㉺���E����offset �s�N�Z����������f�ɂ��Čv�Z����
double PSNR_Matrix( IplImage*img1_data, IplImage*img2_data, long width,long height);



void main(int argc, char** argv){

	IplImage* src1,*src2;
	src1 = cvLoadImage(argv[1],1);
	src2 = cvLoadImage(argv[2],1);


	//SSIM
	printf("SSIM: %lf\n", calc_SSIM(src1, src2, 10));
	//PSNR
	printf("PSNR: %lf\n", calc_PSNR(src1, src2, 10));



}



//*****************************************************************************************************//
//  �P�x�ʂɑ΂���SSIM�l�Z�o
//
//	����: src1, src2�͓��T�C�Y�̉摜�A�O���[�ł��J���[�ł��悢
//		  offset:�������珜���摜�[(pixel)
//	�o��: SSIM�l�@(0-100�̒l��)


double calc_SSIM(IplImage* src1, IplImage* src2, int offset)
{

	if(src1==NULL || src2==NULL){printf("error.insuff...");		return 0;}

	IplImage* img1_temp=cvCreateImage(cvSize(src1->width,src1->height),IPL_DEPTH_8U,1);//��������O���[�摜
	IplImage* img2_temp=cvCreateImage(cvSize(src1->width,src1->height),IPL_DEPTH_8U,1);//��������O���[�摜

	if(src1->nChannels==1){	//���͉摜���O���[�摜�Ȃ炻�̂܂܃R�s�[
		cvCopy(src1,img1_temp);		cvCopy(src2,img2_temp);
	}else{					//���͉摜��BGR�摜�Ȃ�O���[�摜�ɕϊ�
		cvCvtColor(src1,img1_temp,CV_BGR2GRAY);		cvCvtColor(src2,img2_temp,CV_BGR2GRAY);
	}


	
	// default settings
	double C1 = 6.5025, C2 = 58.5225;

	IplImage
		*img1=NULL, *img2=NULL,		
		*img1_img2=NULL,
		*img1_sq=NULL, *img2_sq=NULL,
		*mu1=NULL, *mu2=NULL,
		*mu1_sq=NULL, *mu2_sq=NULL, *mu1_mu2=NULL,
		*sigma1_sq=NULL, *sigma2_sq=NULL, *sigma12=NULL,
		*ssim_map=NULL, *temp1=NULL, *temp2=NULL, *temp3=NULL;
	



	//�摜�̒[(offset�ȓ�)�̉e��������
	for(int i=0;i<img1_temp->height;i++){
		for(int j=0;j<img1_temp->width;j++){
			if(	(i<offset || i>img1_temp->height-offset)
				||(j<offset || j>img1_temp->width-offset)){
					int ad=i*img1_temp->widthStep+j;
					img1_temp->imageData[ad]=0;
					img2_temp->imageData[ad]=0;
			}
	}}

	//��������摜�\��
	cvNamedWindow("img1_temp");	cvShowImage("img1_temp",img1_temp);
	cvNamedWindow("img2_temp");	cvShowImage("img2_temp",img2_temp);
	cvWaitKey(0);


	int x=img1_temp->width, y=img1_temp->height;
	int nChan=img1_temp->nChannels, d=IPL_DEPTH_32F;
	CvSize size = cvSize(x, y);

	img1 = cvCreateImage( size, d, nChan);
	img2 = cvCreateImage( size, d, nChan);

	cvConvert(img1_temp, img1);
	cvConvert(img2_temp, img2);
	
	img1_sq = cvCreateImage( size, d, nChan);
	img2_sq = cvCreateImage( size, d, nChan);
	img1_img2 = cvCreateImage( size, d, nChan);
	
	cvPow( img1, img1_sq, 2 );
	cvPow( img2, img2_sq, 2 );
	cvMul( img1, img2, img1_img2, 1 );

	mu1 = cvCreateImage( size, d, nChan);
	mu2 = cvCreateImage( size, d, nChan);

	mu1_sq = cvCreateImage( size, d, nChan);
	mu2_sq = cvCreateImage( size, d, nChan);
	mu1_mu2 = cvCreateImage( size, d, nChan);
	

	sigma1_sq = cvCreateImage( size, d, nChan);
	sigma2_sq = cvCreateImage( size, d, nChan);
	sigma12 = cvCreateImage( size, d, nChan);

	temp1 = cvCreateImage( size, d, nChan);
	temp2 = cvCreateImage( size, d, nChan);
	temp3 = cvCreateImage( size, d, nChan);

	ssim_map = cvCreateImage( size, d, nChan);


	//////////////////////////////////////////////////////////////////////////
	// PRELIMINARY COMPUTING
	double sigma=0.5;
	cvSmooth( img1, mu1, CV_GAUSSIAN, 11, 11, sigma );
	cvSmooth( img2, mu2, CV_GAUSSIAN, 11, 11, sigma );
	
	cvPow( mu1, mu1_sq, 2 );
	cvPow( mu2, mu2_sq, 2 );
	cvMul( mu1, mu2, mu1_mu2, 1 );


	cvSmooth( img1_sq, sigma1_sq, CV_GAUSSIAN, 11, 11, sigma );
	cvAddWeighted( sigma1_sq, 1, mu1_sq, -1, 0, sigma1_sq );
	
	cvSmooth( img2_sq, sigma2_sq, CV_GAUSSIAN, 11, 11, sigma );
	cvAddWeighted( sigma2_sq, 1, mu2_sq, -1, 0, sigma2_sq );

	cvSmooth( img1_img2, sigma12, CV_GAUSSIAN, 11, 11, sigma );
	cvAddWeighted( sigma12, 1, mu1_mu2, -1, 0, sigma12 );
	

	//////////////////////////////////////////////////////////////////////////
	// FORMULA

	// (2*mu1_mu2 + C1)
	cvScale( mu1_mu2, temp1, 2 );
	cvAddS( temp1, cvScalarAll(C1), temp1 );

	// (2*sigma12 + C2)
	cvScale( sigma12, temp2, 2 );
	cvAddS( temp2, cvScalarAll(C2), temp2 );

	// ((2*mu1_mu2 + C1).*(2*sigma12 + C2))
	cvMul( temp1, temp2, temp3, 1 );

	// (mu1_sq + mu2_sq + C1)
	cvAdd( mu1_sq, mu2_sq, temp1 );
	cvAddS( temp1, cvScalarAll(C1), temp1 );

	// (sigma1_sq + sigma2_sq + C2)
	cvAdd( sigma1_sq, sigma2_sq, temp2 );
	cvAddS( temp2, cvScalarAll(C2), temp2 );

	// ((mu1_sq + mu2_sq + C1).*(sigma1_sq + sigma2_sq + C2))
	cvMul( temp1, temp2, temp1, 1 );

	// ((2*mu1_mu2 + C1).*(2*sigma12 + C2))./((mu1_sq + mu2_sq + C1).*(sigma1_sq + sigma2_sq + C2))
	cvDiv( temp3, temp1, ssim_map, 1 );


	CvScalar index_scalar = cvAvg( ssim_map );


	printf("%lf, \n",index_scalar.val[0] * 100);
//	printf("%lf, \n",index_scalar.val[1] * 100);
//	printf("%lf, \n",index_scalar.val[2] * 100);

	//�J��
	cvReleaseImage(&img1_temp);	cvReleaseImage(&img2_temp);
	cvReleaseImage(&img1);cvReleaseImage(&img2);cvReleaseImage(&img1_img2);
	cvReleaseImage(&img1_sq);cvReleaseImage(&img2_sq);
	cvReleaseImage(&mu1);cvReleaseImage(&mu2);
	cvReleaseImage(&mu1_sq);cvReleaseImage(&mu2_sq);cvReleaseImage(&mu1_mu2);
	cvReleaseImage(&sigma1_sq);cvReleaseImage(&sigma2_sq);cvReleaseImage(&sigma12);
	cvReleaseImage(&ssim_map);cvReleaseImage(&temp1);cvReleaseImage(&temp2);cvReleaseImage(&temp3);


	return index_scalar.val[0] * 100;
}


//*****************************************************************************************************//
//  �P�x�ʂɑ΂���PSNR�l�Z�o
//
//	����: src1, src2�͓��T�C�Y�̉摜�A�O���[�ł��J���[�ł��悢
//		  offset:�������珜���摜�[(pixel)
//	�o��: PSNR�l�@


double calc_PSNR(IplImage* src1, IplImage* src2, int offset)
{
	
	if(src1==NULL || src2==NULL){printf("error.insuff...");		return 0;}

	IplImage* img1_temp=cvCreateImage(cvSize(src1->width,src1->height),IPL_DEPTH_8U,1);//��������O���[�摜
	IplImage* img2_temp=cvCreateImage(cvSize(src1->width,src1->height),IPL_DEPTH_8U,1);//��������O���[�摜

	if(src1->nChannels==1){	//���͉摜���O���[�摜�Ȃ炻�̂܂܃R�s�[
		cvCopy(src1,img1_temp);		cvCopy(src2,img2_temp);
	}else{					//���͉摜��BGR�摜�Ȃ�O���[�摜�ɕϊ�
		cvCvtColor(src1,img1_temp,CV_BGR2GRAY);		cvCvtColor(src2,img2_temp,CV_BGR2GRAY);
	}


	//�摜�̒[(offset�ȓ�)�̉e��������
	for(int i=0;i<img1_temp->height;i++){
		for(int j=0;j<img1_temp->width;j++){
			if(	(i<offset || i>img1_temp->height-offset)
				||(j<offset || j>img1_temp->width-offset)){
					int ad=i*img1_temp->widthStep+j;
					img1_temp->imageData[ad]=0;
					img2_temp->imageData[ad]=0;
			}
	}}

	//��������摜�\��
	cvNamedWindow("img1_temp");	cvShowImage("img1_temp",img1_temp);
	cvNamedWindow("img2_temp");	cvShowImage("img2_temp",img2_temp);
	cvWaitKey(0);


	double value=PSNR_Matrix( img1_temp, // changed image
		            img2_temp, // original image
                    img1_temp->width,
                    img1_temp->height);


	cvReleaseImage(&img1_temp);
	cvReleaseImage(&img2_temp);

	return value;
}



//*****************************************************************************************************//
//  PSNR�l�̎��v�Z��
//

double PSNR_Matrix( IplImage*img1_data, // changed image
                    IplImage*img2_data, // original image
                    long width,
                    long height)
{
	int ad;
    long i, j;
    double error, pix, x, psnr;

    /* calculating distortion */
    error = 0.0;
    pix = (double)width*(double)height;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {
			ad=i*img1_data->widthStep+j;
			x = double((uchar)img1_data->imageData[ad] - (uchar)img2_data->imageData[ad]);
            error += ((x * x) / pix);
        }
    }
    psnr = 10.0 * log10((255.0*255.0)/error);

    return (psnr);
}

	