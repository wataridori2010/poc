#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <cv.h>	
//#include <highgui.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"


//#include <iostream.h>
//#include <iostream>

double PSNR_Matrix( IplImage*img1_data, // changed image
                    IplImage*img2_data, // original image
                    long width,
                    long height);


/*
 * Parameters : complete path to the two image to be compared
 * The file format must be supported by your OpenCV build
 */
int main(int argc, char** argv)
{
	if(argc<3)
		return -1;
	
	// default settings
	double C1 = 6.5025, C2 = 58.5225;

	IplImage
		*img1=NULL, *img2=NULL, *img1_img2=NULL,
		*img1_temp=NULL, *img2_temp=NULL,
		*img1_sq=NULL, *img2_sq=NULL,
		*mu1=NULL, *mu2=NULL,
		*mu1_sq=NULL, *mu2_sq=NULL, *mu1_mu2=NULL,
		*sigma1_sq=NULL, *sigma2_sq=NULL, *sigma12=NULL,
		*ssim_map=NULL, *temp1=NULL, *temp2=NULL, *temp3=NULL;
	

	/***************************** INITS **********************************/
	img1_temp = cvLoadImage(argv[1],0);
	img2_temp = cvLoadImage(argv[2],0);

	if(img1_temp==NULL || img2_temp==NULL){printf("insuff...");
		return -1;}

	printf(".");

	int offset=10;
	if(argc>3)offset=atoi(argv[3]);

	printf(".");
	for(int i=0;i<img1_temp->height;i++){
		for(int j=0;j<img1_temp->width;j++){
			if(	(i<offset || i>img1_temp->height-offset)
				||(j<offset || j>img1_temp->width-offset)){
					int ad=i*img1_temp->widthStep+j;
					img1_temp->imageData[ad]=10;
					img2_temp->imageData[ad]=10;
			}
	}}


	printf(".");
	int width=img1_temp->width, height=img1_temp->height;

	double value=PSNR_Matrix( img1_temp, // changed image
                    img2_temp, // original image
                    width,
                    height);

	printf(".");

	printf("\nPSNR: %lf, \n",value );
	return 0;
}



double PSNR_Matrix( IplImage*img1_data, // changed image
                    IplImage*img2_data, // original image
                    long width,
                    long height)
{
	int ad;
    long i, j;
    double error, pix, x, psnr;

    /* calculating distortion */
    error = 0.0;
    pix = (double)width*(double)height;
    for(i=0;i<height;i++)
    {
        for(j=0;j<width;j++)
        {
			ad=i*img1_data->widthStep+j;
			x = double((uchar)img1_data->imageData[ad] - (uchar)img2_data->imageData[ad]);
            error += ((x * x) / pix);
        }
    }
    psnr = 10.0 * log10((255.0*255.0)/error);

    return (psnr);
}

	