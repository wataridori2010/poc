
#include "NR3.h"


//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter

NR3class::NR3class(){

	counts=0;
	ex_count=0;




}





//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter
int NR3class::InputParam(int pyr_,float sl2,float sl3,float sl4,float sl5 ,int sl6){

	//
	pyr=pyr_;
	sigmax=0.2;		//sl1;//��ԁ@�t���T�C�Y
	sigmax2=sl2;	//��ԁ@1/4�T�C�Y
	Xth=sl3;		//���臒l

	sigmad1=sl4;	//�P�x�p��//15
	sigmad2=sl4;	//�F���p��//5
	Dth1=sl5;		//�P�x�p臒l//45
	Dth2=sl5;		//�F���p臒l//15

	multi[0]=sl6;
	multi[1]=1;

}




//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter

int NR3class::CreateBuffer(IplImage*src){


		p0 = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
		p = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
		pp = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);


		//Creating buffer 

		//1/1scale
		re_img0 = cvCreateImage(cvSize(int(src->width),int(src->height)), IPL_DEPTH_8U, 3);
		for(int num=0; num<2; num++)		p0[num]		 = cvCloneImage(src);//
		

		//1/2scale
		re_img=cvCreateImage(cvSize(int(src->width/2),int(src->height/2)), IPL_DEPTH_8U, 3);
		cvResize(src,re_img,CV_INTER_LINEAR);//		cvResize(src,re_img,CV_INTER_NN);
		for(int num=0; num<2; num++)		p[num]		 = cvCloneImage(re_img);//


		//1/4scale
		re_img2=cvCreateImage(cvSize(int(src->width/4),int(src->height/4)), IPL_DEPTH_8U, 3);
		cvResize(src,re_img2,CV_INTER_LINEAR);//		cvResize(re_img,re_img2,CV_INTER_NN);
		for(int num=0; num<2; num++)		pp[num]		 = cvCloneImage(re_img2);//

		//Noise image
		noise_img2=cvCreateImage(cvSize(int(src->width/4),int(src->height/4)), IPL_DEPTH_8U, 3);
		noise_img =cvCreateImage(cvSize(int(src->width/2),int(src->height/2)), IPL_DEPTH_8U, 3);
		noise_img0 =cvCreateImage(cvSize(int(src->width),int(src->height)), IPL_DEPTH_8U, 3);

		

		//�������ʉ摜
		dst		 = cvCloneImage(src);//




		//Filtering buffer//////

		//Color weight
		d_coef1=(unsigned char**)calloc(2,sizeof(unsigned char*));
		d_coef2=(unsigned char**)calloc(2,sizeof(unsigned char*));
		*(d_coef1+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef1+1)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+1)=(unsigned char*)calloc(512,sizeof(unsigned char));

		//Gaussian weighting
		for(int num=0;num<512;num++){
			if(	(num-255)>-(Dth1)	&&	(num-255)<(Dth1)){
				#ifdef bilatelal

					d_coef2[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1));//bilatelal (lumi)
					d_coef1[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2));//bilatelal (chroma)
					d_coef2[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1));//bilatelal (lumi)
					d_coef1[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2));//bilatelal (chroma)

				#endif
				#ifdef epsilon
					d_coef2[0][num]=fabs(double(num-255));//epsilon-like (lumi)
					d_coef1[0][num]=fabs(double(num-255));//epsilon-like (chroma)
					d_coef2[1][num]=fabs(double(num-255));//epsilon-like (lumi)
					d_coef1[1][num]=fabs(double(num-255));//epsilon-like (chroma)
				#endif

			}
			else{
				d_coef2[0][num]=0;
				d_coef1[0][num]=0;
				d_coef2[1][num]=0;
				d_coef1[1][num]=0;
			}
		}

		//Spatioal weight
		x_coef2=(unsigned char**)calloc(2,sizeof(unsigned char*));		//1/4 sacle
		x_coef3=(unsigned char**)calloc(2,sizeof(unsigned char*));		//1/1 scale
		*(x_coef2+0)=(unsigned char*)calloc(121,sizeof(unsigned char));
		*(x_coef3+0)=(unsigned char*)calloc(121,sizeof(unsigned char));
		*(x_coef2+1)=(unsigned char*)calloc(121,sizeof(unsigned char));
		*(x_coef3+1)=(unsigned char*)calloc(121,sizeof(unsigned char));


		//Gaussian weighting
		for(s=0;s<11;s++){
			for(t=0;t<11;t++){
				if(	(s-5)>-(Xth)	&&	(s-5)<(Xth)	&&	(t-5)>-(Xth)	&&	(t-5)<(Xth)		){
						x_coef2[0][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax2*sigmax2));
						x_coef2[1][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax2*sigmax2));
						x_coef3[0][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax*sigmax));
						x_coef3[1][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax*sigmax));
				}else{
						x_coef2[0][s*11+t]=0;
						x_coef2[1][s*11+t]=0;
						x_coef3[0][s*11+t]=0;
						x_coef3[1][s*11+t]=0;
				}
		}}


	

}


//--------------------------------------------------------------------------------//



//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter

IplImage* NR3class::NR3proc(IplImage*src){



int width1=src->width/1.0;
int width2=src->width/2.0;
int width4=src->width/4.0;
int height1=src->height/1.0;
int height2=src->height/2.0;
int height4=src->height/4.0;

double rgb[3];
double dv3[3];
double sum_p[3];
double sum;


unsigned char t1,t2,t3;
unsigned char v1,v2,v3;
int s,t;
	

#ifdef PYR3

cvResize(src,pp[0],CV_INTER_LINEAR);
//cvZero(re_img2);cvZero(noise_img2);



//1/8�摜���璆���g�m�C�Y����
int address0=0;
int address1=0;

for(i=0;i<height4;i++){

	address0=i*pp[0]->widthStep;

	for(j=0;j<width4;j++){

			address1=address0 + 3*j;

			t1=(uchar)pp[0]->imageData[address1 +0];
			t2=(uchar)pp[0]->imageData[address1 +1];
			t3=(uchar)pp[0]->imageData[address1 +2];

			//�m�C�Y�ώZ�摜�̏�����
			noise_img2->imageData[address1 +0]=0;
			noise_img2->imageData[address1 +1]=0;
			noise_img2->imageData[address1 +2]=0;


			tb=t1;tg=t2;tr=t3;

			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<PFRAME;num++){//���t���[���ƑO�t���[�����g���̂�
//			for(int num=0;num<1;num++){//���t���[���̂�


				address2=address1-5*pp[0]->widthStep;//(5,5)�̃t�B���^�̏ꍇ
				for(s=-5;s<6;s++){


				address3=address2-15;
				for(t=-5;t<6;t++){
						
						if( (address3>=0)&&(address3<=pp[num]->widthStep*pp[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
						xv=x_coef2[num][(s+5)*11+(t+5)];


						v1=(uchar)pp[num]->imageData[address3 +0];
						v2=(uchar)pp[num]->imageData[address3 +1];
						v3=(uchar)pp[num]->imageData[address3 +2];


						//�F�������ɂ��d�ݕt��
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];
						dv3[0]*=multi[num];
						dv3[1]*=multi[num];
						dv3[2]*=multi[num];


						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];


						}
						address3+=3;

					}//t
					address2+=pp[0]->widthStep;

				}//s
			}

			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]/4; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]/4; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]/4; tr=(rgb[2] +dv3[2])/sum_p[2];}

			//2�Ԃ��1NR�摜
			re_img2->imageData[address1 +0]=tb;
			re_img2->imageData[address1 +1]=tg;
			re_img2->imageData[address1 +2]=tr;

			noise_img2->imageData[address1 +0]=(128+tb-t1);
			noise_img2->imageData[address1 +1]=(128+tg-t2);
			noise_img2->imageData[address1 +2]=(128+tr-t3);

	}}



	cvCopy(re_img2, pp[1]);
//	cvCopy(p[0], p[1]);

	cvResize(noise_img2,noise_img,CV_INTER_LINEAR);
//	cvResize(noise_img2,noise_img,CV_INTER_CUBIC);


#endif




//******************************************************************************************************
//******************************************************************************************************
	//�摜�̃R�s�[(���摜�T�C�Y����)
	cvCopy(src, p0[0]);

	//�摜�̃R�s�[(1/2�摜�T�C�Y����)
	cvResize(src,p[0],CV_INTER_LINEAR);
//	cvResize(src,p[0],CV_INTER_AREA);
	cvCopy(p[0],re_img);


//��1226�ǉ�
	cvCopy(src,dst);
	clock_t time3 = clock();




#ifdef PYR3

	address1=0;
	address0=0;
	//�t���X�P�[���摜���璆���g�m�C�Y����
	for(i=0;i<height2;i++){

		address1=address0;

		for(j=0;j<width2;j++){

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p[0]->imageData[address1 +0]+(uchar)noise_img->imageData[address1 +0]-128;
			ttt2=(uchar)p[0]->imageData[address1 +1]+(uchar)noise_img->imageData[address1 +1]-128;
			ttt3=(uchar)p[0]->imageData[address1 +2]+(uchar)noise_img->imageData[address1 +2]-128;

			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p[0]->imageData[address1 +0]=(uchar)t1;
			p[0]->imageData[address1 +1]=(uchar)t2;
			p[0]->imageData[address1 +2]=(uchar)t3;

		address1+=3;
		}
	address0+=p[0]->widthStep;
	}

#endif








//*************************************************************************************************************************//
//1/4�摜���璆���g�m�C�Y����
address0=0;
address1=0;

for(i=0;i<height2;i++){

	address0=i*p[0]->widthStep;

	for(j=0;j<width2;j++){

			address1=address0 + 3*j;

			t1=(uchar)p[0]->imageData[address1 +0];
			t2=(uchar)p[0]->imageData[address1 +1];
			t3=(uchar)p[0]->imageData[address1 +2];

#ifndef PYR3
			//�m�C�Y�ώZ�摜�̏�����
			noise_img->imageData[address1 +0]=0;
			noise_img->imageData[address1 +1]=0;
			noise_img->imageData[address1 +2]=0;
#endif

			tb=t1;tg=t2;tr=t3;

			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<PFRAME;num++){

				address2=address1-5*p[0]->widthStep;//(5,5)�̃t�B���^�̏ꍇ
				for(s=-5;s<6;s++){


				address3=address2-15;
				for(t=-5;t<6;t++){
						
						if( (address3>=0)&&(address3<=p[num]->widthStep*p[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
						xv=x_coef2[num][(s+5)*11+(t+5)];


						v1=(uchar)p[num]->imageData[address3 +0];
						v2=(uchar)p[num]->imageData[address3 +1];
						v3=(uchar)p[num]->imageData[address3 +2];


						//�F�������ɂ��d�ݕt��
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];
						dv3[0]*=multi[num];
						dv3[1]*=multi[num];
						dv3[2]*=multi[num];


						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];


						}
						address3+=3;

					}//t
					address2+=p[0]->widthStep;

				}//s
			}

			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]/4; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]/4; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]/4; tr=(rgb[2] +dv3[2])/sum_p[2];}

			//2�Ԃ��1NR�摜
			re_img->imageData[address1 +0]=tb;
			re_img->imageData[address1 +1]=tg;
			re_img->imageData[address1 +2]=tr;

#ifdef PYR3
			noise_img->imageData[address1 +0]+=(tb-t1);
			noise_img->imageData[address1 +1]+=(tg-t2);
			noise_img->imageData[address1 +2]+=(tr-t3);
#else
			noise_img->imageData[address1 +0]=(128+tb-t1);
			noise_img->imageData[address1 +1]=(128+tg-t2);
			noise_img->imageData[address1 +2]=(128+tr-t3);
#endif

	}}

	//��1027
	cvCopy(re_img, p[1]);
//	cvCopy(p[0], p[1]);


	//��1027
	cvResize(noise_img,noise_img0,CV_INTER_LINEAR);
//	cvResize(noise_img,noise_img0,CV_INTER_CUBIC);

	clock_t time5 = clock();
	double total_time4 = (double)(time5-time3)/CLOCKS_PER_SEC;
	printf("2�K�w: %g sec.\n", total_time4);


//
//�t���T�C�YNR����

	address1=0;
	address0=0;
	//�t���X�P�[���摜���璆���g�m�C�Y����
	for(i=0;i<height1;i++){

		address1=address0;

		for(j=0;j<width1;j++){

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p0[0]->imageData[address1 +0]+(uchar)noise_img0->imageData[address1 +0]-128;
			ttt2=(uchar)p0[0]->imageData[address1 +1]+(uchar)noise_img0->imageData[address1 +1]-128;
			ttt3=(uchar)p0[0]->imageData[address1 +2]+(uchar)noise_img0->imageData[address1 +2]-128;

			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p0[0]->imageData[address1 +0]=(uchar)t1;
			p0[0]->imageData[address1 +1]=(uchar)t2;
			p0[0]->imageData[address1 +2]=(uchar)t3;

		address1+=3;
		}
	address0+=p0[0]->widthStep;
	}


	//�����������t���O
	if(pyr == 2){

	//�t���X�P�[���摜���獂���g�m�C�Y����
	address1=0;
	address0=0;
	for(i=0;i<height1;i++){

		address0=i*p0[0]->widthStep;

		for(j=0;j<width1;j++){


			address1=address0 + 3*j;

			t1=(uchar)p0[0]->imageData[address1 +0];
			t2=(uchar)p0[0]->imageData[address1 +1];
			t3=(uchar)p0[0]->imageData[address1 +2];

			tb=t1;tg=t2;tr=t3;


			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<PFRAME;num++){

				address2=address1-p0[0]->widthStep;//(5,5)�̃t�B���^
//				for(s=-2;s<3;s++){
				for(s=-1;s<2;s++){


					address3=address2-3;//(5,5)�̃t�B���^
//					for(t=-2;t<3;t++){
					for(s=-1;s<2;s++){


						if( (address3>=0)&&(address3<=p0[num]->widthStep*p0[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
						xv=x_coef3[num][(s+5)*11+(t+5)];


						v1=(uchar)p0[num]->imageData[address3 +0];
						v2=(uchar)p0[num]->imageData[address3 +1];
						v3=(uchar)p0[num]->imageData[address3 +2];

						//�F�������ɂ��d�ݕt��
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];
						dv3[0]*=multi[num];
						dv3[1]*=multi[num];
						dv3[2]*=multi[num];


						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];


						}
						address3+=3;

					}//t
					address2+=p0[0]->widthStep;

				}//s
			}


			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]/4; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]/4; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]/4; tr=(rgb[2] +dv3[2])/sum_p[2];}

			dst->imageData[address1 +0]=tb;
			dst->imageData[address1 +1]=tg;
			dst->imageData[address1 +2]=tr;

	}}

	cvCopy(dst,p0[0]);

	}//������

	clock_t time6 = clock();
	double total_time5 = (double)(time6-time5)/CLOCKS_PER_SEC;
	printf("3�K�w: %g sec.\n", total_time5);


	cvCopy(p0[0], p0[1]);


//******************************************************************************************************
//******************************************************************************************************



	//��YCbCr��BGR
	cvCvtColor(p0[0],p0[0],CV_YCrCb2BGR);

	return p0[0];
}



//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter
void NR3class::SaveResult(char*fn,IplImage*dst){

	

	 //replace file extension of original filename
	char out_file_fn[256]; strcpy(out_file_fn, fn);	
	char* code = strtok(out_file_fn, ".");								//reject file extrension
	printf("all_file[counts]:%s,	code:%s\n",fn, code);

	strcpy(out_file_fn,code);
	char str2[256]="_3DNR.tif";	strcat(out_file_fn,str2);
	sprintf(dammy,"%s\\%s",anote_outf,out_file_fn);	


	printf("output:%s\n",dammy);
	cvSaveImage(dammy,dst);
}

//================================================================================//
//NR3
// constructor		
//Initialize STIP parameter
void NR3class::ReleaseBuffer(){

	//���
	cvReleaseImage(p0);
	cvReleaseImage(p);
	cvReleaseImage(pp);
	cvReleaseImage(&re_img0);
	cvReleaseImage(&re_img);
	cvReleaseImage(&re_img2);
	cvReleaseImage(&noise_img0);
	cvReleaseImage(&noise_img);
	cvReleaseImage(&noise_img2);
	cvReleaseImage(&dst);

	free(d_coef1);
	free(d_coef2);
	free(x_coef2);
	free(x_coef3);

}