﻿#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"
#include "opencv\\highgui.h"
#include "opencv\\cv.h"
#include "opencv\\cxcore.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <tchar.h>
#include <ctype.h>
#include <vector>

#include <iostream>
#include <shlwapi.h>
#include <direct.h>
#include <math.h>
#include <time.h>



#define INT_MAX_ 100000
#define MAX_WORD_NUM 128
#define MAX_FILE_NUM 1000//500


int readfolda(char * mosimosi, char all_file[MAX_FILE_NUM][MAX_WORD_NUM]);




//================================================================================//
//フォルダ内ファイル名の一括読み込み

int readfolda(char * mosimosi, char all_file[MAX_FILE_NUM][MAX_WORD_NUM]){

	HANDLE hFind;
	WIN32_FIND_DATA findData={0};//フォルダ内一括読み込み

	int i=0,j=0;

	hFind = FindFirstFile (mosimosi, &findData);
	if (hFind == INVALID_HANDLE_VALUE){
//		fprintf(stderr,"FindFirstFile() failed.");
	}
	else
	{
      do
      {
          if(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
          {
//         fprintf(stderr,"directory=%s\n",findData.cFileName);
          }else{
				// findData.cFileNameにファイル名、ディレクトリ名が入っている
				printf("file=%s\n",findData.cFileName);
				strcpy(all_file[j], findData.cFileName);
				i=i+1;
				j=j+1;
		  }
	  }
      while (FindNextFile(hFind, &findData));   //　次を捜す // ★
      CloseHandle (hFind); // ★
    }
	return i;
}


//================================================================================//
//文字列置換



void strchg(char *buf, const char *str1, const char *str2)
{
  char tmp[1024 + 1];
  char *p;

  while ((p = strstr(buf, str1)) != NULL) {
      /* 見つからなくなるまで繰り返す
            pは旧文字列の先頭を指している */
    *p = '¥0'; /* 元の文字列を旧文字列の直前で区切って */
    p += strlen(str1);  /* ポインタを旧文字列の次の文字へ */
    strcpy(tmp, p);             /* 旧文字列から後を保存 */
    strcat(buf, str2);  /* 新文字列をその後につなぎ */
    strcat(buf, tmp);   /* さらに残りをつなぐ */
  }
}


