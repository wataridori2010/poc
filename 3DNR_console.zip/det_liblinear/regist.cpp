#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/opencv.hpp"

#define OPENCV_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#define OPENCV_VERSION_CODE OPENCV_VERSION(CV_MAJOR_VERSION, CV_MINOR_VERSION, CV_SUBMINOR_VERSION)

#if OPENCV_VERSION_CODE>=OPENCV_VERSION(2,4,0)
#include <opencv2/nonfree/features2d.hpp>
#endif


//#include <cv.h>
//#include <highgui.h>


#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>
#include <mmsystem.h>

#include <iostream>
#include <fstream>

#include <time.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>


using namespace std;



#define ORB_
//#define SURF_
//#define SIFT_

/*
#include <opencv2/opencv.hpp>
//#include <opencv2/nonfree/nonfree.hpp>
 
// --------------------------------------------------------------------------
// main(Number of arguments, Argument values)
// Description  : This is the entry point of the program.
// Return value : SUCCESS:0  ERROR:-1
// --------------------------------------------------------------------------
int main(int argc, char **argv)
{
//    cv::Mat imgA = cv::imread("lenna.png");
//    cv::Mat imgB = cv::imread("lenna_rotated.png");
    cv::Mat imgA = cv::imread(argv[1]);
    cv::Mat imgB = cv::imread(argv[2]);
 

#ifdef ORB_
    cv::OrbFeatureDetector detector(5);
    cv::OrbDescriptorExtractor extractor;
#endif
#ifdef SURF_
	cv::SurfFeatureDetector detector(3000);
	cv::SurfDescriptorExtractor extractor;
#endif

#ifdef SIFT_
	cv::SiftFeatureDetector detector(2000);
	cv::SiftDescriptorExtractor extractor;
#endif
    // �����_���o
    cv::Mat descriptorsA, descriptorsB;
    std::vector<cv::KeyPoint> keypointsA, keypointsB;
    detector.detect(imgA, keypointsA);
    detector.detect(imgB, keypointsB);
    extractor.compute(imgA, keypointsA, descriptorsA);
    extractor.compute(imgB, keypointsB, descriptorsB);
 
    // �}�b�`���O
    std::vector<cv::DMatch> matches;
#ifdef ORB_
    cv::BFMatcher matcher(cv::NORM_HAMMING, true);
#endif
#ifdef SURF_
    cv::BFMatcher matcher(cv::NORM_L2, true);
#endif
#ifdef SIFT_
    cv::BFMatcher matcher(cv::NORM_L2, true);
#endif

    matcher.match(descriptorsA, descriptorsB, matches);
 
    // �ő�E�ŏ�����
    double max_dist = 0; double min_dist = DBL_MAX;
    for (int j = 0; j < (int)matches.size(); j++){ 
        double dist = matches[j].distance;
        if (dist < min_dist) min_dist = dist;
        if (dist > max_dist) max_dist = dist;
    }
 
    // �ǂ��y�A�̂ݎc��
    double cutoff = 3.0 * (min_dist + 1.0);
    std::set<int> existing_trainIdx;
    std::vector<cv::DMatch> matches_good;
    for (int j = 0; j < (int)matches.size(); j++) { 
        if (matches[j].trainIdx <= 0) matches[j].trainIdx = matches[j].imgIdx;
        if (matches[j].distance > 0.0 && matches[j].distance < cutoff) {
            if (existing_trainIdx.find(matches[j].trainIdx) == existing_trainIdx.end() && matches[j].trainIdx >= 0 && matches[j].trainIdx < (int)keypointsB.size()) {
                matches_good.push_back(matches[j]);
                existing_trainIdx.insert(matches[j].trainIdx);
            }
        }
    }
 
    // �\��
    cv::Mat matchImage;
    cv::drawMatches(imgA, keypointsA, imgB, keypointsB, matches_good, matchImage, cv::Scalar::all(-1), cv::Scalar::all(-1), std::vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
    cv::imshow("match", matchImage);
    cv::waitKey(0);
 
    return 0;
}


*/

#include <opencv2/opencv.hpp>
 
// --------------------------------------------------------------------------
// main(Number of arguments, Argument values)
// Description  : This is the entry point of the program.
// Return value : SUCCESS:0  ERROR:-1
// --------------------------------------------------------------------------
int main(int argc, char **argv)
{
#ifdef ORB_
    cv::OrbFeatureDetector detector;
    cv::OrbDescriptorExtractor extractor;
	char fn[256]="orb";

#endif
#ifdef SURF_
	cv::SurfFeatureDetector detector(2000);
	cv::SurfDescriptorExtractor extractor;
	char fn[256]="surf";
#endif

#ifdef SIFT_
	cv::SiftFeatureDetector detector(1);
	cv::SiftDescriptorExtractor extractor;
	char fn[256]="sift";
#endif 
    // �ǂݍ���
//    cv::Mat image1 = cv::imread("box.png");
//    cv::Mat image2 = cv::imread("box_in_scene.png");
    cv::Mat image1 = cv::imread(argv[1]);
    cv::Mat image2 = cv::imread(argv[2]);

 
    // �����_1
    std::vector<cv::KeyPoint> keypointsA;
    cv::Mat descriptorsA;
    detector.detect(image1, keypointsA);
    extractor.compute(image1, keypointsA, descriptorsA);
 
    // �����_2
    std::vector<cv::KeyPoint> keypointsB;
    cv::Mat descriptorsB;
    detector.detect(image2, keypointsB);
    extractor.compute(image2, keypointsB, descriptorsB);
 


    // �}�b�`���O
#ifdef ORB_
    cv::BFMatcher matcher(cv::NORM_HAMMING2, true);
#endif
#ifdef SURF_
    cv::BFMatcher matcher(cv::NORM_L2, true);
#endif
#ifdef SIFT_
    cv::BFMatcher matcher(cv::NORM_L2, true);
//	  cv::FlannBasedMatcher matcher;
#endif	

    std::vector<cv::DMatch> matches;
    matcher.match(descriptorsA, descriptorsB, matches);


    // �ŏ�����
    double min_dist = DBL_MAX;
    for (int i = 0; i < (int)matches.size(); i++) { 
        double dist = matches[i].distance;
        if (dist < min_dist) min_dist = dist;
    }
 
    // �ǂ��y�A�̂ݎc��
    std::vector<cv::DMatch> good_matches;
	if(min_dist==0)min_dist=1;

    for (int i = 0; i < (int)matches.size(); i++){
        if (matches[i].distance < 5.0 * min_dist) good_matches.push_back(matches[i]);
    }

/*
	std::vector<std::vector<cv::DMatch>> matches;
	int k=2;
	matcher.knnMatch(descriptorsA, descriptorsB, matches,k);

	// �ŏ�����
    double min_dist = DBL_MAX;
	printf("matches.size(): %d\n",(int)matches.size());//image1�̓����_�̐�
    for (int i = 0; i < (int)matches.size(); i++) {

		 for (int j = 0; j < k; j++) {
			printf("%f,",matches[i][j].distance);

	        double dist = matches[i][j].distance;
	        if (dist < min_dist) min_dist = dist;
		 }
		printf("\n");

    }
 
    // �ǂ��y�A�̂ݎc��
    std::vector<cv::DMatch> good_matches;
    for (int i = 0; i < (int)matches.size(); i++) { 
//			if (matches[i][0].distance < 3.0 * min_dist) good_matches.push_back(matches[i][0]);
			if (matches[i][0].distance/matches[i][1].distance < 0.8) good_matches.push_back(matches[i][0]);
    }
*/



    // �\���ȑΉ��_������ꍇ�A�Ή�����g��\��(image2���㏑�������Ⴄ)
    if (good_matches.size() > 10) {
        std::vector<cv::Point2f> obj, scene;
        for (int i = 0; i < (int)good_matches.size(); i++) {
            obj.push_back(keypointsA[good_matches[i].queryIdx].pt);
            scene.push_back(keypointsB[good_matches[i].trainIdx].pt);
        }
 
        // �z���O���t�B�[�s����v�Z
        cv::Mat H = cv::findHomography(obj, scene, cv::RANSAC);
        //std::cout << H << std::endl;
 
        // �s�񂪋�ł͂Ȃ�
        if (!H.empty()) {
            std::vector<cv::Point2d> obj_corners(4), scene_corners(4);
            obj_corners[0] = scene_corners[0] = cv::Point2d(0,           0);
            obj_corners[1] = scene_corners[1] = cv::Point2d(image1.cols, 0);
            obj_corners[2] = scene_corners[2] = cv::Point2d(image1.cols, image1.rows );
            obj_corners[3] = scene_corners[3] = cv::Point2d(0,           image1.rows);
 
            // �z���O���t�B�s��̐���
//			cv::invert(H,H,CV_SVD);
            cv::perspectiveTransform(obj_corners, scene_corners, H);
 
            // �΂̐��ň͂� (�J�n�_�����摜�����ɂ���̂ŉE�ɃI�t�Z�b�g)
            cv::line(image2, scene_corners[0] , scene_corners[1] , cv::Scalar(0, 255, 0), 4);
            cv::line(image2, scene_corners[1] , scene_corners[2] , cv::Scalar(0, 255, 0), 4);
            cv::line(image2, scene_corners[2] , scene_corners[3] , cv::Scalar(0, 255, 0), 4);
            cv::line(image2, scene_corners[3] , scene_corners[0] , cv::Scalar(0, 255, 0), 4);
        }
    }
 
 
    // �Ή��_�̕\��
    cv::Mat img_matches;
    cv::drawMatches(image1, keypointsA, image2, keypointsB, good_matches, img_matches, cv::Scalar::all(-1), cv::Scalar::all(-1), std::vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
//    cv::drawMatches(image1, keypointsA, image2, keypointsB, matches, img_matches, cv::Scalar::all(-1), cv::Scalar::all(-1), std::vector<char>(), cv::DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);

    // �\��
    cv::imshow("camera", img_matches);
    cv::waitKey(200);


	strcat(fn,"_"); strcat(fn,argv[3]);	strcat(fn,".png");//���ʉ摜�o��
	cv::imwrite(fn,img_matches);
 
    return 0;
}