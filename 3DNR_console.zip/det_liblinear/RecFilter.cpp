#include "cv.h"
#include "highgui.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main (int argc, char **argv){  




	int i,j; 
	int s=0,t=0;

 
	IplImage *src,*src2,*dst;
	int counts=0;




	//�t�@�C���̐ݒ�
//	CvCapture* capture = cvCaptureFromAVI("F:\\����_�����_�ɂ��ʒu���킹\\05-07.avi");
//	CvCapture* capture = cvCaptureFromAVI("F:\\����_�����_�ɂ��ʒu���킹\\0001_2.avi");
//	CvCapture* capture = cvCaptureFromAVI("F:\\����_�����_�ɂ��ʒu���킹\\DSCF1489.avi");
//	CvCapture* capture = cvCaptureFromAVI("F:\\����_�����_�ɂ��ʒu���킹\\bench_3.avi");
//	CvCapture* capture = cvCaptureFromAVI("F:\\��ʑ̒ǔ�_����\\AVI\\water_BK#7.avi");
//	CvCapture* capture = cvCaptureFromAVI("C:\\Video\\test_sample\\Senoo.avi");
//	CvCapture* capture = cvCaptureFromAVI("C:\\DSC_0590_NRoff.avi");
	CvCapture* capture = cvCaptureFromAVI("G:\\3DNR����\\091030_NC9�Î~��pNR\\bmp\\DSC_0593_full.avi");




//	capture+=10;


	//AVI�o��-------------------------------------------------
	int l=0;
    CvVideoWriter* VideoWriter = NULL;
    char* filename2 = "G:\\test_nr.avi";     // �o�̓t�@�C����
    double fps = 24.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------	


//	cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES , 20 );



for(counts=0;counts<220;counts++){

	//�摜��荞��
	if(NULL==(src=cvQueryFrame(capture))){
		     break;
	}

	printf("counts:%d\n",counts);


	cvCvtColor(src, src, CV_BGR2YCrCb);//�e���v���[�g

	//�����I�ȏ���
	if(counts==0){

		src2 = cvCloneImage(src);
		dst = cvCloneImage(src);

	}





	int ad[2];
	int adp=0;
	int size=src->widthStep*src->height;
	int p=0;
	float inc1=0;
	float inc2=0;
	uchar value1[3];
	uchar value2[3];

	float value1_ave[3];
	float value2_ave[3];

	float w_value[3];

	float rate=0.3;

	//臒l
	float Dth=20;


	for(i=0;i<src->height;i++){

		ad[0]=i*src->widthStep;
		for(j=0;j<src->widthStep;j=j+3){


				value1_ave[0]=0;
				value1_ave[1]=0;
				value1_ave[2]=0;
				value2_ave[0]=0;
				value2_ave[1]=0;
				value2_ave[2]=0;


				ad[1]=ad[0]-src->widthStep+j-3;
//				ad[1]=ad[0]+j;

				inc1=0;
				inc2=0;
				for(s=-1;s<2;s++){
//				for(s=0;s<1;s++){


					p=0;
					for(t=-1;t<2;t++){
//					for(t=0;t<1;t++){

							
						if(	((ad[1]+p)>=0)&&((ad[1]+p)<=size)	){
								value1[0]=		src->imageData[ad[1]+p+0];	
								value1[1]=		src->imageData[ad[1]+p+1];
								value1[2]=		src->imageData[ad[1]+p+2];

								value2[0]=		src2->imageData[ad[1]+p+0];	
								value2[1]=		src2->imageData[ad[1]+p+1];
								value2[2]=		src2->imageData[ad[1]+p+2];

//								dst->imageData[ad[1]+p+0]=(uchar)(value1[0]*rate+(1-rate)*value2[0]);	
//								dst->imageData[ad[1]+p+1]=(uchar)(value1[1]*rate+(1-rate)*value2[1]);
//								dst->imageData[ad[1]+p+2]=(uchar)(value1[2]*rate+(1-rate)*value2[2]);

								
								if(fabs(double(value1[0]-(uchar)src->imageData[ad[0]+j]))<Dth){
									inc1+=1;
									value1_ave[0]+=value1[0];
									value1_ave[1]+=value1[1];
									value1_ave[2]+=value1[2];
								}
							/*	else{
									inc1+=1;
									value1_ave[0]+=(uchar)src->imageData[ad[0]+j+0];
									value1_ave[1]+=(uchar)src->imageData[ad[0]+j+1];
									value1_ave[2]+=(uchar)src->imageData[ad[0]+j+2];
								}
							*/
								if(fabs(double(value2[0]-(uchar)src2->imageData[ad[0]+j]))<Dth){
									inc2+=1;
									value2_ave[0]+=value2[0];
									value2_ave[1]+=value2[1];
									value2_ave[2]+=value2[2];
								}
							/*	else{
									inc2+=1;
									value2_ave[0]+=(uchar)src2->imageData[ad[0]+j+0];
									value2_ave[1]+=(uchar)src2->imageData[ad[0]+j+1];
									value2_ave[2]+=(uchar)src2->imageData[ad[0]+j+2];
								}
							*/
	

						}

					p+=3;	
					}

				ad[1]+=src->widthStep;
				}	


		
				if(inc1>0 && inc2>0 ){
							value1_ave[0]/=inc1;
							value1_ave[1]/=inc1;
							value1_ave[2]/=inc1;
							value2_ave[0]/=inc2;
							value2_ave[1]/=inc2;
							value2_ave[2]/=inc2;

							if( fabs(value1_ave[0]-value2_ave[0])>Dth ){

								dst->imageData[ad[0]+j+0]=(uchar)src->imageData[ad[0]+j+0];	
								dst->imageData[ad[0]+j+1]=(uchar)src->imageData[ad[0]+j+1];
								dst->imageData[ad[0]+j+2]=(uchar)src->imageData[ad[0]+j+2];
							}else{
								w_value[0]=(rate*(uchar)src->imageData[ad[0]+j+0]	+(1-rate)*(uchar)src2->imageData[ad[0]+j+0]);
								w_value[1]=(rate*(uchar)src->imageData[ad[0]+j+1]	+(1-rate)*(uchar)src2->imageData[ad[0]+j+1]);
								w_value[2]=(rate*(uchar)src->imageData[ad[0]+j+2]	+(1-rate)*(uchar)src2->imageData[ad[0]+j+2]);
								if(w_value[0]>255){w_value[0]=255;}else if(w_value[0]<0){w_value[0]=0;}
								if(w_value[1]>255){w_value[1]=255;}else if(w_value[1]<0){w_value[1]=0;}
								if(w_value[2]>255){w_value[2]=255;}else if(w_value[2]<0){w_value[2]=0;}

								dst->imageData[ad[0]+j+0]=(uchar)w_value[0];	
								dst->imageData[ad[0]+j+1]=(uchar)w_value[1];
								dst->imageData[ad[0]+j+2]=(uchar)w_value[2];
							}
				}else{
								dst->imageData[ad[0]+j+0]=(uchar)src->imageData[ad[0]+j+0];	
								dst->imageData[ad[0]+j+1]=(uchar)src->imageData[ad[0]+j+1];
								dst->imageData[ad[0]+j+2]=(uchar)src->imageData[ad[0]+j+2];
				}
		}}








  	cvWaitKey (10);
	cvCopy(dst, src2);//�摜�̃R�s�[
	cvCvtColor(dst, dst, CV_YCrCb2BGR);






	cvNamedWindow ("color", 1); 
	cvShowImage ("color", dst); 


	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename2, -1 , 
      fps , cvSize(src->width,src->height) );
	}
	//AVI��������------------------------------------
//      cvWriteFrame(VideoWriter,dst_img);
	    cvWriteFrame(VideoWriter,dst);
//		cvWriteFrame(VideoWriter,vector_window);
	// ----------------------------------------------



}


// �㏈��-----------------------------------
 cvReleaseVideoWriter(&VideoWriter); 
//------------------------------------------

	return 1;
}