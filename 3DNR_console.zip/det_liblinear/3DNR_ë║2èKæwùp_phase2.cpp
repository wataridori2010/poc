//#define movie_out


#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

#include <time.h>
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <windows.h>
#include <vfw.h>
#include <process.h>
#include <commctrl.h>
#include "resource.h"

//�e�X�g�I�ɕt��
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#pragma once

#ifndef _WIN32_WINNT		// Allow use of features specific to Windows XP or later.                   
#define _WIN32_WINNT 0x0501	// Change this to the appropriate value to target other versions of Windows.
#endif						

#include <tchar.h>






float* gauss_filter(float* a, int filter_rad,float sigma);
float* bilat_filter(float* a, int filter_rad,float sigma);



//int DNR(CvCapture* capture,int skip_num, int sl1, int sl2, int sl3,	int pyr ,char* filename2){
int main(int argc, char** argv){	//filename2,pyr,sl1,sl2,sl3


	IplImage* pColorPhotoI = 0; // �J���[�摜


	IplImage *dst=0;	// �������o�C���e�����t�B���^�p



	char* filename2[256];
	strcpy(filename2[256],argv[1]);
	int pyr=atoi(argv[2]);
	int sl1=atoi(argv[3]);//���
	int sl3=atoi(argv[4]);//�F
	int sl2=atoi(argv[5]);//�t���[��

	if(argc<6){
		return 0;
	}





	int counts=0;
	int ex_count=0;

//�t�H���_���̒��o
	int name_count=0;
	char name_ad[256];
	char name_file[256];
	char *name_test;

	//�h���C�u����؂�o��&�R�s�[
	name_test=strtok(filename2[256], "\\");
//	name_test=strtok(argv[1],"\\");
	strcpy(name_ad,name_test);	strcat(name_ad,"\\");
	//�h���C�u���ȉ�
	while( (name_test=strtok(NULL, "\\")) !=NULL ){
		if(name_count>=1){strcat(name_ad,name_file);	strcat(name_ad,"\\");}//2���[�v�ڂ���؂�o������\\�������Ă���
		strcpy(name_file,name_test); //�؂�o�����̃R�s�[���ŏI�I�Ƀt�@�C�����ɂȂ�B
		name_count+=1;


	}



	//AVI�o��-------------------------------------------------
	//�o��AVI�t�@�C�����ݒ�
	char filename3[256];
	strcpy(filename3,name_ad);
//	strcat(filename3,"NR-");
//	strcat(filename3,name_file);
	strcat(filename3,name_file);

	//�p�����[�^�t�����ĕۑ�
	strcat(filename3,"_test_");
	strcat(filename3,"_");
	strcat(filename3,argv[2]);
	strcat(filename3,"_");
	strcat(filename3,argv[3]);
	strcat(filename3,"_");
	strcat(filename3,argv[4]);
	strcat(filename3,"_");
	strcat(filename3,argv[5]);


	strcat(filename3,"_nr.avi");


	int l=0;
    CvVideoWriter* VideoWriter = NULL;
    double fps = 24.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------	




	CvCapture *capture = 0;
	capture = cvCaptureFromAVI(argv[1]);




//1208
	float* x;
	float* b;
	IplImage *src_ini;
	int i,j,judge_value=0;
	int counts_real=0;

	CvSize image_size ;




	//�����̈�m��
	IplImage **p0,**p, **pp;
	p0 = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	p = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	pp = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);

	unsigned char *x_coef3;
	unsigned char **d_coef1,**d_coef2;


	IplImage *re_img0;//,*re_img00; 
	IplImage *re_img;//,*re_img01,*re_img02;
	IplImage *re_img2;

	IplImage *noise_img2,*noise_img,*noise_img0;//�m�C�Y�摜


	FILE* fp=fopen("G:\\3DNR����\\�o�b�`����\\�����p\\sigma.txt","r");
//	float *sig_para=(float*)calloc(256,sizeof(float));
	float sig_para[256];

	if(fp!=NULL){
		for(i=0;i<256;i++){
			fscanf(fp,"%d	%f\n",&counts,&(sig_para[i]));
			printf("%d	%f\n",counts,sig_para[i]);
		}
//		cvWaitKey(100);
	}



for(counts=0;counts<1000;counts++){

	//�t���[���ǂݍ���
	if(NULL==(pColorPhotoI=cvQueryFrame(capture))){
	 break;
	}


	//��BGR2YCbCr��
	cvCvtColor(pColorPhotoI,pColorPhotoI,CV_BGR2YCrCb);


//	cvSmooth(pColorPhotoI,pColorPhotoI,CV_BILATERAL,20,50,0,0);


	float sigmax=(0.1*sl1);//0.7
//	float sigmad1=(0.33*sl3);	//�F���p��//5
//	float sigmad2=(sl3); //�P�x�p��//15
	float sigmad1=(sl3);	//�F���p��//5
	float sigmad2=(sl3); //�P�x�p��//15


	float sigmax2=(0.1*sl1);//0.7
	float frame_dst=0.0;//0.5

//	int epsi1=sl3;	//�F���p臒l//15
//	int epsi=3*sl3;	//�P�x�p臒l//45
	int epsi1=3*sl3;	//�F���p臒l//15
	int epsi=3*sl3;	//�P�x�p臒l//45


	unsigned char t1,t2,t3;
	unsigned char v1,v2,v3;
	int s,t;

	//uint,uchar
	unsigned int rgb[3];
	unsigned int dv3[3];
	unsigned int sum_p[3];
	unsigned int sum=0;
	unsigned char xv=0;
	unsigned char tr,tg,tb;

	unsigned char tim[2];
	tim[0]=10;
	tim[1]=sl2;
	float sl2_inv=(1.0/sl2);


	double t1_level=0;//�m�C�Y���x�����ς���p
	double t2_level=0;//�m�C�Y���x�����ς���p
	double t3_level=0;//�m�C�Y���x�����ς���p

	int width1=pColorPhotoI->width/1.0;
	int width2=pColorPhotoI->width/2.0;
	int width4=pColorPhotoI->width/4.0;
	int height1=pColorPhotoI->height/1.0;
	int height2=pColorPhotoI->height/2.0;
	int height4=pColorPhotoI->height/4.0;

	int address0=0;
	int address1=0;
	int address2=0;
	int address3=0;



//�������t���[���ŉ摜����
	if(counts==0){
		re_img0 = cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);
//		re_img00= cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);
		//�����摜����
		for(int num=0; num<2; num++){
		p0[num]		 = cvCloneImage(pColorPhotoI);//
		}

		re_img=cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img,CV_INTER_LINEAR);
		cvResize(pColorPhotoI,re_img,CV_INTER_NN);

		//�����摜����
		for(int num=0; num<2; num++){
		p[num]		 = cvCloneImage(re_img);//
		}

		re_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img2,CV_INTER_LINEAR);
		cvResize(re_img,re_img2,CV_INTER_NN);

		noise_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
		noise_img =cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
		noise_img0 =cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);

		//�����摜����
		for(int num=0; num<2; num++){
		pp[num]		 = cvCloneImage(re_img2);//
		}

		//�������ʉ摜
		dst		 = cvCloneImage(pColorPhotoI);//


		//�t�B���^�W���̈�
		d_coef1=(unsigned char**)calloc(2,sizeof(unsigned char*));
		d_coef2=(unsigned char**)calloc(2,sizeof(unsigned char*));
		*(d_coef1+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef1+1)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+1)=(unsigned char*)calloc(512,sizeof(unsigned char));

		//�����t���[���p
		//�P�x�p
		for(int num=0;num<512;num++){
			if(	(num-255)>-epsi	&&	(num-255)<epsi){
				d_coef2[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2));
			}
			else{
//				d_coef2[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2));
				d_coef2[0][num]=0;
			}
		}
		//�F���p
		for(int num=0;num<512;num++){
			if(	(num-255)>-epsi1	&&	(num-255)<epsi1){
				d_coef1[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1));
			}else{
//				d_coef1[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1));
				d_coef1[0][num]=0;
			}
		}


		//���ߋ��t���[���p
		//�P�x�p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(epsi*sl2_inv)	&&	(num-255)<(epsi*sl2_inv)){
				d_coef2[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2*sl2_inv*sl2_inv));
			}else{
				d_coef2[1][num]=0;
			}
		}
		//�F���p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(epsi1*sl2_inv)	&&	(num-255)<(epsi1*sl2_inv)){
				d_coef1[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1*sl2_inv*sl2_inv));
			}else{
				d_coef1[1][num]=0;
			}
		}
		//��ԕ����p
		x_coef3=(unsigned char*)calloc(25,sizeof(unsigned char));
		for(s=0;s<5;s++){
			for(t=0;t<5;t++){
				x_coef3[s*5+t]=255*exp(( (-1)*((2-s)*(2-s)+(2-t)*(2-t)) )/(2*sigmax*sigmax));
		}}
//		x_coef3=(unsigned char*)calloc(121,sizeof(unsigned char));
//		for(s=0;s<11;s++){
//			for(t=0;t<11;t++){
//				x_coef3[s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax*sigmax));
//		}}



	}



	int i2,j2;
	int i4,j4;
	int i8,j8;
	int i16,j16;

	int heikin[3];

	int tt1,tt2,tt3;
	int ttt1,ttt2,ttt3;

	// Get current time. We will use it later to obtain total calculation time.
	clock_t time1 = clock();


///************************************************************************************************************************//
//************************************************************************************************************************//
	//�摜�̃R�s�[(���摜�T�C�Y)
//	cvCopy(p0[0],p0[1]);
	cvCopy(pColorPhotoI, p0[0]);

	//�摜�̃R�s�[(1/2�摜�T�C�Y)
	cvResize(pColorPhotoI,p[0],CV_INTER_LINEAR);
	cvCopy(p[0],re_img);


	//�摜�̃R�s�[(1/4�摜�T�C�Y)
	cvResize(p[0],pp[0],CV_INTER_LINEAR);
	cvCopy(pp[0],re_img2);



//��1226�ǉ�
	cvCopy(pColorPhotoI,dst);


///*************************************************************************************************************************//

	clock_t time2 = clock();
	double total_time1 = (double)(time2-time1)/CLOCKS_PER_SEC;
	printf("Caclulation time1: %g sec.\n", total_time1);


//���m�C�Y���x������
	t1_level=0;
	t2_level=0;
	t3_level=0;


//3DNR(1/4�k���摜�ɂ���)
//	for(i4=2;i4<height4-3;i4++){
	for(i4=0;i4<height4;i4++){

		address0=i4*pp[0]->widthStep;

//		for(j4=2;j4<width4-3;j4++){
		for(j4=0;j4<width4;j4++){

			address1=address0 + 3*j4;

			t1=(uchar)pp[0]->imageData[address1 +0];
			t2=(uchar)pp[0]->imageData[address1 +1];
			t3=(uchar)pp[0]->imageData[address1 +2];

			tb=t1;tg=t2;tr=t3;

			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<2;num++){

				address2=address1-(2*pp[0]->widthStep);
				for(s=-2;s<3;s++){


				address3=address2-6;
				for(t=-2;t<3;t++){

						if( (address3>=0)&&(address3<=pp[num]->widthStep*pp[num]->height) ){


						//��ԋ����ɂ��d�݂Â�
						xv=x_coef3[(s+2)*5+(t+2)];


						v1=(uchar)pp[num]->imageData[address3 +0];
						v2=(uchar)pp[num]->imageData[address3 +1];
						v3=(uchar)pp[num]->imageData[address3 +2];


						//�F�������ɂ��d�ݕt��
//						dv3[0]=d_coef2[255+int(alpha*(v1-t1))];
//						dv3[1]=d_coef2[255+int(alpha*(v2-t2))];
//						dv3[2]=d_coef2[255+int(alpha*(v3-t3))];
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];
//						dv3[0]=xv;
//						dv3[1]=xv;
//						dv3[2]=xv;

						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];

						

						}
						address3+=3;

					}//t
					address2+=pp[0]->widthStep;

				}//s
			}


//			tb=uchar(t1);
//			tg=uchar(t2);
//			tr=uchar(t3);

//			tb=uchar(rgb[0]/sum_p[0]);
//			tg=uchar(rgb[1]/sum_p[1]);
//			tr=uchar(rgb[2]/sum_p[2]);

			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=(rgb[2] +dv3[2])/sum_p[2];}


			//2�Ԃ��1NR�摜
			re_img2->imageData[address1 +0]=tb;
			re_img2->imageData[address1 +1]=tg;
			re_img2->imageData[address1 +2]=tr;
//			pp[0]->imageData[address1 +0]=tb;
//			pp[0]->imageData[address1 +1]=tg;
//			pp[0]->imageData[address1 +2]=tr;

			//�m�C�Y�摜
			noise_img2->imageData[address1 +0]=uchar(128+tb-t1);
			noise_img2->imageData[address1 +1]=uchar(128+tg-t2);
			noise_img2->imageData[address1 +2]=uchar(128+tr-t3);
//			noise_img2->imageData[address1 +0]=(uchar)(tb);
//			noise_img2->imageData[address1 +1]=(uchar)(tg);
//			noise_img2->imageData[address1 +2]=(uchar)(tr);


			//���m�C�Y���x�����ς���
			t1_level+=abs(t1-tb);
			t2_level+=abs(t2-tg);
			t3_level+=abs(t3-tr);

	}}


	//���m�C�Y���x�����ς���
	t1_level/=((pColorPhotoI->height/4.0)*(pColorPhotoI->width/4.0));
	t2_level/=((pColorPhotoI->height/4.0)*(pColorPhotoI->width/4.0));
	t3_level/=((pColorPhotoI->height/4.0)*(pColorPhotoI->width/4.0));

//	printf("	,t1_level:%lf,t2_level:%lf,t3_level:%lf\n",t1_level,t2_level,t3_level);


//	cvSmooth(pp[0],re_img2,CV_BILATERAL,20,50,0,0);


	//��1027
	cvCopy(re_img2, pp[1]);
//	cvCopy(pp[0], pp[1]);

	// (1/4)��(1/2)�Ƀ��T�C�Y
	//��1027
	cvResize(noise_img2,noise_img,CV_INTER_LINEAR);

	clock_t time3 = clock();
	double total_time2 = (double)(time3-time2)/CLOCKS_PER_SEC;
	printf("1�K�w: %g sec.\n", total_time2);

//*************************************************************************************************************************//


//���m�C�Y���x�����ς���
	t1_level=0;
	t2_level=0;
	t3_level=0;



	
//��
//3DNR(1/2�k���摜�ɂ���)
	address1=0;
	address0=0;

/*
	for(i2=0;i2<height2;i2++){

		address1=address0;
		for(j2=0;j2<width2;j2++){


//			address0=i2*p[0]->widthStep + 3*j2;

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p[0]->imageData[address1 +0]+(uchar)noise_img->imageData[address1 +0]-128;
			ttt2=(uchar)p[0]->imageData[address1 +1]+(uchar)noise_img->imageData[address1 +1]-128;
			ttt3=(uchar)p[0]->imageData[address1 +2]+(uchar)noise_img->imageData[address1 +2]-128;
//			ttt1=(uchar)noise_img->imageData[address0 +0];
//			ttt2=(uchar)noise_img->imageData[address0 +1];
//			ttt3=(uchar)noise_img->imageData[address0 +2];

			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p[0]->imageData[address1 +0]=(uchar)t1;
			p[0]->imageData[address1 +1]=(uchar)t2;
			p[0]->imageData[address1 +2]=(uchar)t3;

		address1+=3;
		}
	address0+=p[0]->widthStep;
	}
*/

//for(i2=7;i2<height2-9;i2++){
for(i2=0;i2<height2;i2++){

	address0=i2*p[0]->widthStep;

//	for(j2=7;j2<width2-9;j2++){
	for(j2=0;j2<width2;j2++){

			address1=address0 + 3*j2;

//			t1=(uchar)p[0]->imageData[address1 +0];
//			t2=(uchar)p[0]->imageData[address1 +1];
//			t3=(uchar)p[0]->imageData[address1 +2];
			t1=((uchar)p[0]->imageData[address1 +0]+(uchar)re_img->imageData[address1 +0])/2.0;
			t2=((uchar)p[0]->imageData[address1 +1]+(uchar)re_img->imageData[address1 +1])/2.0;
			t3=((uchar)p[0]->imageData[address1 +2]+(uchar)re_img->imageData[address1 +2])/2.0;


			tb=t1;tg=t2;tr=t3;

			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<2;num++){

//				address2=address1-5*p[0]->widthStep;//(11,11)�̃t�B���^�̏ꍇ
				address2=address1-3*p[0]->widthStep;//(5,5)�̃t�B���^�̏ꍇ
//				address2=address1-p[0]->widthStep;//(3,3)�̃t�B���^�̏ꍇ
				for(s=-3;s<4;s++){
//				for(s=-2;s<3;s++){
//				for(s=-1;s<2;s++){


				address3=address2-9;
				for(t=-3;t<4;t++){
//				address3=address2-6;
//				for(t=-2;t<3;t++){
//				address3=address2-3;
//				for(t=-1;t<2;t++){
						
						if( (address3>=0)&&(address3<=p[num]->widthStep*p[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
//						xv=x_coef3[(s+2)*5+(t+2)];
						xv=1;
//						xv=x_coef3[(s+5)*11+(t+5)];


						v1=(uchar)p[num]->imageData[address3 +0];
						v2=(uchar)p[num]->imageData[address3 +1];
						v3=(uchar)p[num]->imageData[address3 +2];


						//�F�������ɂ��d�ݕt��
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];

						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];


						}
						address3+=3;

					}//t
					address2+=p[0]->widthStep;

				}//s
			}



			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=(rgb[2] +dv3[2])/sum_p[2];}

			//2�Ԃ��1NR�摜
			re_img->imageData[address1 +0]=tb;
			re_img->imageData[address1 +1]=tg;
			re_img->imageData[address1 +2]=tr;
//			p[0]->imageData[address1 +0]=tb;
//			p[0]->imageData[address1 +1]=tg;
//			p[0]->imageData[address1 +2]=tr;

			noise_img->imageData[address1 +0]+=(tb-t1);
			noise_img->imageData[address1 +1]+=(tg-t2);
			noise_img->imageData[address1 +2]+=(tr-t3);
//			noise_img->imageData[address1 +0]=(uchar)(tb);
//			noise_img->imageData[address1 +1]=(uchar)(tg);
//			noise_img->imageData[address1 +2]=(uchar)(tr);



			//���m�C�Y���x�����ς���
			t1_level+=abs(t1-tb);
			t2_level+=abs(t2-tg);
			t3_level+=abs(t3-tr);

	}}



	//���m�C�Y���x�����ς���
	t1_level/=((pColorPhotoI->height/2.0)*(pColorPhotoI->width/2.0));
	t2_level/=((pColorPhotoI->height/2.0)*(pColorPhotoI->width/2.0));
	t3_level/=((pColorPhotoI->height/2.0)*(pColorPhotoI->width/2.0));

//	printf("	,t1_level:%lf,t2_level:%lf,t3_level:%lf\n",t1_level,t2_level,t3_level);

//	cvSmooth(p[0],re_img,CV_BILATERAL,20,50,0,0);

	//��1027
	cvCopy(re_img, p[1]);
//	cvCopy(p[0], p[1]);


	//��1027
	cvResize(noise_img,noise_img0,CV_INTER_LINEAR);


	clock_t time5 = clock();
	double total_time4 = (double)(time5-time3)/CLOCKS_PER_SEC;
	printf("2�K�w: %g sec.\n", total_time4);



//*************************************************************************************************************************//

	//���m�C�Y���x�����ς���
//	t1_level=0;
//	t2_level=0;
//	t3_level=0;

	address1=0;
	address0=0;
	//3DNR(�t���X�P�[��)
//	for(i=14;i<height1-18;i++){
//		for(j=14;j<width1-18;j++){
	for(i=0;i<height1;i++){

		address1=address0;
		for(j=0;j<width1;j++){


//			address0=i*p0[0]->widthStep + 3*j;

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p0[0]->imageData[address1 +0]+(uchar)noise_img0->imageData[address1 +0]-128;
			ttt2=(uchar)p0[0]->imageData[address1 +1]+(uchar)noise_img0->imageData[address1 +1]-128;
			ttt3=(uchar)p0[0]->imageData[address1 +2]+(uchar)noise_img0->imageData[address1 +2]-128;
//			ttt1=(uchar)noise_img0->imageData[address0 +0];
//			ttt2=(uchar)noise_img0->imageData[address0 +1];
//			ttt3=(uchar)noise_img0->imageData[address0 +2];
//			ttt1=(uchar)p0[0]->imageData[address0 +0];
//			ttt2=(uchar)p0[0]->imageData[address0 +1];
//			ttt3=(uchar)p0[0]->imageData[address0 +2];



			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p0[0]->imageData[address1 +0]=(uchar)t1;
			p0[0]->imageData[address1 +1]=(uchar)t2;
			p0[0]->imageData[address1 +2]=(uchar)t3;

		address1+=3;
		}
	address0+=p0[0]->widthStep;
	}


	//��������2�K�w�̏ꍇ��������
	if(pyr == 2){

	address1=0;
	address0=0;
//	for(i=16;i<height1-20;i++){
	for(i=0;i<height1;i++){

		address0=i*p0[0]->widthStep;

//		for(j=16;j<width1-20;j++){
		for(j=0;j<width1;j++){


			address1=address0 + 3*j;

			t1=(uchar)p0[0]->imageData[address1 +0];
			t2=(uchar)p0[0]->imageData[address1 +1];
			t3=(uchar)p0[0]->imageData[address1 +2];

			tb=t1;tg=t2;tr=t3;


			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<2;num++){

				address2=address1-2*p0[0]->widthStep;//(5,5)�̃t�B���^
				for(s=-2;s<3;s++){
//				address2=address1-p0[0]->widthStep;//(3,3)�̃t�B���^
//				for(s=-1;s<2;s++){
//				address2=address1;//(1,1)�̃t�B���^
//				for(s=0;s<1;s++){


				address3=address2-6;//(5,5)�̃t�B���^
				for(t=-2;t<3;t++){
//				address3=address2-3;//(3,3)�̃t�B���^
//				for(t=-1;t<2;t++){
//				address3=address2;//(1,1)�̃t�B���^
//				for(t=0;t<1;t++){


						if( (address3>=0)&&(address3<=p0[num]->widthStep*p0[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
						xv=x_coef3[(s+2)*5+(t+2)];
//						xv=x_coef3[(s+5)*11+(t+5)];
//						xv=1;


						v1=(uchar)p0[num]->imageData[address3 +0];
						v2=(uchar)p0[num]->imageData[address3 +1];
						v3=(uchar)p0[num]->imageData[address3 +2];

						//�F�������ɂ��d�ݕt��
						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
						dv3[2]=xv*d_coef1[num][255+(v3-t3)];


						rgb[0]+=dv3[0]*v1; 
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];


						}
						address3+=3;

					}//t
					address2+=p0[0]->widthStep;

				}//s
			}



			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=(rgb[2] +dv3[2])/sum_p[2];}

//			dst->imageData[(i)*dst->widthStep + 3*(j) +0]=0;
			dst->imageData[address1 +0]=tb;
//			dst->imageData[(i)*dst->widthStep + 3*(j) +0]=(uchar)(t1);
			dst->imageData[address1 +1]=tg;
//			dst->imageData[(i)*dst->widthStep + 3*(j) +1]=(uchar)(t2);
			dst->imageData[address1 +2]=tr;
//			dst->imageData[(i)*dst->widthStep + 3*(j) +2]=(uchar)(t3);
//			dst->imageData[(i)*dst->widthStep + 3*(j) +0]=0;
//			p0[0]->imageData[address1 +0]=tb;
//			p0[0]->imageData[address1 +1]=tg;
//			p0[0]->imageData[address1 +2]=tr;

	}}

//	cvSmooth(dst,dst,CV_BILATERAL,20,50,0,0);

	cvCopy(dst,p0[0]);

	}//�������`�F�b�N�{�b�N�X�̃X�L�b�v

	clock_t time6 = clock();
	double total_time5 = (double)(time6-time5)/CLOCKS_PER_SEC;
	printf("3�K�w: %g sec.\n", total_time5);


	cvCopy(p0[0], p0[1]);


//******************************************************************************************************
//******************************************************************************************************
//******************************************************************************************************
//******************************************************************************************************


//	cvSmooth(dst,dst,CV_GAUSSIAN,5,5,0.1,5);



//#ifdef movie_out

	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename3, CV_FOURCC('D','I','B',' '), 
		fps , cvSize(dst->width,dst->height) );

		}
	//----------------------------------------------
//#endif


	//��BGR2YCbCr��
	cvCvtColor(p0[0],p0[0],CV_YCrCb2BGR);
//	cvCvtColor(re_img,re_img,CV_YCrCb2BGR);
//	cvCvtColor(re_img2,re_img2,CV_YCrCb2BGR);

//#ifdef movie_out

	//AVI��������------------------------------------
		cvWriteFrame(VideoWriter,p0[0]);	//�����t���[���o�C���e����
//		cvWriteFrame(VideoWriter,re_img2);	//�����t���[���o�C���e����
//		cvWriteFrame(VideoWriter,re_img);	//�����t���[���o�C���e����
	//  cvWriteFrame(VideoWriter,dst3);//���J�[�V�u
	// ----------------------------------------------
//#endif


	printf("counts: %d\n", counts);

//	cvNamedWindow("NR�摜",0);//bilatelal�p
//	cvShowImage("NR�摜",p0[0]);//bilatelal�p



	cvWaitKey(10);



	//�������E�B���h�E��������̏���
//	if(destroy_flag==1){
//		break;
//		PostQuitMessage(0);
//	}



}



//#ifdef movie_out
// �㏈��-----------------------------------
 cvReleaseVideoWriter(&VideoWriter); 
//-----------------------------------------
//#endif

	//���

	cvReleaseImage(p0);
	cvReleaseImage(p);
	cvReleaseImage(pp);
	cvReleaseImage(&re_img0);
	cvReleaseImage(&re_img);
	cvReleaseImage(&re_img2);
	cvReleaseImage(&noise_img0);
	cvReleaseImage(&noise_img);
	cvReleaseImage(&noise_img2);
	cvReleaseImage(&dst);

	free(d_coef1);
	free(d_coef2);
	free(x_coef3);

	return 0;


}






float* gauss_filter(float* a, int filter_rad,float sigma){
//	float* a=(float*)calloc(121,sizeof(float));
	int i=0,j=0;
	double dist=0;
	double sum=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			dist=sqrt((double)( (i-filter_rad)*(i-filter_rad) + (j-filter_rad)*(j-filter_rad)) );

//			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));
			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist)/(2*sigma*sigma));
			sum+=*(a + i*(filter_rad*2+1) + j);
		}
	}

	//���K������
	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			*(a + i*(filter_rad*2+1) + j)/=sum;

		}
	}

	return a;
}


float* bilat_filter(float* a, int filter_rad,float sigma){
//	float* a=(float*)calloc(121,sizeof(float));
	int i=0,j=0;
	double dist=0;
	double sum=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			dist=sqrt((double)( (i-filter_rad)*(i-filter_rad) + (j-filter_rad)*(j-filter_rad)) );

//			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));
			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist)/(2*sigma*sigma));
			sum+=*(a + i*(filter_rad*2+1) + j);
		}
	}

	return a;
}
