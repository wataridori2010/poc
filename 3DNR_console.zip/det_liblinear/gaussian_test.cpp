#include "cv.h"
#include "highgui.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//int main (int argc, char **argv){  
void main (){  




	int i,j; 
	int s=0,t=0;

 

	int counts=0;
	float sigma1=20;
	float sigma2=20;
//	float sigma3=20;


	float *gauss1=(float *)calloc(256,sizeof(float));
	float *gauss2=(float *)calloc(256,sizeof(float));
//	float *gauss3=(float *)calloc(256,sizeof(float));

	float *dst=(float *)calloc(256,sizeof(float));


	for(i=0;i<256;i++){
		gauss1[i]=exp(-1*((i-128)*(i-128))/(2*sigma1*sigma1));
		gauss2[i]=exp(-1*((i-128)*(i-128))/(2*sigma2*sigma2));
//		gauss3[i]=exp(-1*((i-128)*(i-128))/(2*sigma3*sigma3));
	}


//	for(s=0;s<256;s++){
		for(i=0;i<256;i++){
			for(j=0;j<256;j++){
				dst[int(0.25*(float)i+0.75*(float)j)]+=(gauss1[i]*gauss2[j]);
//				dst[int(0.333*(float)i+0.333*(float)j+0.333*(float)s)]+=(gauss1[i]*gauss2[j]*gauss3[s]);

			}}
//}


	//dst�̋K�i��
	double max=0;
	int pos=0;
	for(i=0;i<256;i++){
		if(max<dst[i]){max=dst[i];pos=i;}
	}
	for(i=0;i<256;i++){
		dst[i]/=max;
	}

	//dst�̃s�[�N
	printf("pos:%d\n",pos);
	//�΍�����
	double var;
	double sig;
	double sum;

	var=0;sig=0;sum=0;
	for(i=0;i<256;i++){
		var+=((i-128)*(i-128)*gauss1[i]);
		sum+=gauss1[i];
	}
	var/=sum;
	sig=sqrt(var);
	printf("var1:%lf, sig1:%lf\n",var,sig);



	var=0;sig=0;sum=0;
	for(i=0;i<256;i++){
		var+=((i-128)*(i-128)*gauss2[i]);
		sum+=gauss2[i];
	}
	var/=sum;
	sig=sqrt(var);
	printf("var2:%lf, sig2:%lf\n",var,sig);



	var=0;sig=0;sum=0;
	for(i=0;i<256;i++){
		var+=((i-pos)*(i-pos)*dst[i]);
		sum+=dst[i];
	}
	var/=sum;
	sig=sqrt(var);
	printf("var_d:%lf, sig_d:%lf\n",var,sig);



	IplImage *src1,*src2,*dst1;
	src1=cvCreateImage(cvSize(256,256),IPL_DEPTH_8U,1);
	src2=cvCreateImage(cvSize(256,256),IPL_DEPTH_8U,1);
	dst1=cvCreateImage(cvSize(256,256),IPL_DEPTH_8U,1);


		for(j=0;j<256;j++){
			for(i=0;i<256;i++){
				if(i<(255*gauss1[j])){
					src1->imageData[i*src1->widthStep+j]=255;
				}
				if(i<(255*gauss2[j])){
					src2->imageData[i*src2->widthStep+j]=255;
				}

				if(i<(255*dst[j])){
					dst1->imageData[i*dst1->widthStep+j]=255;
				}
		}}


		cvFlip(src1,src1,0);
		cvFlip(src2,src2,0);
		cvFlip(dst1,dst1,0);
		cvSaveImage("C:\\src1.bmp",src1);
		cvSaveImage("C:\\src2.bmp",src2);
		cvSaveImage("C:\\dst1.bmp",dst1);

		cvNamedWindow("src1",1);
		cvShowImage("src1",src1);
		cvNamedWindow("src2",1);
		cvShowImage("src2",src2);

		cvNamedWindow("dst1",1);
		cvShowImage("dst1",dst1);
		
		
		cvWaitKey(0);

}