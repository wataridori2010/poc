#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cv.h>
#include <highgui.h>

int main(int argc, char **argv)
{  
	char *status;  
	int i,j,k, counts,corner_count = 2000;
	int s=0,t=0,times=0;
	CvPoint corners1, corners2;

	CvTermCriteria criteria;
	IplImage *src,*dammy;

	CvCapture* capture = cvCaptureFromAVI("G:\\3DNR����\\100629_�t���b�J�[�H�m�F\\Original_RGB_IB.avi");


	//AVI�o��-------------------------------------------------
	int l=0;
    CvVideoWriter* VideoWriter = NULL;
    char* filename2 = "G:\\test.avi";     // �o�̓t�@�C����
    double fps = 30.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------	

	FILE *fp;
	double qp_ave=0;
	double qp_counts=0;
	FILE* fqp=fopen("G:\\fqp.csv","w");

for(counts=0;counts<220;counts++){


	qp_ave=0;
	qp_counts=0;

	//�摜��荞��
	if(NULL==(src=cvQueryFrame(capture))){
		     break;
	}

//	char word1[256]="G:\\3DNR����\\100629_�t���b�J�[�H�m�F\\MV_TextData_IBBP_5x5_epsi\\";
	char word1[256]="G:\\3DNR����\\100629_�t���b�J�[�H�m�F\\MV_TextData_IBBP\\";

	char word2[256];
	sprintf(word2,"%2d",counts+10);
	strcat(word1,word2);
	strcat(word1,".txt");
	fp=fopen(word1,"r");

	int X,Y,mv_x,mv_y,R,G,B;
	int X1,Y1,mv_x1,mv_y1,dir1,sad1,qp1;
	int X2,Y2,mv_x2,mv_y2,dir2,sad2,qp2;

	if(counts==0){
		dammy=cvCloneImage(src);
	}
	for(i=0;i<src->widthStep*src->height;i++){dammy->imageData[i]=0;}//������

	while(1){
		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X1,&Y1,&mv_x1,&mv_y1,&dir1,&sad1,&qp1)){break;}
		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X2,&Y2,&mv_x2,&mv_y2,&dir2,&sad2,&qp2)){break;}

		if(dir1==0){
			corners1.x=X1;
			corners1.y=src->height-Y1;
			corners2.x=X1+mv_x1;
			corners2.y=src->height-(Y1+mv_y1);
//			cvLine (src, corners1, corners2, CV_RGB (255, 0, 0), 0.4, CV_AA, 0);
			cvCircle(dammy, corners1, 2, CV_RGB (5*qp1,0, 0), 2, 7, 0);

			qp_ave+=qp1;
			qp_counts+=1;

		}else if(dir1==1){
			corners1.x=X2;
			corners1.y=src->height-Y2;
			corners2.x=X2+mv_x2;
			corners2.y=src->height-(Y2+mv_y2);
//			cvLine (src, corners1, corners2, CV_RGB (0, 255, 0), 0.4, CV_AA, 0);
			cvCircle(dammy, corners1, 2, CV_RGB (5*qp2,0,0), 2, 7, 0);

			qp_ave+=qp2;
			qp_counts+=1;


		}else if(dir1==2){
			corners1.x=X1;
			corners1.y=src->height-Y1;
			corners2.x=X1+mv_x1;
			corners2.y=src->height-(Y1+mv_y1);
//			cvLine (src, corners1, corners2, CV_RGB (0, 0, 255), 0.4, CV_AA, 0);
			cvCircle(dammy, corners1, 2, CV_RGB (5*qp1,0,0), 2, 7, 0);

			corners1.x=X2;
			corners1.y=src->height-Y2;
			corners2.x=X2+mv_x2;
			corners2.y=src->height-(Y2+mv_y2);
//			cvLine (src, corners1, corners2, CV_RGB (0, 0, 255), 0.4, CV_AA, 0);
			cvCircle(dammy, corners1, 2, CV_RGB (5*qp2,0,0), 2, 7, 0);

			qp_ave+=(qp1+qp2);
			qp_counts+=2;

			}

//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X1,&Y1,&mv_x1,&mv_y1,&dir1,&sad1,&qp1)){break;}
//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X2,&Y2,&mv_x2,&mv_y2,&dir2,&sad2,&qp2)){break;}
//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X1,&Y1,&mv_x1,&mv_y1,&dir1,&sad1,&qp1)){break;}
//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X2,&Y2,&mv_x2,&mv_y2,&dir2,&sad2,&qp2)){break;}
//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X1,&Y1,&mv_x1,&mv_y1,&dir1,&sad1,&qp1)){break;}
//		if(EOF==fscanf(fp,"%d %d %d %d %d %d %d\n",&X2,&Y2,&mv_x2,&mv_y2,&dir2,&sad2,&qp2)){break;}

		}


	qp_ave/=qp_counts;
	fprintf(fqp,"%lf\n",qp_ave);


	fclose(fp);

	cvNamedWindow ("Image", 1);  
//	cvShowImage ("Image", src); 
	cvShowImage ("Image", dammy); 

	cvWaitKey (10);



	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename2, -1 , 
      fps , cvSize(src->width,src->height) );
	}
	//AVI��������------------------------------------
//      cvWriteFrame(VideoWriter,src);
      cvWriteFrame(VideoWriter,dammy);
	// ----------------------------------------------

}

	fclose(fqp);

// �㏈��-----------------------------------
 cvReleaseVideoWriter(&VideoWriter); 
//------------------------------------------

	cvDestroyWindow ("Image");  

	return 0;
}