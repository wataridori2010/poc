////////////////////////////////////////////////////////////////
//
//	CTC ito NR�p�����[�^�������̃t�@�C�� 2010.06.18
// (�������E�������Ȃ�)
////////////////////////////////////////////////////////////////


#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

#include <time.h>
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define movie_out	//����o�̓t���O
#define bilatelal	//�o�C���e�����t�B���^�t���O
//#define epsilon	//�C�v�V�����t�B���^�t���O





int main(int argc, char** argv){	//filename, ���(�t���T�C�Y)��,  ���(1/4�T�C�Y)��,  ���(1/4�T�C�Y)臒l, �F��, �F臒l, ���t���[���̐F�Б����W��

	int i,j;
	IplImage* pColorPhotoI = 0; // �J���[�摜
	IplImage *dst=0;	// �������o�C���e�����t�B���^�p



	if(argc<9){
		return 0;
	}
	char* filename2=(char*)calloc(256,sizeof(char));
	strcpy(filename2,argv[1]);

	int pyr=atoi(argv[2]);	//��������K�w�̐�

	float sl1=atof(argv[3]);//���(�t���T�C�Y��)
	float sl2=atof(argv[4]);//���(1/4�T�C�Y��)
	float sl3=atof(argv[5]);//���臒l
	float sl4=atof(argv[6]);//�F((�t���T�C�Y�A1/4�T�C�Y��))
	float sl5=atof(argv[7]);//�F臒l
	float sl6=atof(argv[8]);//���t���[����(��ԁA�F)������



	int counts=0;
	int ex_count=0;

//�t�H���_���̒��o
	int name_count=0;
	char name_ad[512];
	char name_file[512];
	char *name_test;



	//�h���C�u����؂�o��&�R�s�[
	name_test=strtok(filename2, "\\");
	strcpy(name_ad,name_test);	strcat(name_ad,"\\");
	//�h���C�u���ȉ�
	while( (name_test=strtok(NULL, "\\")) !=NULL ){
		if(name_count>=1){strcat(name_ad,name_file);	strcat(name_ad,"\\");}//2���[�v�ڂ���؂�o������\\�������Ă���
		strcpy(name_file,name_test); //�؂�o�����̃R�s�[���ŏI�I�Ƀt�@�C�����ɂȂ�B
		name_count+=1;
	}



#ifdef movie_out
	//AVI�o��-------------------------------------------------
	//�o��AVI�t�@�C�����ݒ�
	char filename3[512];
	strcpy(filename3,name_ad);
//	strcat(filename3,"NR-");
//	strcat(filename3,name_file);
	strcat(filename3,name_file);

	//�p�����[�^�t�����ĕۑ�
	strcat(filename3,"_test_");
	strcat(filename3,"_");
	strcat(filename3,argv[2]);
	strcat(filename3,"_");
	strcat(filename3,argv[3]);
	strcat(filename3,"_");
	strcat(filename3,argv[4]);
	strcat(filename3,"_");
	strcat(filename3,argv[5]);
	strcat(filename3,"_");
	strcat(filename3,argv[6]);
	strcat(filename3,"_");
	strcat(filename3,argv[7]);
	strcat(filename3,"_");
	strcat(filename3,argv[8]);

	strcat(filename3,"_nr.avi");

	int l=0;
    CvVideoWriter* VideoWriter = NULL;
    double fps = 24.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------	
#endif


	CvCapture *capture = 0;
	capture = cvCaptureFromAVI(argv[1]);
	if(capture==NULL){return 0;}



	//�����̈�m��
	IplImage **p0,**p, **pp;
	p0 = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	p = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	pp = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);

	unsigned char **x_coef2,**x_coef3;
	unsigned char **d_coef1,**d_coef2;


	IplImage *re_img0;//,*re_img00; 
	IplImage *re_img;//,*re_img01,*re_img02;
	IplImage *re_img2;

	IplImage *noise_img2,*noise_img,*noise_img0;//�m�C�Y�摜



	IplImage *binary_image;

	//���J�[�V�u�p�̏d��
//	float rec_rate[2];
//	rec_rate[0]=0.3;
//	rec_rate[1]=1.0-rec_rate[0];
	unsigned char **rec_rate;

	unsigned char *gain_rate;
	unsigned char *gain_rate3;



for(counts=0;counts<1000;counts++){

	//�t���[���ǂݍ���
	if(NULL==(pColorPhotoI=cvQueryFrame(capture))){
	 break;
	}


	//��BGR2YCbCr��
	cvCvtColor(pColorPhotoI,pColorPhotoI,CV_BGR2YCrCb);




	float sigmax=sl1;//��ԁ@�t���T�C�Y
	float sigmax2=sl2;//��ԁ@1/4�T�C�Y
	int Xth=sl3;		//���臒l

//	float sigmad1=(sl4); //�P�x�p��//15
//	float sigmad2=(0.33*sl4);	//�F���p��//5
	float sigmad1=sl4; //�P�x�p��//15
	float sigmad2=sl4;	//�F���p��//5
	int Dth1=sl5;	//�P�x�p臒l//45
	int Dth2=sl5;	//�F���p臒l//15
	int Dth3=Dth2/2.0;

	float multi=sl6;	//���t���[�������W��



	unsigned char t1,t2,t3;
	unsigned char v1,v2,v3;
	int s,t;

	//uint,uchar
	unsigned int rgb[3];
	unsigned int dv3[3];
	unsigned int dv4[3];
	unsigned int dv4_out[3][3];

	unsigned int sum_p[3];
	unsigned int sum=0;
	unsigned char xv=0;
	unsigned char tr,tg,tb;

	int width1=pColorPhotoI->width/1.0;
	int width2=pColorPhotoI->width/2.0;
	int width4=pColorPhotoI->width/4.0;
	int height1=pColorPhotoI->height/1.0;
	int height2=pColorPhotoI->height/2.0;
	int height4=pColorPhotoI->height/4.0;

	int address0=0;
	int address1=0;
	int address2=0;
	int address3=0;


	float sg=0;


//�������t���[���ŉ摜�̈�&�p�����[�^����
	if(counts==0){


		binary_image=cvCloneImage(pColorPhotoI);


		re_img0 = cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);
		//�����摜����
		for(int num=0; num<2; num++){
		p0[num]		 = cvCloneImage(pColorPhotoI);//
		}

		re_img=cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img,CV_INTER_LINEAR);
		cvResize(pColorPhotoI,re_img,CV_INTER_NN);

		//�����摜����
		for(int num=0; num<2; num++){
		p[num]		 = cvCloneImage(re_img);//
		}

		re_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img2,CV_INTER_LINEAR);
		cvResize(re_img,re_img2,CV_INTER_NN);

		noise_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
		noise_img =cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
		noise_img0 =cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);

		//�����摜����
		for(int num=0; num<2; num++){
		pp[num]		 = cvCloneImage(re_img2);//
		}

		//�������ʉ摜
		dst		 = cvCloneImage(pColorPhotoI);//



		//���J�[�V�u�t�B���^�p
		rec_rate=(unsigned char**)calloc(2,sizeof(unsigned char*));
		*(rec_rate+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(rec_rate+1)=(unsigned char*)calloc(512,sizeof(unsigned char));
		for(int num=0;num<512;num++){
/*			if(	(num-255)>-(Dth1+Dth1/2.0)	&&	(num-255)<=-(Dth1/2.0)){
					rec_rate[0][num]=150;
					rec_rate[1][num]=50;
			}
			else if(	(num-255)>-(Dth1/2.0)	&&	(num-255)<(Dth1/2.0)){
					rec_rate[0][num]=100;
					rec_rate[1][num]=100;
			}
			else if(	(num-255)>=(Dth1/2.0)	&&	(num-255)<(Dth1+Dth1/2.0)){
					rec_rate[0][num]=150;
					rec_rate[1][num]=50;
			}
			else{
					rec_rate[0][num]=0;
					rec_rate[1][num]=0;
			}
*/
			if(	(num-255)>-(Dth1)	&&	(num-255)<(Dth1)){
					rec_rate[0][num]=100;
					rec_rate[1][num]=100;
			}
			else{
					rec_rate[0][num]=100;
					rec_rate[1][num]=100;
//					rec_rate[0][num]=0;
//					rec_rate[1][num]=0;
			}

/*			sg=Dth1/3.0;

			if(	(num-255)>-(Dth1)	&&	(num-255)<(Dth1)){
					rec_rate[0][num]=100*exp(-1*((num-255)*(num-255))/(2*sg*sg));
					rec_rate[1][num]=100*exp(-1*((num-255)*(num-255))/(2*sg*sg));
			}else{
					rec_rate[0][num]=0;
					rec_rate[1][num]=0;

			}
*/

		}




		//�t�B���^�W���̈�
		d_coef1=(unsigned char**)calloc(2,sizeof(unsigned char*));
		d_coef2=(unsigned char**)calloc(2,sizeof(unsigned char*));
		*(d_coef1+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+0)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef1+1)=(unsigned char*)calloc(512,sizeof(unsigned char));
		*(d_coef2+1)=(unsigned char*)calloc(512,sizeof(unsigned char));

		//�����t���[���p
		//�P�x�p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(Dth1)	&&	(num-255)<(Dth1)){

				#ifdef bilatelal
					d_coef2[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1*multi*multi));//bilatelal�p
				#endif
				#ifdef epsilon
					d_coef2[0][num]=fabs(double(num-255));//epsilon�p
				#endif

			}
			else{
				d_coef2[0][num]=0;
			}
		}
		//�F���p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(Dth2)	&&	(num-255)<(Dth2)){
				#ifdef bilatelal
					d_coef1[0][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2*multi*multi));
				#endif
				#ifdef epsilon
					d_coef1[0][num]=fabs(double(num-255));//epsilon�p
				#endif

			}else{
				d_coef1[0][num]=0;
			}
		}


		//���ߋ��t���[���p
		//�P�x�p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(Dth1)	&&	(num-255)<(Dth1)){
				#ifdef bilatelal
					d_coef2[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad1*sigmad1));
				#endif
				#ifdef epsilon
					d_coef2[1][num]=fabs(double(num-255));//epsilon�p
				#endif

			}else{
				d_coef2[1][num]=0;
			}
		}
		//�F���p
		for(int num=0;num<512;num++){
			if(	(num-255)>-(Dth2)	&&	(num-255)<(Dth2)){
				#ifdef bilatelal
					d_coef1[1][num]=255*exp(( (-1)*(255-num)*(255-num) )/(2*sigmad2*sigmad2));
				#endif
				#ifdef epsilon
					d_coef1[1][num]=fabs(double(num-255));//epsilon�p
				#endif

			}else{
				d_coef1[1][num]=0;
			}
		}

		//��ԕ����p
		x_coef2=(unsigned char**)calloc(2,sizeof(unsigned char*));
//		x_coef3=(unsigned char**)calloc(2,sizeof(unsigned char*));
		*(x_coef2+0)=(unsigned char*)calloc(121,sizeof(unsigned char));
		*(x_coef2+1)=(unsigned char*)calloc(121,sizeof(unsigned char));
//		*(x_coef3+1)=(unsigned char*)calloc(121,sizeof(unsigned char));
//		*(x_coef3+1)=(unsigned char*)calloc(121,sizeof(unsigned char));

		//1/4�T�C�Y
		for(s=0;s<11;s++){
			for(t=0;t<11;t++){
				if(	(s-5)>-(Xth)	&&	(s-5)<(Xth)	&&	(t-5)>-(Xth)	&&	(t-5)<(Xth)		){

					x_coef2[0][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax2*sigmax2*multi*multi));
				}else{
					x_coef2[0][s*11+t]=0;
				}
		}}
		for(s=0;s<11;s++){
			for(t=0;t<11;t++){
				if(	(s-5)>-(Xth)	&&	(s-5)<(Xth)	&&	(t-5)>-(Xth)	&&	(t-5)<(Xth)		){
					x_coef2[1][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax2*sigmax2*multi*multi));
				}else{

					x_coef2[1][s*11+t]=0;
				}
		}}


		//�t���T�C�Y
/*		for(s=0;s<11;s++){
			for(t=0;t<11;t++){
				if(	(s-5)>-(Xth)	&&	(s-5)<(Xth)	&&	(t-5)>-(Xth)	&&	(t-5)<(Xth)		){
					x_coef3[0][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax*sigmax));

				}else{
					x_coef3[0][s*11+t]=0;
				}
		}}
		for(s=0;s<11;s++){
			for(t=0;t<11;t++){
				if(	(s-5)>-(Xth)	&&	(s-5)<(Xth)	&&	(t-5)>-(Xth)	&&	(t-5)<(Xth)		){
					x_coef3[1][s*11+t]=255*exp(( (-1)*((5-s)*(5-s)+(5-t)*(5-t)) )/(2*sigmax*sigmax));
				}else{
					x_coef3[1][s*11+t]=0;
				}
		}}
*/



		gain_rate=(unsigned char*)calloc(256,sizeof(unsigned char));

		for(int num=0;num<256;num++){
			if(num<Dth2){
					gain_rate[num]=Dth2-num;
			}else{
					gain_rate[num]=0;
			}

/*			if(num<Dth2){
					gain_rate[num]=(Dth2/2);
			}else{
					gain_rate[num]=0;
			}
*/		}

		gain_rate3=(unsigned char*)calloc(256,sizeof(unsigned char));
		for(int num=0;num<256;num++){
			if(num<Dth3){
					gain_rate3[num]=Dth3-num;
			}else{
					gain_rate3[num]=0;
			}
		}



/*		sg=Dth2/3.0;
		for(int num=0;num<256;num++){
			if(num<8){
					gain_rate[num]=100*exp((-1*num*num)/(2*sg*sg));
			}else{
					gain_rate[num]=0;

			}
		}
*/

	}



	float ggr=255.0/float(Dth3);
	int ttt1,ttt2,ttt3;




//******************************************************************************************************
//******************************************************************************************************
	//�摜�̃R�s�[(���摜�T�C�Y����)
	cvCopy(pColorPhotoI, p0[0]);

	//�摜�̃R�s�[(1/2�摜�T�C�Y����)
	cvResize(pColorPhotoI,p[0],CV_INTER_LINEAR);
	cvCopy(p[0],re_img);




	cvCopy(pColorPhotoI,binary_image);


//��1226�ǉ�
	cvCopy(pColorPhotoI,dst);

	clock_t time3 = clock();




//*************************************************************************************************************************//
//1/4�摜���璆���g�m�C�Y����
address0=0;
address1=0;


//��MaxMin
int min_value=255;
int max_value=0;
int mm_plane[2];


//�������ϒl�Z�o
unsigned int patch_v[3];
unsigned int patch_ave1[3];
unsigned int patch_ave2[3];
unsigned int ave_plane[2][3];


for(i=0;i<height2;i++){

	address0=i*p[0]->widthStep;

	for(j=0;j<width2;j++){

			address1=address0 + 3*j;

			t1=(uchar)p[0]->imageData[address1 +0];
			t2=(uchar)p[0]->imageData[address1 +1];
			t3=(uchar)p[0]->imageData[address1 +2];

			//�m�C�Y�ώZ�摜�̏�����
			noise_img->imageData[address1 +0]=0;
			noise_img->imageData[address1 +1]=0;
			noise_img->imageData[address1 +2]=0;


			tb=t1;tg=t2;tr=t3;

			//������
			sum=0;
//			rgb[0]=0;sum_p[0]=0;			
//			rgb[1]=0;sum_p[1]=0;
//			rgb[2]=0;sum_p[2]=0;





			for(int num=0;num<2;num++){

				//��MaxMin
				min_value=255;
				max_value=0;

				//�������ϒl�Z�o
				patch_ave1[0]=0;
				patch_ave1[1]=0;
				patch_ave1[2]=0;
				patch_ave2[0]=0;
				patch_ave2[1]=0;
				patch_ave2[2]=0;


				rgb[0]=0;sum_p[0]=0;			
				rgb[1]=0;sum_p[1]=0;
				rgb[2]=0;sum_p[2]=0;


//				address2=address1;//(5,5)�̃t�B���^�̏ꍇ
//				for(s=0;s<1;s++){
				address2=address1-3*p[0]->widthStep;//(5,5)�̃t�B���^�̏ꍇ
				for(s=-3;s<4;s++){

//				address3=address2;
//				for(t=0;t<1;t++){
				address3=address2-9;
				for(t=-3;t<4;t++){
						
						if( (address3>=0)&&(address3<=p[num]->widthStep*p[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
						xv=x_coef2[num][(s+5)*11+(t+5)];


						v1=(uchar)p[num]->imageData[address3 +0];
						v2=(uchar)p[num]->imageData[address3 +1];
						v3=(uchar)p[num]->imageData[address3 +2];


						//��MaxMin
						if(v1>max_value){max_value=v1;}
						if(v1<min_value){min_value=v1;}


						//�F�������ɂ��d�ݕt��
						dv4[0]=xv*d_coef2[num][255+(v1-(uchar)p[num]->imageData[address1 +0])];
						dv4[1]=xv*d_coef1[num][255+(v2-(uchar)p[num]->imageData[address1 +1])];
						dv4[2]=xv*d_coef1[num][255+(v3-(uchar)p[num]->imageData[address1 +2])];

						dv3[0]=xv*rec_rate[num][255+(v1-t1)];
						dv3[1]=xv*rec_rate[num][255+(v2-t2)];
						dv3[2]=xv*rec_rate[num][255+(v3-t3)];

						//�������ϒl�Z�o
						patch_v[0]=rec_rate[num][255+(v1-(uchar)p[num]->imageData[address1 +0])];
						patch_v[1]=rec_rate[num][255+(v2-(uchar)p[num]->imageData[address1 +1])];
						patch_v[2]=rec_rate[num][255+(v3-(uchar)p[num]->imageData[address1 +2])];

						patch_ave1[0]+=patch_v[0]*v1;
						patch_ave1[1]+=patch_v[1]*v2;
						patch_ave1[2]+=patch_v[2]*v3;

						patch_ave2[0]+=patch_v[0];
						patch_ave2[1]+=patch_v[1];
						patch_ave2[2]+=patch_v[2];


#ifdef bilatelal
						rgb[0]+=dv4[0]*v1; 
						rgb[1]+=dv4[1]*v2; 
						rgb[2]+=dv4[2]*v3;

						sum_p[0]+=dv4[0];
						sum_p[1]+=dv4[1];
						sum_p[2]+=dv4[2];
#endif
#ifdef epsilon
						rgb[0]+=dv3[0]; 
						rgb[1]+=dv3[1]; 
						rgb[2]+=dv3[2];

						sum_p[0]+=xv;
						sum_p[1]+=xv;
						sum_p[2]+=xv;
#endif

						}
						address3+=3;

					}//t
					address2+=p[0]->widthStep;

				}//s

				//��MaxMin
//				mm_plane[num]=max_value-min_value;
				//�������ϒl�Z�o
				dv3[0]=patch_ave2[0]>>2; ave_plane[num][0]=(patch_ave1[0] +dv3[0])/patch_ave2[0];
				dv3[1]=patch_ave2[1]>>2; ave_plane[num][1]=(patch_ave1[1] +dv3[1])/patch_ave2[1];
				dv3[2]=patch_ave2[2]>>2; ave_plane[num][2]=(patch_ave1[2] +dv3[2])/patch_ave2[2];

				//�����o�C���e�������ϒl�Z�o
				dv4[0]=sum_p[0]>>2; dv4_out[num][0]=(rgb[0] +dv4[0])/sum_p[0];
				dv4[1]=sum_p[1]>>2; dv4_out[num][1]=(rgb[1] +dv4[1])/sum_p[1];
				dv4[2]=sum_p[2]>>2; dv4_out[num][2]=(rgb[2] +dv4[2])/sum_p[2];

			}


#ifdef bilatelal

			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=(rgb[2] +dv3[2])/sum_p[2];}



			int thv1=ave_plane[0][0]-ave_plane[1][0];
			int thv2=ave_plane[0][1]-ave_plane[1][1];
			int thv3=ave_plane[0][2]-ave_plane[1][2];
//			int thv1=dv4_out[0][0]-dv4_out[1][0];
//			int thv2=dv4_out[0][1]-dv4_out[1][1];
//			int thv3=dv4_out[0][2]-dv4_out[1][2];


			if(thv1<0){thv1*=-1;}
			if(thv2<0){thv2*=-1;}
			if(thv3<0){thv3*=-1;}


//			tb=((2*Dth2-gain_rate[int(thv1)])*t1+gain_rate[int(thv1)]*(uchar)p[1]->imageData[address1 +0]+Dth2)/(Dth2*2);	
//			tg=((2*Dth2-gain_rate[int(thv2)])*t2+gain_rate[int(thv2)]*(uchar)p[1]->imageData[address1 +1]+Dth2)/(Dth2*2);
//			tr=((2*Dth2-gain_rate[int(thv3)])*t3+gain_rate[int(thv3)]*(uchar)p[1]->imageData[address1 +2]+Dth2)/(Dth2*2);
//			tb=((2*Dth2-gain_rate[int((2*thv1+thv2+thv3)/4.0)])*t1+gain_rate[int((2*thv1+thv2+thv3)/4.0)]*(uchar)p[1]->imageData[address1 +0]+Dth2)/(Dth2*2);	
//			tg=((2*Dth2-gain_rate[int((2*thv1+thv2+thv3)/4.0)])*t2+gain_rate[int((2*thv1+thv2+thv3)/4.0)]*(uchar)p[1]->imageData[address1 +1]+Dth2)/(Dth2*2);
//			tr=((2*Dth2-gain_rate[int((2*thv1+thv2+thv3)/4.0)])*t3+gain_rate[int((2*thv1+thv2+thv3)/4.0)]*(uchar)p[1]->imageData[address1 +2]+Dth2)/(Dth2*2);


			tb=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t1+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +0]+Dth2)/(Dth2*2);	
			tg=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t2+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +1]+Dth2)/(Dth2*2);
			tr=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t3+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +2]+Dth2)/(Dth2*2);
//			tb=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][0]+gain_rate[int((thv1+thv2+thv3)/3.0)]*ave_plane[1][0])/(Dth2*2);	
//			tg=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][1]+gain_rate[int((thv1+thv2+thv3)/3.0)]*ave_plane[1][1])/(Dth2*2);
//			tr=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][2]+gain_rate[int((thv1+thv2+thv3)/3.0)]*ave_plane[1][2])/(Dth2*2);
//			tb=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][0]+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +0])/(Dth2*2);	
//			tg=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][1]+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +1])/(Dth2*2);
//			tr=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*ave_plane[0][2]+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p[1]->imageData[address1 +2])/(Dth2*2);
//			tb=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*dv4_out[0][0]+gain_rate[int((thv1+thv2+thv3)/3.0)]*dv4_out[1][0]+Dth2)/(Dth2*2);	
//			tg=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*dv4_out[0][1]+gain_rate[int((thv1+thv2+thv3)/3.0)]*dv4_out[1][1]+Dth2)/(Dth2*2);
//			tr=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*dv4_out[0][2]+gain_rate[int((thv1+thv2+thv3)/3.0)]*dv4_out[1][2]+Dth2)/(Dth2*2);


/*
//			if( thv1>Dth1 || thv2>Dth1 || thv3>Dth1  ){
			if( thv1>Dth1 || (thv2+thv3)>Dth1*2  ){

			//�������ϒl�Z�o
//			if( fabs(double(ave_plane[0][0]-ave_plane[1][0]))>Dth1 ||
//				(fabs(double(ave_plane[0][1]-ave_plane[1][1]))	+
//				fabs(double(ave_plane[0][2]-ave_plane[1][2]))	)>Dth1*2
//				){
				tb=t1;
				tg=t2;
				tr=t3;
//				tb=ave_plane[0][0];
//				tg=ave_plane[0][1];
//				tr=ave_plane[0][2];

			}else{
//				tb=(100*t1+100*(uchar)p[1]->imageData[address1 +0])/200.0;
//				tg=(100*t2+100*(uchar)p[1]->imageData[address1 +1])/200.0;
//				tr=(100*t3+100*(uchar)p[1]->imageData[address1 +2])/200.0;
//				tb=(60*ave_plane[0][0]+140*(uchar)p[1]->imageData[address1 +0])/200.0;
//				tg=(60*ave_plane[0][1]+140*(uchar)p[1]->imageData[address1 +1])/200.0;
//				tr=(60*ave_plane[0][2]+140*(uchar)p[1]->imageData[address1 +2])/200.0;
				tb=(60*t1+140*(uchar)p[1]->imageData[address1 +0])/200.0;
				tg=(60*t2+140*(uchar)p[1]->imageData[address1 +1])/200.0;
				tr=(60*t3+140*(uchar)p[1]->imageData[address1 +2])/200.0;
			}
*/

#endif

#ifdef epsilon
			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=t1-(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=t2-(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=t3-(rgb[2] +dv3[2])/sum_p[2];}

#endif

			//2�Ԃ��1NR�摜
			re_img->imageData[address1 +0]=tb;
			re_img->imageData[address1 +1]=tg;
			re_img->imageData[address1 +2]=tr;

#ifdef bilatelal
			noise_img->imageData[address1 +0]=(128+tb-t1);
			noise_img->imageData[address1 +1]=(128+tg-t2);
			noise_img->imageData[address1 +2]=(128+tr-t3);
#endif
#ifdef epsilon
			noise_img->imageData[address1 +0]=(128-tb+t1);
			noise_img->imageData[address1 +1]=(128-tg+t2);
			noise_img->imageData[address1 +2]=(128-tr+t3);
#endif


	}}

	//��1027
	cvCopy(re_img, p[1]);
//	cvCopy(p[0], p[1]);


	//��1027
	cvResize(noise_img,noise_img0,CV_INTER_LINEAR);


	clock_t time5 = clock();
	double total_time4 = (double)(time5-time3)/CLOCKS_PER_SEC;
	printf("2�K�w: %g sec.\n", total_time4);


//*************************************************************************************************************************//
//�t���T�C�YNR����

	address1=0;
	address0=0;

	//�t���X�P�[���摜���璆���g�m�C�Y����
	for(i=0;i<height1;i++){

		address1=address0;

		for(j=0;j<width1;j++){

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p0[0]->imageData[address1 +0]+(uchar)noise_img0->imageData[address1 +0]-128;
			ttt2=(uchar)p0[0]->imageData[address1 +1]+(uchar)noise_img0->imageData[address1 +1]-128;
			ttt3=(uchar)p0[0]->imageData[address1 +2]+(uchar)noise_img0->imageData[address1 +2]-128;

			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p0[0]->imageData[address1 +0]=(uchar)t1;
			p0[0]->imageData[address1 +1]=(uchar)t2;
			p0[0]->imageData[address1 +2]=(uchar)t3;



		address1+=3;
		}
	address0+=p0[0]->widthStep;
	}


	//�����������t���O
	if(pyr == 2){

	//�t���X�P�[���摜���獂���g�m�C�Y����
	address1=0;
	address0=0;
	for(i=0;i<height1;i++){

		address0=i*p0[0]->widthStep;

		for(j=0;j<width1;j++){


			address1=address0 + 3*j;

			t1=(uchar)p0[0]->imageData[address1 +0];
			t2=(uchar)p0[0]->imageData[address1 +1];
			t3=(uchar)p0[0]->imageData[address1 +2];

			tb=t1;tg=t2;tr=t3;


			//������
			sum=0;
			rgb[0]=0;sum_p[0]=0;			
			rgb[1]=0;sum_p[1]=0;
			rgb[2]=0;sum_p[2]=0;

			for(int num=0;num<2;num++){

				//�������ϒl�Z�o
				patch_ave1[0]=0;
				patch_ave1[1]=0;
				patch_ave1[2]=0;
				patch_ave2[0]=0;
				patch_ave2[1]=0;
				patch_ave2[2]=0;

//				address2=address1-p0[0]->widthStep;
//				for(s=-1;s<2;s++){
//				address2=address1-5*p0[0]->widthStep;
//				for(s=-5;s<6;s++){
				address2=address1;//(1,1)�̃t�B���^
				for(s=0;s<1;s++){


//					address3=address2-3;//(1,1)�̃t�B���^
//					for(t=-1;t<2;t++){
//					address3=address2-15;//(1,1)�̃t�B���^
//					for(t=-5;t<6;t++){
					address3=address2;//(1,1)�̃t�B���^
					for(t=0;t<1;t++){


						if( (address3>=0)&&(address3<=p0[num]->widthStep*p0[num]->height) ){

						//��ԋ����ɂ��d�݂Â�
//						xv=x_coef3[num][(s+5)*11+(t+5)];
						xv=1;


						v1=(uchar)p0[num]->imageData[address3 +0];
						v2=(uchar)p0[num]->imageData[address3 +1];
						v3=(uchar)p0[num]->imageData[address3 +2];

						//�F�������ɂ��d�ݕt��
//						dv3[0]=xv*d_coef2[num][255+(v1-t1)];
//						dv3[1]=xv*d_coef1[num][255+(v2-t2)];
//						dv3[2]=xv*d_coef1[num][255+(v3-t3)];
						dv3[0]=xv*rec_rate[num][255+(v1-t1)];
						dv3[1]=xv*rec_rate[num][255+(v2-t2)];
						dv3[2]=xv*rec_rate[num][255+(v3-t3)];

						//�������ϒl�Z�o
						patch_v[0]=rec_rate[num][255+(v1-(uchar)p0[num]->imageData[address1 +0])];
						patch_v[1]=rec_rate[num][255+(v2-(uchar)p0[num]->imageData[address1 +1])];
						patch_v[2]=rec_rate[num][255+(v3-(uchar)p0[num]->imageData[address1 +2])];

						patch_ave1[0]+=patch_v[0]*v1;
						patch_ave1[1]+=patch_v[1]*v2;
						patch_ave1[2]+=patch_v[2]*v3;

						patch_ave2[0]+=patch_v[0];
						patch_ave2[1]+=patch_v[1];
						patch_ave2[2]+=patch_v[2];



						rgb[0]+=dv3[0]*v1;
						rgb[1]+=dv3[1]*v2; 
						rgb[2]+=dv3[2]*v3;

						sum_p[0]+=dv3[0];
						sum_p[1]+=dv3[1];
						sum_p[2]+=dv3[2];



						}
						address3+=3;

					}//t
					address2+=p0[0]->widthStep;

				}//s

				//�������ϒl�Z�o
				dv3[0]=patch_ave2[0]>>2; ave_plane[num][0]=(patch_ave1[0] +dv3[0])/patch_ave2[0];
				dv3[1]=patch_ave2[1]>>2; ave_plane[num][1]=(patch_ave1[1] +dv3[1])/patch_ave2[1];
				dv3[2]=patch_ave2[2]>>2; ave_plane[num][2]=(patch_ave1[2] +dv3[2])/patch_ave2[2];


			}



			//Y
			if(sum_p[0]>0){ dv3[0]=sum_p[0]>>2; tb=(rgb[0] +dv3[0])/sum_p[0];}
			//Cr
			if(sum_p[1]>0){ dv3[1]=sum_p[1]>>2; tg=(rgb[1] +dv3[1])/sum_p[1];}
			//Cb
			if(sum_p[2]>0){ dv3[2]=sum_p[2]>>2; tr=(rgb[2] +dv3[2])/sum_p[2];}


			int thv1=ave_plane[0][0]-ave_plane[1][0];
			int thv2=ave_plane[0][1]-ave_plane[1][1];
			int thv3=ave_plane[0][2]-ave_plane[1][2];

			if(thv1<0){thv1*=-1;}
			if(thv2<0){thv2*=-1;}
			if(thv3<0){thv3*=-1;}

/*			if( thv1>Dth1 || (thv2+thv3)>Dth1*2  ){

//					tb=t1;
//					tg=t2;
//					tr=t3;
					tb=ave_plane[0][0];
					tg=ave_plane[0][1];
					tr=ave_plane[0][2];
			}else{
				tb=(60*t1+140*(uchar)p0[1]->imageData[address1 +0])/200.0;
				tg=(60*t2+140*(uchar)p0[1]->imageData[address1 +1])/200.0;
				tr=(60*t3+140*(uchar)p0[1]->imageData[address1 +2])/200.0;
//				tb=(60*ave_plane[0][0]+140*(uchar)p0[1]->imageData[address1 +0])/200.0;
//				tg=(60*ave_plane[0][1]+140*(uchar)p0[1]->imageData[address1 +1])/200.0;
//				tr=(60*ave_plane[0][2]+140*(uchar)p0[1]->imageData[address1 +2])/200.0;
			}

*/
/*
			if( thv1>Dth1 || (thv2+thv3)>Dth1*2  ){

//					tb=t1;
//					tg=t2;
//					tr=t3;
					tb=ave_plane[0][0];
					tg=ave_plane[0][1];
					tr=ave_plane[0][2];
			}else{
*/	


				tb=((2*Dth3-gain_rate3[int((thv1+thv2+thv3)/3.0)])*t1+gain_rate3[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +0]+Dth3)/(Dth3*2);
				tg=((2*Dth3-gain_rate3[int((thv1+thv2+thv3)/3.0)])*t2+gain_rate3[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +1]+Dth3)/(Dth3*2);
				tr=((2*Dth3-gain_rate3[int((thv1+thv2+thv3)/3.0)])*t3+gain_rate3[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +2]+Dth3)/(Dth3*2);
//				tb=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t1+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +0])/(Dth2*2);
//				tg=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t2+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +1])/(Dth2*2);
//				tr=((2*Dth2-gain_rate[int((thv1+thv2+thv3)/3.0)])*t3+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +2])/(Dth2*2);


				binary_image->imageData[address1 +0]=(uchar)(gain_rate3[int((thv1+thv2+thv3)/3.0)]*ggr);
				binary_image->imageData[address1 +1]=(uchar)128;
				binary_image->imageData[address1 +2]=(uchar)128;


//				tb=((100-gain_rate[int((thv1+thv2+thv3)/3.0)])*t1+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +0])/(100);
//				tg=((100-gain_rate[int((thv1+thv2+thv3)/3.0)])*t2+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +1])/(100);
//				tr=((100-gain_rate[int((thv1+thv2+thv3)/3.0)])*t3+gain_rate[int((thv1+thv2+thv3)/3.0)]*(uchar)p0[1]->imageData[address1 +2])/(100);


//				tb=(60*ave_plane[0][0]+140*(uchar)p0[1]->imageData[address1 +0])/200.0;
//				tg=(60*ave_plane[0][1]+140*(uchar)p0[1]->imageData[address1 +1])/200.0;
//				tr=(60*ave_plane[0][2]+140*(uchar)p0[1]->imageData[address1 +2])/200.0;
//			}



/*			if( thv1>Dth1){
				tb=ave_plane[0][0];
			}else{
				tb=(60*t1+140*(uchar)p0[1]->imageData[address1 +0])/200.0;
			}
			if( thv2>Dth1){
				tg=ave_plane[0][1];
			}else{
				tg=(60*t2+140*(uchar)p0[1]->imageData[address1 +1])/200.0;
			}
			if( thv3>Dth1){
				tr=ave_plane[0][2];
			}else{
				tr=(60*t3+140*(uchar)p0[1]->imageData[address1 +2])/200.0;
			}

*/

			//�������ϒl�Z�o
//			if( fabs(double((uchar)p0[0]->imageData[address1 +0]-(uchar)p0[1]->imageData[address1 +0]))>Dth1 ||
//				(fabs(double((uchar)p0[0]->imageData[address1 +1]-(uchar)p0[1]->imageData[address1 +1]))	+
//				 fabs(double((uchar)p0[0]->imageData[address1 +2]-(uchar)p0[1]->imageData[address1 +2]))	)>Dth1*2
//				){
/*			if( thv1>Dth1 || (thv2+thv3)>Dth1*2  ){
						tb=t1;
						tg=t2;
						tr=t3;
						binary_image->imageData[address1 +0]=(uchar)255;
						binary_image->imageData[address1 +1]=(uchar)128;
						binary_image->imageData[address1 +2]=(uchar)128;

			}else{
				tb=(60*t1+140*(uchar)p0[1]->imageData[address1 +0])/200.0;
				tg=(60*t2+140*(uchar)p0[1]->imageData[address1 +1])/200.0;
				tr=(60*t3+140*(uchar)p0[1]->imageData[address1 +2])/200.0;

			}
*/


			dst->imageData[address1 +0]=tb;
			dst->imageData[address1 +1]=tg;
			dst->imageData[address1 +2]=tr;




	}}

	cvCopy(dst,p0[0]);

	}//������

	clock_t time6 = clock();
	double total_time5 = (double)(time6-time5)/CLOCKS_PER_SEC;
	printf("3�K�w: %g sec.\n", total_time5);


	cvCopy(p0[0], p0[1]);


//******************************************************************************************************
//******************************************************************************************************


#ifdef movie_out

	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename3, CV_FOURCC('D','I','B',' '), 
		fps , cvSize(dst->width,dst->height) );
		}
	//----------------------------------------------
#endif


	//��YCbCr��BGR
	cvCvtColor(p0[0],p0[0],CV_YCrCb2BGR);

	cvCvtColor(binary_image,binary_image,CV_YCrCb2BGR);


#ifdef movie_out
	//AVI��������------------------------------------
	cvWriteFrame(VideoWriter,p0[0]);	//�����t���[���o�C���e����
//	cvWriteFrame(VideoWriter,binary_image);	//�����t���[���o�C���e����
	// ----------------------------------------------
#endif


	printf("frame: %d\n", counts);
	cvWaitKey(10);

}









#ifdef movie_out
	// �㏈��-----------------------------------
	cvReleaseVideoWriter(&VideoWriter);		
	//-----------------------------------------
#endif

	//���

	cvReleaseImage(p0);
	cvReleaseImage(p);
	cvReleaseImage(pp);
	cvReleaseImage(&re_img0);
	cvReleaseImage(&re_img);
	cvReleaseImage(&re_img2);
	cvReleaseImage(&noise_img0);
	cvReleaseImage(&noise_img);
	cvReleaseImage(&noise_img2);
	cvReleaseImage(&dst);

	free(d_coef1);
	free(d_coef2);
	free(x_coef2);
//	free(x_coef3);

	return 1;


}


