
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <tchar.h>
#include <ctype.h>
#include <vector>
#include <iostream>
#include <shlwapi.h>
#include <direct.h>
#include <math.h>
#include "common.h"

#include "harris.h"
#include "susan.h"
#include "fast.h"
#include "klt/klt.h"



void DesColorPatch(IplImage *src_gray){

		//�L�q�q���o
		feature_extractor(src, keypoints1, size1, descriptor1);
}


void DesSURF(IplImage *src_gray){

		//�f�B�X�N���v�^���o��
		cv::Mat descriptors1_, descriptors2_;
//		cv::OrbDescriptorExtractor extractor;
		cv::SurfDescriptorExtractor extractor;
//		cv::SiftDescriptorExtractor extractor;

		cout << "descripting..." <<endl;

//		cv::Scalar color(100,255,50);
		extractor.compute(gray_img1, keypoints1_, descriptors1_);	
		extractor.compute(gray_img2, keypoints2_, descriptors2_);
}


void DesSIFT(IplImage *src_gray){

		//�f�B�X�N���v�^���o��
		cv::Mat descriptors1_, descriptors2_;
//		cv::OrbDescriptorExtractor extractor;
//		cv::SurfDescriptorExtractor extractor;
		cv::SiftDescriptorExtractor extractor;

		cout << "descripting..." <<endl;

//		cv::Scalar color(100,255,50);
		extractor.compute(gray_img1, keypoints1_, descriptors1_);	
		extractor.compute(gray_img2, keypoints2_, descriptors2_);

}


void DesKLT(IplImage *src_gray){
}


