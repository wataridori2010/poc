////////////////////////////////////////////////////////////////
//
//	CTC ito NR�p�����[�^�������̃t�@�C�� 2010.07.05
// (�������E�������Ȃ�)
////////////////////////////////////////////////////////////////


#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

#include <time.h>
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define movie_out	//����o�̓t���O






int main(int argc, char** argv){	//filename, ���(1/4�T�C�Y)��,  1/4�T�C�Y�t�B���^���a,  �F��臒l

	int i,j;
	IplImage* pColorPhotoI = 0; // �J���[�摜
	IplImage *dst=0;	// �������o�C���e�����t�B���^�p



	if(argc<5){
		return 0;
	}
	char* filename2=(char*)calloc(256,sizeof(char));
	strcpy(filename2,argv[1]);



	float sl1=atof(argv[2]);//���(1/4�T�C�Y�̃�)
	float sl3=atof(argv[3]);//�t�B���^���a
	float sl4=atof(argv[4]);//�F�̎c��臒l



	int counts=0;
	int ex_count=0;

//�t�H���_���̒��o
	int name_count=0;
	char name_ad[512];
	char name_file[512];
	char *name_test;



	//�h���C�u����؂�o��&�R�s�[
	name_test=strtok(filename2, "\\");
	strcpy(name_ad,name_test);	strcat(name_ad,"\\");
	//�h���C�u���ȉ�
	while( (name_test=strtok(NULL, "\\")) !=NULL ){
		if(name_count>=1){strcat(name_ad,name_file);	strcat(name_ad,"\\");}//2���[�v�ڂ���؂�o������\\�������Ă���
		strcpy(name_file,name_test); //�؂�o�����̃R�s�[���ŏI�I�Ƀt�@�C�����ɂȂ�B
		name_count+=1;
	}



#ifdef movie_out
	//AVI�o��-------------------------------------------------
	//�o��AVI�t�@�C�����ݒ�
	char filename3[512];
	strcpy(filename3,name_ad);
	strcat(filename3,name_file);

	//�p�����[�^�t�����ĕۑ�
	strcat(filename3,"_test_");
	strcat(filename3,"_");
	strcat(filename3,argv[2]);
	strcat(filename3,"_");
	strcat(filename3,argv[3]);
	strcat(filename3,"_");
	strcat(filename3,argv[4]);

	strcat(filename3,"_nr.avi");

	int l=0;
    CvVideoWriter* VideoWriter = NULL;
    double fps = 20.0;               // �r�f�I�̃t���[�����[�g
	//--------------------------------------------------------	
#endif


	CvCapture *capture = 0;
	capture = cvCaptureFromAVI(argv[1]);
	if(capture==NULL){return 0;}


	//�����̈�m��
	IplImage **p0,**p, **pp;
	p0 = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	p = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);
	pp = (IplImage **) cvAlloc (sizeof (IplImage *) * 2);


	IplImage *re_img0;//,*re_img00; 
	IplImage *re_img;//,*re_img01,*re_img02;
	IplImage *re_img2;

	IplImage *noise_img2,*noise_img,*noise_img0;//�m�C�Y�摜
	IplImage *binary_image;


	unsigned char **x_coef;
	unsigned char **rec_rate;
	unsigned char *gain_rate;

	float *mg;
	float *mg2;


for(counts=0;counts<500;counts++){

	//�t���[���ǂݍ���
	if(NULL==(pColorPhotoI=cvQueryFrame(capture))){
	 break;
	}


	//��BGR2YCbCr��
	cvCvtColor(pColorPhotoI,pColorPhotoI,CV_BGR2YCrCb);




	//�p�����[�^�֘A
	float sigmax=sl1;//��ԁ@1/4�T�C�Y��
	int Xth=sl3;	//�t�B���^���a
	int Dth1=sl4;	//臒l


	unsigned char t1,t2,t3;
	unsigned char v1,v2,v3;
	int s,t;

	//uint,uchar
	unsigned int dv3[3];
	unsigned int sum=0;
	unsigned char xv=0;
	short tr,tg,tb;

	int width1=pColorPhotoI->width/1.0;
	int width2=pColorPhotoI->width/2.0;

	int height1=pColorPhotoI->height/1.0;
	int height2=pColorPhotoI->height/2.0;


	int address0=0;
	int address1=0;
	int address2=0;
	int address3=0;


	float sg=0;

	int thv1,thv2,thv3;
	int zansa;
	int ttt1,ttt2,ttt3;

	char *char_p1;



//�������t���[���ŉ摜�̈�&�p�����[�^����
	if(counts==0){


		binary_image=cvCloneImage(pColorPhotoI);


		re_img0 = cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);
		//�����摜����
		for(int num=0; num<2; num++){
		p0[num]		 = cvCloneImage(pColorPhotoI);//
		}

		re_img=cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img,CV_INTER_LINEAR);
		cvResize(pColorPhotoI,re_img,CV_INTER_NN);

		//�����摜����
		for(int num=0; num<2; num++){
		p[num]		 = cvCloneImage(re_img);//
		}

		re_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
//		cvResize(pColorPhotoI,re_img2,CV_INTER_LINEAR);
		cvResize(re_img,re_img2,CV_INTER_NN);

		noise_img2=cvCreateImage(cvSize(int(pColorPhotoI->width/4),int(pColorPhotoI->height/4)), IPL_DEPTH_8U, 3);
		noise_img =cvCreateImage(cvSize(int(pColorPhotoI->width/2),int(pColorPhotoI->height/2)), IPL_DEPTH_8U, 3);
		noise_img0 =cvCreateImage(cvSize(int(pColorPhotoI->width),int(pColorPhotoI->height)), IPL_DEPTH_8U, 3);

		//�����摜����
		for(int num=0; num<2; num++){
		pp[num]		 = cvCloneImage(re_img2);//
		}

		//�������ʉ摜
		dst		 = cvCloneImage(pColorPhotoI);//





		//���J�[�V�u�t�B���^�p
		gain_rate=(unsigned char*)calloc(256,sizeof(unsigned char));
		for(int num=0;num<256;num++){

			if(num<=Dth1){
					gain_rate[num]=(Dth1-num);
			}else{
					gain_rate[num]=0;
			}

/*			float f1=1.0*float(Dth1-num)/2.0;
			float f2=1.0*float(2*Dth1-num)/4.0;
			if(f1<0){f1=0;}

			if(num<2*Dth1){
					gain_rate[num]=f1+f2;
			}else{
					gain_rate[num]=0;
			}
*/
			
		}


		//��f�l�ɉ������d�ݕt���p//�Ƃ肠����20
		mg = (float*)calloc(256,sizeof(float));
/*		for(int num=0;num<256;num++){
			
			if(num<15){
				mg[num]=1.0;
			}else if(num<30){
//					mg[num]=1.0-(30.0-num)/(1.0*30.0);
					mg[num]=1.0-(30.0-num)/(1.0*15.0);

//					mg[num]=0.5;
//					mg[num]=0.1;
//					mg[num]=((num-30.0/2.0)*(num-30.0/2.0)+30)/(15*15+30);
//					mg[num]=((num-30.0/2.0)*(num-30.0/2.0)+15*15)/(15*15+15*15);
*/
		for(int num=0;num<256;num++){
/*			if(num<=0.5*Dth1){
					mg[num]=0.1;
			}else if(num<=Dth1){
					mg[num]=(1.0-float(Dth1-num)/(0.5*Dth1));
*/
		if(num<=Dth1){
					mg[num]=(1.0-float(Dth1-num)/(Dth1));
//					mg[num]=0.2;


/*		if(num<=Dth1*0.5){
					mg[num]=(1.0-float(num)/(0.5*Dth1));

		}else if(num<=Dth1){
					mg[num]=(1.0-float(Dth1-num)/(0.5*Dth1));

*/		}else{
					mg[num]=1.0;
			}
		}



		mg2 = (float*)calloc(256,sizeof(float));
		for(int num=0;num<256;num++){

//			mg2[num]=float(1.0*num+128.0)/128.0;
//			mg2[num]=float(0.5*num+160.0)/128.0;
			mg2[num]=float(0.5*num+256.0)/128.0;

//			mg2[num]=2;
		}

	}



//******************************************************************************************************
//******************************************************************************************************
	//�摜�̃R�s�[(���摜�T�C�Y����)
	cvCopy(pColorPhotoI, p0[0]);

	//�摜�̃R�s�[(1/4�摜�T�C�Y����)
	cvResize(pColorPhotoI,p[0],CV_INTER_LINEAR);
//	cvResize(pColorPhotoI,p[0],CV_INTER_NN);
	//NN�ŏk������(��������4��f����)

		//NN�Ŋg�又��
/*	for(i=0;i<p[0]->height;i++){
		for(j=0;j<p[0]->width;j++){
			p[0]->imageData[i*p[0]->widthStep + 3*j+0]=(uchar)pColorPhotoI->imageData[(2*i)*pColorPhotoI->widthStep + 3*(2*j)+0];
			p[0]->imageData[i*p[0]->widthStep + 3*j+1]=(uchar)pColorPhotoI->imageData[(2*i)*pColorPhotoI->widthStep + 3*(2*j)+1];
			p[0]->imageData[i*p[0]->widthStep + 3*j+2]=(uchar)pColorPhotoI->imageData[(2*i)*pColorPhotoI->widthStep + 3*(2*j)+2];
	}}
*/

	cvCopy(p[0],re_img);


	//���̔��ʂ̊m�F�p�C���[�W
	cvCopy(pColorPhotoI,binary_image);



//��1226�ǉ�
	cvCopy(pColorPhotoI,dst);



	clock_t time1 = clock();

//*************************************************************************************************************************//
//1/4�摜���璆���g�m�C�Y����
address0=0;
address1=0;


//�C�v�V�����t�B���^�p
int ip_c[3];ip_c[0]=0;ip_c[1]=0;ip_c[2]=0;
int ip[3];


//�������ϒl�Z�o
unsigned int patch_ave1[3];
unsigned int patch_ave2[3];
unsigned int ave_plane[2][3];


for(i=0;i<height2;i++){

	address0=i*p[0]->widthStep;

	for(j=0;j<width2;j++){

			address1=address0 + 3*j;

			t1=(uchar)p[0]->imageData[address1 +0];
			t2=(uchar)p[0]->imageData[address1 +1];
			t3=(uchar)p[0]->imageData[address1 +2];

			//�m�C�Y�ώZ�摜�̏�����
			noise_img->imageData[address1 +0]=0;
			noise_img->imageData[address1 +1]=0;
			noise_img->imageData[address1 +2]=0;


			tb=t1;tg=t2;tr=t3;

			//������
			sum=0;


			//������
			ip[0]=0;
			ip[1]=0;
			ip[2]=0;

//			for(int num=1;num<2;num++){
			for(int num=0;num<2;num++){


				//������
				patch_ave1[0]=0;
				patch_ave1[1]=0;
				patch_ave1[2]=0;


				address2=address1-Xth*p[0]->widthStep;
				for(s=-Xth;s<Xth+1;s++){

					address3=address2-3*Xth;
					for(t=-Xth;t<Xth+1;t++){
						
						if( (address3>=0)&&(address3<=p[num]->widthStep*p[num]->height) ){

//						v1=(uchar)p[num]->imageData[address3 +0];
//						v2=(uchar)p[num]->imageData[address3 +1];
//						v3=(uchar)p[num]->imageData[address3 +2];
						char_p1=&p[num]->imageData[address3 +0];
						v1=(uchar)*char_p1;
						v2=(uchar)*(char_p1+1);
						v3=(uchar)*(char_p1+2);

//���J�[�V�u�t�B���^����


						//���ϒl�Z�o�̂��߂̉�f���Z
						patch_ave1[0]+=v1;
						patch_ave1[1]+=v2;
						patch_ave1[2]+=v3;

						}
						address3+=3;

					}//t
					address2+=p[0]->widthStep;

				}//s

				//�t���[�����̉��Z��f�l
				ave_plane[num][0]=patch_ave1[0];
				ave_plane[num][1]=patch_ave1[1];
				ave_plane[num][2]=patch_ave1[2];

			}

			//�������̉��Z��f�̍���
			thv1=ave_plane[0][0]-ave_plane[1][0];
			thv2=ave_plane[0][1]-ave_plane[1][1];
			thv3=ave_plane[0][2]-ave_plane[1][2];
			if(thv1<0){thv1*=-1;}
			if(thv2<0){thv2*=-1;}
			if(thv3<0){thv3*=-1;}

			//�K�i��
			zansa=(thv1+thv2+thv3)/(3*(2*Xth+1)*(2*Xth+1));
//			zansa=(1.5*thv1+0.75*thv2+0.75*thv3)/(3*(2*Xth+1)*(2*Xth+1));


			float p_coef;

			//���J�[�V�u�t�B���^����
//			tb=((2*Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +0]+Dth1)/(Dth1*2);	
			tb=((2*Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +0])/(Dth1*2);	
//			tg=((2*Dth1-gain_rate[zansa])*t2+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +1]+Dth1)/(Dth1*2);
//			tr=((2*Dth1-gain_rate[zansa])*t3+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +2]+Dth1)/(Dth1*2);

			
//			p_coef=float(gain_rate[zansa])/float(Dth1*2);
//			p_coef=float(gain_rate[zansa])/float(Dth1*1.2);
//			p_coef=1.0-(float(gain_rate[zansa])/float(Dth1*mg2[t1]));
			p_coef=1.0-(float(gain_rate[zansa])/float(Dth1*mg2[tb]));



//			tb=0.80*((2*Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +0]+Dth1)/(Dth1*2) + 0.20*(uchar)p[1]->imageData[address1 +0];	
//			tg=0.80*((2*Dth1-gain_rate[zansa])*t2+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +1]+Dth1)/(Dth1*2) + 0.20*(uchar)p[1]->imageData[address1 +1];
//			tr=0.80*((2*Dth1-gain_rate[zansa])*t3+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +2]+Dth1)/(Dth1*2) + 0.20*(uchar)p[1]->imageData[address1 +2];

//			p_coef=0.5-0.075*sqrt(float(zansa));
/*			p_coef=0.5-0.1*sqrt(float(zansa));
			if(p_coef<0){p_coef=0;}
			else if(p_coef>1){p_coef=1;}

			tb=uchar((1-p_coef)*t1+p_coef*(uchar)p[1]->imageData[address1 +0]);
			tg=uchar((1-p_coef)*t2+p_coef*(uchar)p[1]->imageData[address1 +1]);
			tr=uchar((1-p_coef)*t3+p_coef*(uchar)p[1]->imageData[address1 +2]);
*/


//			if( abs((uchar)p[1]->imageData[address1 +0]-t1)<20){
//			if( abs((uchar)p[1]->imageData[address1 +0]-tb)<10){
//			if( (uchar)p[1]->imageData[address1 +0]<Dth1 && t1 < Dth1){
//			if( (uchar)p[1]->imageData[address1 +0]<Dth1 && tb < Dth1){
//			if(  tb < Dth1){



//			if( zansa<30){

//			short avg_value=((uchar)p[1]->imageData[address1 +0]+abs((uchar)p[1]->imageData[address1 +1]+(uchar)p[1]->imageData[address1 +2]-256)
//			+t1+abs(t2+t3-256))/4;

//			short avg_value=(tb);
			short avg_value=((uchar)p[1]->imageData[address1 +0]+t1)/2;
//			short avg_value=((uchar)p[1]->imageData[address1 +0]+t1)/2 + abs((uchar)p[1]->imageData[address1 +0]-t1)/2;

//			if( avg_value<Dth1 ){


//			tb=uchar(mg[avg_value]*(1-p_coef)*t1+(1-mg[avg_value])*p_coef*(uchar)p[1]->imageData[address1 +0]);
//			tg=uchar(mg[avg_value]*(1-p_coef)*t2+(1-mg[avg_value])*p_coef*(uchar)p[1]->imageData[address1 +1]);
//			tr=uchar(mg[avg_value]*(1-p_coef)*t3+(1-mg[avg_value])*p_coef*(uchar)p[1]->imageData[address1 +2]);

//				tb=uchar(mg[avg_value]*(1-p_coef)*t1+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +0]);
//				tg=uchar(mg[avg_value]*(1-p_coef)*t2+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +1]);
//				tr=uchar(mg[avg_value]*(1-p_coef)*t3+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +2]);
				tb=uchar(mg[avg_value]*p_coef*t1+(1-(mg[avg_value]*p_coef))*(uchar)p[1]->imageData[address1 +0]);
				tg=uchar(mg[avg_value]*p_coef*t2+(1-(mg[avg_value]*p_coef))*(uchar)p[1]->imageData[address1 +1]);
				tr=uchar(mg[avg_value]*p_coef*t3+(1-(mg[avg_value]*p_coef))*(uchar)p[1]->imageData[address1 +2]);
//				tb=uchar(p_coef*t1+(1-p_coef)*(uchar)p[1]->imageData[address1 +0]);
//				tg=uchar(p_coef*t2+(1-p_coef)*(uchar)p[1]->imageData[address1 +1]);
//				tr=uchar(p_coef*t3+(1-p_coef)*(uchar)p[1]->imageData[address1 +2]);

//				tg=t2;
//				tr=t3;


//				tb=0.8*(uchar(mg[avg_value]*(1-p_coef)*t1+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +0]))+0.20*(uchar)p[1]->imageData[address1 +0];
//				tg=0.8*(uchar(mg[avg_value]*(1-p_coef)*t2+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +1]))+0.20*(uchar)p[1]->imageData[address1 +1];
//				tr=0.8*(uchar(mg[avg_value]*(1-p_coef)*t3+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +2]))+0.20*(uchar)p[1]->imageData[address1 +2];

/*			}else{
//				tb=uchar((1-p_coef)*t1+(1-((1-p_coef)))*(uchar)p[1]->imageData[address1 +0]);
//				tg=uchar((1-p_coef)*t2+(1-((1-p_coef)))*(uchar)p[1]->imageData[address1 +1]);
//				tr=uchar((1-p_coef)*t3+(1-((1-p_coef)))*(uchar)p[1]->imageData[address1 +2]);
				tb=uchar(p_coef*t1+(1-p_coef)*(uchar)p[1]->imageData[address1 +0]);
				tg=uchar(p_coef*t2+(1-p_coef)*(uchar)p[1]->imageData[address1 +1]);
				tr=uchar(p_coef*t3+(1-p_coef)*(uchar)p[1]->imageData[address1 +2]);



//				short avg_value=(tb);
//				tb=uchar(mg[avg_value]*(1-p_coef)*t1+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +0]);
//				tg=uchar(mg[avg_value]*(1-p_coef)*t2+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +1]);
//				tr=uchar(mg[avg_value]*(1-p_coef)*t3+(1-(mg[avg_value]*(1-p_coef)))*(uchar)p[1]->imageData[address1 +2]);

//				tg=t2;
//				tr=t3;
			}

*/

//			tb=((Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +0]+Dth1)/(Dth1);	
//			tg=((Dth1-gain_rate[zansa])*t2+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +1]+Dth1)/(Dth1);
//			tr=((Dth1-gain_rate[zansa])*t3+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +2]+Dth1)/(Dth1);

//			tb=((2*Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*ave_plane[1][0]/((2*Xth+1)*(2*Xth+1))+Dth1)/(Dth1*2);	
//			tg=((2*Dth1-gain_rate[zansa])*t2+gain_rate[zansa]*ave_plane[1][1]/((2*Xth+1)*(2*Xth+1))+Dth1)/(Dth1*2);
//			tr=((2*Dth1-gain_rate[zansa])*t3+gain_rate[zansa]*ave_plane[1][2]/((2*Xth+1)*(2*Xth+1))+Dth1)/(Dth1*2);
//			tb=((2*Dth1-gain_rate[zansa])*ave_plane[0][0]/((2*Xth+1)*(2*Xth+1))+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +0]+Dth1)/(Dth1*2);	
//			tg=((2*Dth1-gain_rate[zansa])*ave_plane[0][1]/((2*Xth+1)*(2*Xth+1))+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +1]+Dth1)/(Dth1*2);
//			tr=((2*Dth1-gain_rate[zansa])*ave_plane[0][2]/((2*Xth+1)*(2*Xth+1))+gain_rate[zansa]*(uchar)p[1]->imageData[address1 +2]+Dth1)/(Dth1*2);
//			tb=((2*Dth1-gain_rate[zansa])*t1+gain_rate[zansa]*(uchar)(0.2*p[1]->imageData[address1-3 +0]+0.6*p[1]->imageData[address1 +0]+0.2*p[1]->imageData[address1+3 +0])+Dth1)/(Dth1*2);	
//			tg=((2*Dth1-gain_rate[zansa])*t2+gain_rate[zansa]*(uchar)(0.2*p[1]->imageData[address1-3 +1]+0.6*p[1]->imageData[address1 +1]+0.2*p[1]->imageData[address1+3 +1])+Dth1)/(Dth1*2);
//			tr=((2*Dth1-gain_rate[zansa])*t3+gain_rate[zansa]*(uchar)(0.2*p[1]->imageData[address1-3 +2]+0.6*p[1]->imageData[address1 +2]+0.2*p[1]->imageData[address1+3 +2])+Dth1)/(Dth1*2);


			//2�Ԃ��1NR�摜
			re_img->imageData[address1 +0]=tb;
			re_img->imageData[address1 +1]=tg;
			re_img->imageData[address1 +2]=tr;

			noise_img->imageData[address1 +0]=(128+tb-t1);
			noise_img->imageData[address1 +1]=(128+tg-t2);
			noise_img->imageData[address1 +2]=(128+tr-t3);


//�C�v�V�����I�ȏ���
/*
						//���ϒl�Z�o�̂��߂̉�f���Z
						patch_ave1[0]+=v1;
						patch_ave1[1]+=v2;
						patch_ave1[2]+=v3;

							if( abs(v1-t1)+abs(v2-t2)+abs(v3-t3) <2*Dth1 && num==1){
//							if(  num==1){
/*								if(abs(v1-t1)<Dth1){
									ip[0]+=(v1-t1);
									ip_c[0]+=1;

								}else if((v1-t1)>=0 && (v1-t1)<2*Dth1){
									ip[0]+=(2*Dth1-(v1-t1));
									ip_c[0]+=1;

								}else if((v1-t1)<0 && (v1-t1)>-2*Dth1){
									ip[0]-=((v1-t1)+2*Dth1);
									ip_c[0]+=1;

								}

								if(abs(v2-t2)<Dth1){
									ip[1]+=(v2-t2);
									ip_c[1]+=1;

								}else if((v2-t2)>=0 && (v2-t2)<2*Dth1){
									ip[1]+=(2*Dth1-(v2-t2));
									ip_c[1]+=1;

								}else if((v2-t2)<0 && (v2-t2)>-2*Dth1){
									ip[1]-=((v2-t2)+2*Dth1);
									ip_c[1]+=1;

								}

								if(abs(v3-t3)<20){
									ip[2]+=(v3-t3);
									ip_c[2]+=1;

								}else if((v3-t3)>=0 && (v3-t3)<2*Dth1){
									ip[2]+=(2*Dth1-(v3-t3));
									ip_c[2]+=1;

								}else if((v3-t3)<0 && (v3-t3)>-2*Dth1){
									ip[2]-=((v3-t3)+2*Dth1);
									ip_c[2]+=1;
								}
*/
/*
//									ip[0]+=(v1-t1);
									ip[0]+=(v1-ave_plane[0][0]);
									ip_c[0]+=1;
//									ip[1]+=(v2-t2);
									ip[1]+=(v2-ave_plane[0][1]);
									ip_c[1]+=1;
//									ip[2]+=(v3-t3);
									ip[2]+=(v3-ave_plane[0][2]);
									ip_c[2]+=1;
							}



						}
						address3+=3;

					}//t
					address2+=p[0]->widthStep;	
				}//s
				//�t���[�����̉��Z��f�l
				ave_plane[num][0]=patch_ave1[0]/((2*Xth+1)*(2*Xth+1));
				ave_plane[num][1]=patch_ave1[1]/((2*Xth+1)*(2*Xth+1));
				ave_plane[num][2]=patch_ave1[2]/((2*Xth+1)*(2*Xth+1));

			}
			if(ip_c[0]>0){
				ip[0]/=ip_c[0];
			}else{
				ip[0]=0;
			}
			if(ip_c[1]>0){
				ip[1]/=ip_c[1];
			}else{
				ip[1]=0;
			}
			if(ip_c[2]>0){
				ip[2]/=ip_c[2];
			}else{
				ip[2]=0;
			}


//			tb=t1+ip[0];
//			tg=t2+ip[1];
//			tr=t3+ip[2];
			tb=ave_plane[0][0]+ip[0];
			tg=ave_plane[0][1]+ip[1];
			tr=ave_plane[0][2]+ip[2];
			//2�Ԃ��1NR�摜
			re_img->imageData[address1 +0]=tb;
			re_img->imageData[address1 +1]=tg;
			re_img->imageData[address1 +2]=tr;
//			noise_img->imageData[address1 +0]=(128+(tb-t1));
//			noise_img->imageData[address1 +1]=(128+(tg-t2));
//			noise_img->imageData[address1 +2]=(128+(tr-t3));
			noise_img->imageData[address1 +0]=(128+(tb-ave_plane[0][0]));
			noise_img->imageData[address1 +1]=(128+(tg-ave_plane[0][1]));
			noise_img->imageData[address1 +2]=(128+(tr-ave_plane[0][2]));
			ip_c[0]=0;ip_c[1]=0;ip_c[2]=0;

*/
/////////////////////////

	}}

	//��1027
	cvCopy(re_img, p[1]);
//	cvCopy(p[0], p[1]);


	//��1027
//	cvResize(noise_img,noise_img0,CV_INTER_LINEAR);
//	cvResize(noise_img,noise_img0,CV_INTER_NN);

	//NN�Ŋg�又��
	for(i=0;i<noise_img->height;i++){
		for(j=0;j<noise_img->width;j++){
			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+0)+0]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+0];
			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+1)+0]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+0];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+0)+0]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+0];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+1)+0]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+0];

			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+0)+1]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+1];
			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+1)+1]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+1];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+0)+1]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+1];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+1)+1]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+1];

			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+0)+2]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+2];
			noise_img0->imageData[(2*i+0)*noise_img0->widthStep + 3*(2*j+1)+2]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+2];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+0)+2]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+2];
			noise_img0->imageData[(2*i+1)*noise_img0->widthStep + 3*(2*j+1)+2]=(uchar)noise_img->imageData[i*noise_img->widthStep + 3*j+2];
	}}




	clock_t time2 = clock();
	double total_time1 = (double)(time2-time1)/CLOCKS_PER_SEC;
	printf("2�K�w: %g sec.\n", total_time1);


//*************************************************************************************************************************//
//�t���T�C�YNR����

	address1=0;
	address0=0;

	//�t���X�P�[���摜���璆���g�m�C�Y����
	for(i=0;i<height1;i++){

		address1=address0;

		for(j=0;j<width1;j++){

			//�����������Ώۂ̃t���[��(p[0]����ԐV����)
			ttt1=(uchar)p0[0]->imageData[address1 +0]+(uchar)noise_img0->imageData[address1 +0]-128;
			ttt2=(uchar)p0[0]->imageData[address1 +1]+(uchar)noise_img0->imageData[address1 +1]-128;
			ttt3=(uchar)p0[0]->imageData[address1 +2]+(uchar)noise_img0->imageData[address1 +2]-128;

			if(ttt1>255){t1=255;}else if(ttt1<0){t1=0;}else{t1=ttt1;}
			if(ttt2>255){t2=255;}else if(ttt2<0){t2=0;}else{t2=ttt2;}			
			if(ttt3>255){t3=255;}else if(ttt3<0){t3=0;}else{t3=ttt3;}

			p0[0]->imageData[address1 +0]=(uchar)t1;
			p0[0]->imageData[address1 +1]=(uchar)t2;
			p0[0]->imageData[address1 +2]=(uchar)t3;



		address1+=3;
		}
	address0+=p0[0]->widthStep;
	}

	clock_t time3 = clock();
	double total_time2 = (double)(time3-time2)/CLOCKS_PER_SEC;
	printf("3�K�w: %g sec.\n", total_time2);


	cvCopy(p0[0], p0[1]);


//******************************************************************************************************
//******************************************************************************************************


#ifdef movie_out

	//AVI�������ݐݒ� ------------------------------
	if(counts==0){
	VideoWriter = cvCreateVideoWriter(filename3, CV_FOURCC('D','I','B',' '), 
		fps , cvSize(dst->width,dst->height) );
		}
	//----------------------------------------------
#endif


	//��YCbCr��BGR
	cvCvtColor(p0[0],p0[0],CV_YCrCb2BGR);

	cvCvtColor(binary_image,binary_image,CV_YCrCb2BGR);


#ifdef movie_out
	//AVI��������------------------------------------
	cvWriteFrame(VideoWriter,p0[0]);	//�����t���[���o�C���e����
//	cvWriteFrame(VideoWriter,binary_image);	//�����t���[���o�C���e����
	// ----------------------------------------------
#endif


	printf("frame: %d\n", counts);
	cvWaitKey(10);

}



#ifdef movie_out
	// �㏈��-----------------------------------
	cvReleaseVideoWriter(&VideoWriter);		
	//-----------------------------------------
#endif

	//���

/*	cvReleaseImage(p0);
	cvReleaseImage(p);
	cvReleaseImage(pp);
	cvReleaseImage(&re_img0);
	cvReleaseImage(&re_img);
	cvReleaseImage(&re_img2);
	cvReleaseImage(&noise_img0);
	cvReleaseImage(&noise_img);
	cvReleaseImage(&noise_img2);
	cvReleaseImage(&dst);


	free(x_coef);
*/
	return 1;


}


