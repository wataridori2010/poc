#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <list>

#include <tchar.h>
#include <ctype.h>
#include<iostream>
#include <fstream>
#include <vector>
#include <windows.h>


#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"



//�\����
struct regist{
	double img;
	double x;
	double y;
};

struct address{
	int ad;
	double ratio;
};

void get_template(IplImage *src_gray, int step, int i, int j, double magnify_ratio, double* patch_high);
void get_template2(IplImage *src_gray, int step, int i, int j, double magnify_ratio, double* patch_high, double *src_low);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main (int argc, char **argv){

	//�摜����
	printf("loading image..");
	IplImage* src		= cvLoadImage(argv[1],1);//
	IplImage* src_gray	= cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);
	IplImage* src_gray_s1= cvCreateImage(cvSize(src->width,src->height), IPL_DEPTH_8U, 1);


	cvCvtColor(src, src_gray, CV_BGR2GRAY);	


	printf("high-pass filtering..");
	//�n�C�p�X�����A���[�p�X����
	double* src_low	= (double*)calloc(src->width*src->height,sizeof(double));
	double* src_high= (double*)calloc(src->width*src->height,sizeof(double));
	double* src_raw	= (double*)calloc(src->width*src->height,sizeof(double));

	//�n�C�p�X�����A���[�p�X�����ɑ��
	double sig=0.70;
	cvSmooth(src_gray,src_gray_s1,CV_GAUSSIAN,7,7,sig);
	cvShowImage("src_gray_s1",src_gray_s1);

	for(int i=0;i<src->height;i++){
		for(int j=0;j<src->width;j++){

			int address		=i*src_gray->width+j;
			int address_ipl	=i*src_gray->widthStep+j;

			src_low[address]=double((uchar)src_gray_s1->imageData[address_ipl]);
			src_high[address]=double((uchar)src_gray->imageData[address_ipl])-src_low[address];

			src_raw[address]=double((uchar)src_gray->imageData[address_ipl]);

		}}



	double magnify_ratio=atof(argv[2]);
	double magnify_ratio_inv=1.0/double(magnify_ratio);
	//�g��摜
	IplImage*	src_mag		= cvCreateImage(cvSize(int(src->width*magnify_ratio),int(src->height*magnify_ratio)), IPL_DEPTH_8U, 1);	//(1/4)�O���[�X�P�[���̗̈�m��
	IplImage*	src_mag_dst		= cvCreateImage(cvSize(int(src->width*magnify_ratio),int(src->height*magnify_ratio)), IPL_DEPTH_8U, 1);	//(1/4)�O���[�X�P�[���̗̈�m��
	int*		address_mag	= (int*)calloc(src_mag->width*src_mag->height,sizeof(int));
	double*		sad_mag		= (double*)calloc(src_mag->width*src_mag->height,sizeof(double));


	//�g��
	cvResize(src_gray, src_mag, CV_INTER_LINEAR);
	//�����{�J�X
//	cvSmooth(src_mag,src_mag,CV_GAUSSIAN,7,7,2.0*sig);



	//�p�b�`�T�C�Y
	int step=2;
	double *patch_high=(double*)calloc((2*step+1)*(2*step+1),sizeof(double));
	//�����p�b�`�T�C�Y
	int step_s=2;

	//�g��摜����T��
	for(int i=step*2; i<src_mag->height-(step*2+1); i++){
		for(int j=step*2; j<src_mag->width-(step*2+1); j++){


			int address_high	=i*src_mag->width + j;//�g��摜�̒����ʒu
			//�g��摜�̃p�b�`���擾
			int k=0;
/*			for(int s=-step; s<step+1; s++){
				for(int t=-step; t<step+1; t++){

					int address_ipl	=(i+s)*src_mag->widthStep+j+t;
					patch_high[k]= (uchar)src_mag->imageData[address_ipl];
					k++;
				}}
*/
//			get_template(src_gray, step, i, j, magnify_ratio, patch_high);
//			get_template2(src_gray, step, i, j, magnify_ratio, patch_high, src_low);
			get_template2(src_gray, step, i, j, magnify_ratio, patch_high, src_raw);


			//���摜�̃p�b�`��T��
			//���摜�̈ʒu
			int low_i=i*magnify_ratio_inv;
			int low_j=j*magnify_ratio_inv;

			double sum_min=600000;
			for(int s=-step_s;s<step_s+1;s++){
				for(int t=-step_s;t<step_s+1;t++){

					if( (low_i+s)>=step_s && (low_i+s)<src->height-(step_s+1) && (low_j+t)>=step_s && (low_j+t)<src->width-(step_s+1)  ){




						int address_low	=(low_i+s)*src->width + low_j+t;//���摜�̒����ʒu

						//�Ή�����p�b�`���擾
						k=0;
						double sum=0;
						for(int y=-step;y<step+1;y++){
							for(int x=-step;x<step+1;x++){

								int address	=(low_i+s+y)*src->width + low_j+t+x;
//								sum+=(patch_high[k] - src_low[address]);//��r: SAD
								sum+=abs(patch_high[k] - src_raw[address]);//��r: SAD
								k++;
							}}

						if(sum<sum_min){
							sum_min=sum;
							address_mag[address_high]=address_low;
							sad_mag[address_high]=sum;
						}

					}
				}}

		}
				//���������L�q
			if(i==int(src_mag->height*0.1)){printf("10percent�Ή��t��..");}
			if(i==int(src_mag->height*0.2)){printf("20..");}
			if(i==int(src_mag->height*0.3)){printf("30..");}
			if(i==int(src_mag->height*0.4)){printf("40..");}
			if(i==int(src_mag->height*0.5)){printf("50..");}
			if(i==int(src_mag->height*0.6)){printf("60..");}
			if(i==int(src_mag->height*0.7)){printf("70..");}
			if(i==int(src_mag->height*0.8)){printf("80..");}
			if(i==int(src_mag->height*0.9)){printf("90..\n");}
	}


	//�摜����
	int *psf=(int*)calloc(9,sizeof(int));
	psf[0]=1;psf[1]=2;psf[2]=1;
	psf[3]=2;psf[4]=8;psf[5]=2;
	psf[6]=1;psf[7]=2;psf[8]=1;

	for(int i=step*2;i<src_mag->height-(step*2+1);i++){
		for(int j=step*2;j<src_mag->width-(step*2+1);j++){

			int address_high	=i*src_mag->width + j;//�g��摜�̈ʒu
			int address_high_ipl=i*src_mag->widthStep + j;//�g��摜�̈ʒu
//			int val=(uchar)src_mag->imageData[address_high_ipl] + src_high[ address_mag[address_high ]];
//			int val=(uchar)src_gray->imageData[ address_mag[address_high ]];


			get_template2(src_gray, step, i, j, magnify_ratio, patch_high, src_raw);
			int val=cvFloor(patch_high[12]+src_high[ address_mag[address_high ]]);
//			int val=cvFloor(patch_high[12]);

//			get_template2(src_gray, step, i, j, magnify_ratio, patch_high, src_low);
//			int val=cvFloor(src_raw[ address_mag[address_high ]]);

/*			int val=0;
			int sad_sum=0;
			for(int s=-1;s<2;s++){
				for(int t=-1;t<2;t++){
					
					int address_high	=(i+s)*src_mag->width + (j+t);//�g��摜�̈ʒu
					int address_high_ipl=(i+s)*src_mag->widthStep + (j+t);//�g��摜�̈ʒu
//					val+=((uchar)src_mag->imageData[address_high_ipl]+src_high[ address_mag[address_high ]])*abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);
//					sad_sum+=abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);
//					val+=(cvFloor(src_raw[ address_mag[address_high ]]))*abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);
//					sad_sum+=abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);

					get_template2(src_gray, step, i+s, j+t, magnify_ratio, patch_high, src_raw);

					val+=cvFloor(patch_high[12]+src_high[ address_mag[address_high ]])*abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);
					sad_sum+=abs(sad_mag[address_high]*psf[3*(s+1)+(t+1)]);
				}}
//			printf("%d,%d,%d,%d\n",i,j,val,sad_sum);
			val=val/(sad_sum+1);

*/





			if(val>255)val=255;
			else if(val<0)val=0;

			src_mag_dst->imageData[address_high_ipl]=(uchar)val;
	}}

	cvShowImage("src_gray",src_gray);
	cvShowImage("src_mag",src_mag);
	cvShowImage("src_mag_dst",src_mag_dst);

	cvSaveImage("src_mag_dst.png",src_mag_dst);

	cvWaitKey(0);


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	return 1;


}



//Iplimage		�������摜
//step			�e���v���[�g��1��
//i				���𑜉摜��y���W
//j				���𑜉摜��x���W
//magnify_ratio �g��{��
//patch_high	�o�b�t�@


void get_template(IplImage *src_gray, int step, int i, int j, double magnify_ratio, double* patch_high){


int k=0;
for(int s=-step; s<step+1; s++){
	for(int t=-step; t<step+1; t++){
	patch_high[k]=0;
	k++;
}}



double low_i=double(i)/magnify_ratio;
double low_j=double(j)/magnify_ratio;
int mlow_i=int(low_i);
int mlow_j=int(low_j);
int Mlow_i=int(low_i)+1;
int Mlow_j=int(low_j)+1;


double gain[4];

gain[0]=double(Mlow_i-low_i)*double(Mlow_j-low_j);//������W�̏d��
gain[1]=double(Mlow_i-low_i)*double(low_j-mlow_j);//�E����W�̏d��
gain[2]=double(low_i-mlow_i)*double(Mlow_j-low_j);//�������W�̏d��
gain[3]=double(low_i-mlow_i)*double(low_j-mlow_j);//�E�����W�̏d��


	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address_ipl	=(mlow_i+s)*src_gray->widthStep+mlow_j+t;
			patch_high[k]+=((uchar)src_gray->imageData[address_ipl])*gain[0];
			k++;
	}}

	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address_ipl	=(mlow_i+s)*src_gray->widthStep+Mlow_j+t;
			patch_high[k]+=((uchar)src_gray->imageData[address_ipl])*gain[1];
			k++;
	}}

	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address_ipl	=(Mlow_i+s)*src_gray->widthStep+mlow_j+t;
			patch_high[k]+=((uchar)src_gray->imageData[address_ipl])*gain[2];
			k++;
	}}
	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address_ipl	=(Mlow_i+s)*src_gray->widthStep+Mlow_j+t;
			patch_high[k]+=((uchar)src_gray->imageData[address_ipl])*gain[3];
			k++;
	}}



}


///////////////////////////////////////////////////////////////////////////////////////////////////
//Iplimage		�������摜
//step			�e���v���[�g��1��
//i				���𑜉摜��y���W
//j				���𑜉摜��x���W
//magnify_ratio �g��{��
//patch_high	�o�b�t�@


void get_template2(IplImage *src_gray, int step, int i, int j, double magnify_ratio, double* patch_high, double *src_low){


int k=0;
for(int s=-step; s<step+1; s++){
	for(int t=-step; t<step+1; t++){
	patch_high[k]=0;
	k++;
}}



double low_i=double(i)/magnify_ratio;
double low_j=double(j)/magnify_ratio;
int mlow_i=int(low_i);
int mlow_j=int(low_j);
int Mlow_i=int(low_i)+1;
int Mlow_j=int(low_j)+1;


double gain[4];

gain[0]=double(Mlow_i-low_i)*double(Mlow_j-low_j);//������W�̏d��
gain[1]=double(Mlow_i-low_i)*double(low_j-mlow_j);//�E����W�̏d��
gain[2]=double(low_i-mlow_i)*double(Mlow_j-low_j);//�������W�̏d��
gain[3]=double(low_i-mlow_i)*double(low_j-mlow_j);//�E�����W�̏d��

//	cout << gain[0] << "  ," <<gain[1] << "  ," <<gain[2] << "  ," <<gain[3] << endl;

	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address	=(mlow_i+s)*src_gray->width+mlow_j+t;
			patch_high[k]+=((uchar)src_low[address])*gain[0];
			k++;
	}}

	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address	=(mlow_i+s)*src_gray->width+Mlow_j+t;
			patch_high[k]+=((uchar)src_low[address])*gain[1];
			k++;
	}}

	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address	=(Mlow_i+s)*src_gray->width+mlow_j+t;
			patch_high[k]+=((uchar)src_low[address])*gain[2];
			k++;
	}}
	k=0;
	for(int s=-step; s<step+1; s++){
		for(int t=-step; t<step+1; t++){

			int address	=(Mlow_i+s)*src_gray->width+Mlow_j+t;
			patch_high[k]+=((uchar)src_low[address])*gain[3];
			k++;
	}}



}
