#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//#include "cv.h"
//#include "cxcore.h"
//#include "highgui.h"

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2\\opencv.hpp"

#define N_gen 1228800 /* N��������*///*************************************************************************�����ɉ摜�T�C�Y(�s�N�Z��)������!!
//#define N 4096 /* N��������*/
#define EPS2 pow(10.0, -3.0) /* epsilon�̐ݒ�*/
#define KMAX 500 /* �ő唽����*/



/* 1�m�����̌v�Za[0,...,N-1] */
float vector_norm1( float *a );
/* A�x�N�g��a[0,...,N-1]��b[0,...,N-1]�̓��ς��v�Z����*/
float inner_product(float *a, float *b);
/* �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�c<-Ab*/
void matrix_vector_product( float *a, float *b, float *c ,IplImage*);
/* �������z�@(CG�@) */
float* cg( float *a, float *b, float *x ,IplImage*);


float* gauss_filter(int filter_size,float sigma);//�K�E�X�J�[�l���̒l������


int main(int argc, char **argv)
{
	IplImage *src,*dst;
	FILE *fin, *fout;
//	double a[N][N], b[N], x[N];
//	float *a, *b, *x;
	int i,j,s,t;

//	dst:�{�P���܂񂾍��𑜉摜
//  src:���[�v�̏����l

//	src = cvLoadImage("D:\\lenna_Lanczos3_40000_cut.bmp",0);
//	src = cvLoadImage("D:\\SR_9_result_0.7_lena-y_cut�g�p.bmp",0);
	src = cvLoadImage("C:\\ito\\22\\Debug\\sr.png",0);
//	src = cvLoadImage(argv[1],0);


//	dst = cvLoadImage("D:\\lena-y_cut.bmp",0);
//	dst = cvLoadImage("D:\\source1_1024.bmp",0);
//	src = cvLoadImage("D:\\SR_heisin_4pix_cut.bmp",0);
//	dst = cvLoadImage("D:\\SR_5_bmp.bmp",0);
	dst = cvLoadImage("C:\\ito\\22\\Debug\\cu.png",0);
//	dst = cvLoadImage(argv[2],0);


//	src = cvLoadImage("D:\\SR_iti1024_2.bmp",0);
	puts("0");

	float* x=(float*)calloc(src->width*src->height,sizeof(float));
	float* b=(float*)calloc(src->width*src->height,sizeof(float));

	for(i=0;i<src->height;i++){
		for(j=0;j<src->width;j++){
			*(x+i*src->width+j)=(uchar)(src->imageData[i*src->widthStep+j*src->nChannels]);
			*(b+i*src->width+j)=(uchar)(dst->imageData[i*dst->widthStep+j*dst->nChannels]);

	}}

	puts("a");

//PSF�̐���
	float* psf=(float*)calloc(121,sizeof(float));
	//�K�E�V�A���J�[�l���̏ꍇ
	float sigma=0.5;
	int filter_size=5;
	psf = gauss_filter(filter_size,sigma);



	puts("aa");

	x = cg( psf, b, x ,src); /* �������z�@(CG�@) */


	int resu=0;
	/* ���ʂ̏o��*/
	for(i=0;i<src->height;i++){
		for(j=0;j<src->width;j++){
			if(*(x+i*src->width+j)>255){resu=255;}
			else if(*(x+i*src->width+j)<0){resu=0;}
			else{resu=(int)*(x+i*src->width+j);}
			(dst->imageData[i*src->widthStep+j])= (uchar)(resu);
	}}
	cvSaveImage("C:\\ito\\22\\Debug\\SR_result.png",dst);//���𑜉摜�̕ۑ�

	return 0;
}




/* �������z�@(CG�@) */
float* cg(float *a, float *b, float *x, IplImage* src)
{
	float  alpha, beta, work;
	float *r=(float*)calloc(N_gen,sizeof(float));
	float *p=(float*)calloc(N_gen,sizeof(float));
	float *tmp=(float*)calloc(N_gen,sizeof(float)); 
	double eps;
	int i, k=0;
	//������
	for(i=0;i<N_gen;i++){*(r+i)=0;*(p+i)=0;*(tmp+i)=0;}

	puts("a");


	matrix_vector_product( a, x, tmp, src); /* tmp<-A b *///������
	for( i = 0; i < N_gen; i++)
	{
		*(p+i) = *(b+i) -*(tmp+i) ; *(r+i) = *(p+i);
	}

	puts("a2");



do
	{
	/* alpha�̌v�Z*/
		matrix_vector_product( a, p, tmp, src); /* tmp<-A p_k*///������
		work = inner_product( p, tmp); /* work <-(p,Ap_k) */
		alpha = inner_product( p, r ) / work ;

	puts("a3");

	/* x_{k+1}��r_{k+1}�̌v�Z*/
	for( i = 0; i < N_gen; i++) *(x+i) = *(x+i) + alpha*(*(p+i));
	for( i= 0; i< N_gen; i++) *(r+i) = *(r+i) -alpha*(*(tmp+i));

	/* ��������*/
	eps= (double)vector_norm1(r);
	eps=(double)sqrt((double)eps);

	k++; /* �����񐔂̍X�V*/
	printf("iterate:%d,	eps:%f\n",k,(float)eps);
//	if ( eps< (EPS2*N_gen) ) goto OUTPUT;

	/* beta��p_{k+1}�̌v�Z*/
	beta = -inner_product( r, tmp) / work;
	for( i = 0; i < N_gen; i++) *(p+i) = *(r+i) + beta*(*(p+i));

	puts("a4");

//}while( k < KMAX );
}while( k < 10 );


OUTPUT:

	if ( k == KMAX )
	{
	printf("������������܂���ł���\n");
//	exit(1);
	}
	else
	{
	printf("�����񐔂�%d��ł�\n", k); /* �����񐔂���ʂɕ\��*/
	}

	return x;
}




/* �s��a[0,...,N-1][0,...,N-1]�ƃx�N�g��b[0,...,N-1]�Ƃ̐�c <-Ab*/

void matrix_vector_product(float *a, float *b, float *c, IplImage* src)
{
	float wk=0;
	int i, j, s, t;

	float work;

	for ( i = 0; i < N_gen; i++)
	{
		wk = 0.0;
/*		for ( j = 0; j < N; j++ )
		{
			work=*(b+j);
			wk=wk+ *(a+ i*N + j )*work;
		}
*/
				for(s=-5;s<6;s++){
				for(t=-5;t<6;t++){

					if( ((i + (s*src->width) + t)>=0)&&((i + (s*src->width) + t)<(src->width*src->height))  ){

						work=*(b + i+ (s*src->width) + t );
						wk+=*(a +(s+5)*11 +(t+5))*work;


					}
				}}


		*(c+i) = wk;
	}
}







int double_comp( const void *s1 , const void *s2 )
{
	const double a1 = *((double *)s1); /* (double *)�փL���X�g*/
	const double a2 = *((double *)s2); /* (double *)�փL���X�g*/		

	if( a1 < a2 )
	{
		return -1;
	}
	else if( a1 == a2 )
	{
		return 0;
	}
	else
	{
		return 1;
	}
}



/* A�x�N�g��a[0,...,N-1]��b[0,...,N-1]�̓��ς��v�Z����*/
float inner_product(float *a, float *b)
{
	int i;
	float s = 0.0;

	for( i= 0; i< N_gen; i++) s += (*(a+i)*(*(b+i)));
		return s ;
	}


/* 1�m�����̌v�Za[0,...,N-1] */
float vector_norm1( float *a)
{
	int i;
	float norm = 0.0;
	for ( i = 0; i < N_gen; i++ )
	{
		norm += fabs(*(a+i));
	}
	return norm;
}





float* gauss_filter(int filter_rad,float sigma){
	float* a=(float*)calloc(121,sizeof(float));
	int i=0,j=0;
	double dist=0;
	double sum=0;

	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			dist=sqrt((double)( (i-filter_rad)*(i-filter_rad) + (j-filter_rad)*(j-filter_rad)) );

//			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist*dist)/(2*sigma*sigma));
			*(a + i*(filter_rad*2+1) + j) =(float)exp(((-1)*dist)/(2*sigma*sigma));
			sum+=*(a + i*(filter_rad*2+1) + j);
		}
	}

	//���K������
	for(i=0;i<(filter_rad*2+1);i++){
		for(j=0;j<(filter_rad*2+1);j++){

			*(a + i*(filter_rad*2+1) + j)/=sum;

		}
	}

	return a;
}